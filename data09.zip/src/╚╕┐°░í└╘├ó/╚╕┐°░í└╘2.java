package ȸ������â;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ȸ������2 {
	private static JTextField t1;
	private static JTextField t2;
	private static JTextField t3;
	private static JTextField t4;

	/**
	 * @wbp.parser.entryPoint
	 */
	public void sighIn() { // ȸ������ â �߰� �ϱ�
		
		JFrame f = new JFrame();
		f.getContentPane().setBackground(Color.GREEN);
		f.setSize(373,450);
		f.getContentPane().setLayout(null);
		
		t1 = new JTextField();
		t1.setBackground(Color.YELLOW);
		t1.setBounds(145, 10, 180, 40);
		f.getContentPane().add(t1);
		t1.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("\uC544\uC774\uB514");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 25));
		lblNewLabel.setBounds(14, 10, 119, 40);
		f.getContentPane().add(lblNewLabel);
		
		t2 = new JTextField();
		t2.setBackground(Color.YELLOW);
		t2.setColumns(10);
		t2.setBounds(145, 60, 180, 40);
		f.getContentPane().add(t2);
		
		JLabel lblNewLabel_1 = new JLabel("\uD328\uC2A4\uC6CC\uB4DC");
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 25));
		lblNewLabel_1.setBounds(14, 60, 119, 40);
		f.getContentPane().add(lblNewLabel_1);
		
		t3 = new JTextField();
		t3.setBackground(Color.YELLOW);
		t3.setColumns(10);
		t3.setBounds(145, 115, 180, 40);
		f.getContentPane().add(t3);
		
		JLabel lblNewLabel_2 = new JLabel("\uC774\uB984");
		lblNewLabel_2.setFont(new Font("����", Font.PLAIN, 25));
		lblNewLabel_2.setBounds(14, 115, 119, 40);
		f.getContentPane().add(lblNewLabel_2);
		
		t4 = new JTextField();
		t4.setBackground(Color.YELLOW);
		t4.setColumns(10);
		t4.setBounds(145, 165, 180, 40);
		f.getContentPane().add(t4);
		
		JLabel lblNewLabel_3 = new JLabel("\uC804\uD654\uBC88\uD638");
		lblNewLabel_3.setFont(new Font("����", Font.PLAIN, 25));
		lblNewLabel_3.setBounds(14, 165, 119, 40);
		f.getContentPane().add(lblNewLabel_3);
		
		JButton ȸ������ = new JButton("\uD68C\uC6D0\uAC00\uC785\uCC98\uB9AC");
		ȸ������.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = t1.getText();
				String pw = t2.getText();
				String name = t3.getText();
				String tel = t3.getText();
				
				DB���� db = new DB����();
				db.insert(id, pw, name, tel);
			}
		});
		ȸ������.setBackground(Color.WHITE);
		ȸ������.setFont(new Font("����", Font.PLAIN, 20));
		ȸ������.setBounds(67, 261, 226, 86);
		f.getContentPane().add(ȸ������);
		
		
		
		f.setVisible(true);
	}
}
