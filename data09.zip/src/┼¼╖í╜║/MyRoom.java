package Ŭ����;

public class MyRoom {

	public static void main(String[] args) {
		
		
		Tv myTv = new Tv();
		Tv yourTv = new Tv();
		
		myTv.channel = 20;
		myTv.onOff = "on";
		myTv.volume = 100;
		myTv.turnOn();
		myTv.turnOff();
		
		yourTv.channel = 30;
		yourTv.onOff = "off";
		yourTv.volume = 100;
		yourTv.turnOff();
		yourTv.turnOn();
		
		System.out.println(myTv);
	}

}
