package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import db.MemberDTO;

public class MemberDAO {
//1. 회원가입
	public int insert(MemberDTO dto) {
		int result = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("커넥터 설정 ok");
			// 2. db연결
			String url = "jdbc:mysql://localhost:3708/virus";
			String user = "root";
			String password = "1234";

			// 검색을 에정,
			java.sql.Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("데이터베이스 연결 ok!");
			// 3. sql문 결정
			String sql = "insert into member values (?,?,?,?)"; // ?는 빈 변수를 의미한다.
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			ps.setString(2, dto.getPw());
			ps.setString(3, dto.getName());
			ps.setString(4, dto.getTel());

			System.out.println("sql 데이터 결정 ok");
			// 4. sql 전송
			result = ps.executeUpdate();
			System.out.println("sql문 전송 ok");
			System.out.println("db연결 처리하다.");
		} catch (Exception e1) {
			System.out.println("예외처리가  있습니다.");
		}
		return result;
	}
	
	//1. 수정
		public int update(MemberDTO dto) {
			int result = 0;
			try {
				Class.forName("com.mysql.jdbc.Driver");
				System.out.println("커넥터 설정 ok");
				// 2. db연결
				String url = "jdbc:mysql://localhost:3708/virus";
				String user = "root";
				String password = "1234";

				// 검색을 에정,
				java.sql.Connection con = DriverManager.getConnection(url, user, password);
				System.out.println("데이터베이스 연결 ok!");
				// 3. sql문 결정
				String sql = "update member set pw = ?, name = ?, tel = ? "
						+ "where id = ?"; // ?는 빈 변수를 의미한다.
				PreparedStatement ps = con.prepareStatement(sql);
				ps.setString(4, dto.getId());
				ps.setString(1, dto.getPw());
				ps.setString(2, dto.getName());
				ps.setString(3, dto.getTel());
				System.out.println(dto);
				// 4. sql 전송
				result = ps.executeUpdate();
			} catch (Exception e1) {
				System.out.println("예외처리가  있습니다.");
			}
			return result;
		}	

//2. db연결
	public Connection connect() {
		MemberDAO db1 = new MemberDAO();
		Connection con = null;
		// 1. 커넥터 설정
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("커넥터 설정 ok");
			// 2. db연결
			String url = "jdbc:mysql://localhost:3708/virus";
			String user = "root";
			String password = "1234";
			con = DriverManager.getConnection(url, user, password);
			if(con != null) {
				System.out.println("데이터베이스 연결 ok!");
				// 3. sql문 결정
				// 4. sql 전송
				System.out.println("db연결 처리하다.");
			}else {
				System.out.println("데이터 연결 실패!");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("예외가 발생했습니다.");
		}
		return con;

	}

//3. 회원탈퇴
	public int delete(MemberDTO dto) {		
		int result = 0;
		try {
			Connection con =connect();
			String sql = "delete from member where id = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			result = ps.executeUpdate();		// 되면 1을 반환한다.
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return result;
	}

//4. 회원검색	
	public MemberDTO select(MemberDTO dto) {
		MemberDTO dto2 = null; // ★★★★★★★★★ 아주 중요한 방법
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("커넥터 설정 ok");
			// 2. db연결
			String url = "jdbc:mysql://localhost:3708/virus";
			String user = "root";
			String password = "1234";

			// 검색을 에정,
			java.sql.Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("데이터베이스 연결 ok!");
			// 3. sql문 결정
			String sql = "select * from member where id = ?"; // ?는 빈 변수를 의미한다.
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			ResultSet rs = ps.executeQuery();
			if (rs.next()) { // 있는지 없는지 확인시켜주는 아이
				dto2 = new MemberDTO();// 있으면 생성되어야 하기 때문에 이 방법 잘 기억 ★★★★★★★★★
				String id = rs.getString(1);
				String pw = rs.getString(2);
				String name = rs.getString("name");
				String tel = rs.getString("tel");
				dto2.setId(id);
				dto2.setPw(pw);
				dto2.setName(name);
				dto2.setTel(tel);
			}
		} catch (Exception e1) {
			System.out.println("예외처리가  있습니다.");
		}
		System.out.println(dto2);
		return dto2;
	}
}
