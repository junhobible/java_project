package user_join;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import control.CheckSeat;
import database.DaoConn;
import database.DtoMember;
import database.MemDaoCrud;

import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SeatsGraphic {

	public void seatsgraphic(DtoMember dto) {

		if (dto == null) {
			seats();
		} else {
			seats2(dto);
		}

	}

	public void seats() {
		JFrame f = new JFrame();
		f.setSize(564, 420);
		f.getContentPane().setLayout(null);
		SeatPopup sp = new SeatPopup();

		JButton b1 = new JButton("1");
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton button = b1;
				sp.popup(button, 1, f); // button 자체를 넘겨준다.
			}
		});
		b1.setBackground(Color.LIGHT_GRAY);
		b1.setBounds(12, 45, 97, 62);
		f.getContentPane().add(b1);

		JButton b2 = new JButton("2");
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton button = b2;
				sp.popup(button, 2, f);
			}
		});
		b2.setBackground(Color.LIGHT_GRAY);
		b2.setBounds(121, 45, 97, 62);
		f.getContentPane().add(b2);

		JButton b3 = new JButton("3");
		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton button = b3;
				sp.popup(button, 3, f);
			}
		});
		b3.setBackground(Color.LIGHT_GRAY);
		b3.setBounds(12, 117, 97, 62);
		f.getContentPane().add(b3);

		JButton b4 = new JButton("4");
		b4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton button = b4;
				sp.popup(button, 4, f);
			}
		});
		b4.setBackground(Color.LIGHT_GRAY);
		b4.setBounds(121, 117, 97, 62);
		f.getContentPane().add(b4);

		JButton b5 = new JButton("5");
		b5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton button = b5;
				sp.popup(button, 5, f);
			}
		});
		b5.setBackground(Color.LIGHT_GRAY);
		b5.setBounds(12, 189, 97, 62);
		f.getContentPane().add(b5);

		JButton b6 = new JButton("6");
		b6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton button = b6;
				sp.popup(button, 6, f);
			}
		});
		b6.setBackground(Color.LIGHT_GRAY);
		b6.setBounds(121, 189, 97, 62);
		f.getContentPane().add(b6);

		JButton b7 = new JButton("7");
		b7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton button = b7;
				sp.popup(button, 7, f);
			}

		});
		b7.setBackground(Color.LIGHT_GRAY);
		b7.setBounds(12, 261, 97, 62);
		f.getContentPane().add(b7);

		JButton b8 = new JButton("8");
		b8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton button = b8;
				sp.popup(button, 8, f);
			}
		});
		b8.setBackground(Color.LIGHT_GRAY);
		b8.setBounds(121, 261, 97, 62);
		f.getContentPane().add(b8);

		JButton b9 = new JButton("9");
		b9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton button = b9;
				sp.popup(button, 9, f);
			}
		});
		b9.setBackground(Color.LIGHT_GRAY);
		b9.setBounds(330, 45, 97, 62);
		f.getContentPane().add(b9);

		JButton b10 = new JButton("10");
		b10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton button = b10;
				sp.popup(button, 10, f);
			}
		});
		b10.setBackground(Color.LIGHT_GRAY);
		b10.setBounds(439, 45, 97, 62);
		f.getContentPane().add(b10, f);

		JButton b11 = new JButton("11");
		b11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton button = b11;
				sp.popup(button, 11, f);
			}
		});
		b11.setBackground(Color.LIGHT_GRAY);
		b11.setBounds(330, 117, 97, 62);
		f.getContentPane().add(b11);

		JButton b12 = new JButton("12");
		b12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton button = b12;
				sp.popup(button, 12, f);
			}
		});
		b12.setBackground(Color.LIGHT_GRAY);
		b12.setBounds(439, 117, 97, 62);
		f.getContentPane().add(b12);

		JButton b13 = new JButton("13");
		b13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton button = b13;
				sp.popup(button, 13, f);
			}
		});
		b13.setBackground(Color.LIGHT_GRAY);
		b13.setBounds(330, 189, 97, 62);
		f.getContentPane().add(b13);

		JButton b14 = new JButton("14");
		b14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton button = b14;
				sp.popup(button, 14, f);
			}
		});
		b14.setBackground(Color.LIGHT_GRAY);
		b14.setBounds(439, 189, 97, 62);
		f.getContentPane().add(b14);

		JButton b15 = new JButton("15");
		b15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton button = b15;
				sp.popup(button, 15, f);
			}
		});
		b15.setBackground(Color.LIGHT_GRAY);
		b15.setBounds(330, 261, 97, 62);
		f.getContentPane().add(b15);

		JButton b16 = new JButton("16");
		b16.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton button = b16;
				sp.popup(button, 16, f);
			}
		});
		b16.setBackground(Color.LIGHT_GRAY);
		b16.setBounds(439, 261, 97, 62);
		f.getContentPane().add(b16);

		f.setVisible(true);
	}

	public void seats2(DtoMember dto) { // 로그인후 자리변경하기
		System.out.println("자리함수" + dto);
		int seatNum = dto.getSeat_num();
		JFrame f = new JFrame();
		f.setSize(564, 420);
		f.getContentPane().setLayout(null);
		SeatPopup sp = new SeatPopup();
		CheckSeat cs = new CheckSeat();
		
		JButton[] button_list = new JButton[16];	
		
		
		
		for (int i = 0; i < button_list.length; i++) {
			String j = Integer.toString(i+1);
			button_list[i] = new JButton(j);
		}
		

		button_list[0].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				cs.checkseat(f,1, seatNum, dto, sp);		// 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.		
			}
		});
		button_list[0].setBackground(Color.LIGHT_GRAY);
		button_list[0].setBounds(12, 45, 97, 62);
		f.getContentPane().add(button_list[0]);
		
		button_list[1].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f,2, seatNum, dto, sp);
			}
		});
		button_list[1].setBackground(Color.LIGHT_GRAY);
		button_list[1].setBounds(121, 45, 97, 62);
		f.getContentPane().add(button_list[1]);
		
		button_list[2] = new JButton("3");
		button_list[2].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f,3, seatNum, dto, sp);
			}
		});
		button_list[2].setBackground(Color.LIGHT_GRAY);
		button_list[2].setBounds(12, 117, 97, 62);
		f.getContentPane().add(button_list[2]);
		
		
		
		button_list[3].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f,4, seatNum, dto, sp);
			}
		});
		button_list[3].setBackground(Color.LIGHT_GRAY);
		button_list[3].setBounds(121, 117, 97, 62);
		f.getContentPane().add(button_list[3]);
		
		
		
		button_list[4].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f,5, seatNum, dto, sp);
			}
		});
		button_list[4].setBackground(Color.LIGHT_GRAY);
		button_list[4].setBounds(12, 189, 97, 62);
		f.getContentPane().add(button_list[4]);
		
		
		button_list[5].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f,6, seatNum, dto, sp);
			}
		});
		button_list[5].setBackground(Color.LIGHT_GRAY);
		button_list[5].setBounds(121, 189, 97, 62);
		f.getContentPane().add(button_list[5]);
		
		
		
		button_list[6].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f,7, seatNum, dto, sp);
			}
			
		});
		button_list[6].setBackground(Color.LIGHT_GRAY);
		button_list[6].setBounds(12, 261, 97, 62);
		f.getContentPane().add(button_list[6]);
	
		
		
		button_list[7].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f,7, seatNum, dto, sp);
			}
		});
		button_list[7].setBackground(Color.LIGHT_GRAY);
		button_list[7].setBounds(121, 261, 97, 62);
		f.getContentPane().add(button_list[7]);
		
		
		button_list[8].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f,9, seatNum, dto, sp);
			}
		});
		button_list[8].setBackground(Color.LIGHT_GRAY);
		button_list[8].setBounds(330, 45, 97, 62);
		f.getContentPane().add(button_list[8]);	
		
		
		
		
		button_list[9].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f,10, seatNum, dto, sp);
			}
		});
		button_list[9].setBackground(Color.LIGHT_GRAY);
		button_list[9].setBounds(439, 45, 97, 62);
		f.getContentPane().add(button_list[9],f);
		
		button_list[10] = new JButton("11");
		button_list[10].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f,11, seatNum, dto, sp);
			}
		});
		button_list[10].setBackground(Color.LIGHT_GRAY);
		button_list[10].setBounds(330, 117, 97, 62);
		f.getContentPane().add(button_list[10]);
		
	
		
		button_list[11].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f,12, seatNum, dto, sp);
			}
		});
		button_list[11].setBackground(Color.LIGHT_GRAY);
		button_list[11].setBounds(439, 117, 97, 62);
		f.getContentPane().add(button_list[11]);
		
		
		button_list[12].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f,13, seatNum, dto, sp);
			}
		});
		button_list[12].setBackground(Color.LIGHT_GRAY);
		button_list[12].setBounds(330, 189, 97, 62);
		f.getContentPane().add(button_list[12]);	
		
		
		button_list[13].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f,14, seatNum, dto, sp);
			}
		});
		button_list[13].setBackground(Color.LIGHT_GRAY);
		button_list[13].setBounds(439, 189, 97, 62);
		f.getContentPane().add(button_list[13]);
		
		button_list[14].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f,15, seatNum, dto, sp);
			}
		});
		button_list[14].setBackground(Color.LIGHT_GRAY);
		button_list[14].setBounds(330, 261, 97, 62);
		f.getContentPane().add(button_list[14]);		
	
		
		button_list[15].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f,16, seatNum, dto, sp);
			}
		});
		button_list[15].setBackground(Color.LIGHT_GRAY);
		button_list[15].setBounds(439, 261, 97, 62);
		f.getContentPane().add(button_list[15]);	
		
		button_list[seatNum-1].setBackground(Color.BLUE);
		
		f.setVisible(true);
	}
		
	
}
