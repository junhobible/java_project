package user_join;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import control.TimeTrans;
import database.DaoCrud;
import database.DtoMember;


public class UserInter {
	private JLabel t1;
	private JLabel t2;
	private JLabel t3;
	private JLabel t4;
	SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	SimpleDateFormat format2 = new SimpleDateFormat("HH:mm:ss");
	TimeTrans ttr = new TimeTrans();
	public int leftTime = 0;


//	sql
	/**
	 * @wbp.parser.entryPoint
	 */
	public void userInter(DtoMember dto) {
		JFrame f = new JFrame();
		f.getContentPane().setBackground(Color.GRAY);
		
		f.setSize(454, 363);
		f.getContentPane().setLayout(null);
		
		JLabel b1 = new JLabel("더 좋은 pc방");
		b1.setForeground(Color.WHITE);
		b1.setFont(new Font("휴먼둥근헤드라인", Font.PLAIN, 20));
		b1.setHorizontalAlignment(SwingConstants.RIGHT);
		b1.setBounds(38, 10, 256, 37);
		f.getContentPane().add(b1);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setForeground(Color.YELLOW);
		lblNewLabel_1.setBounds(22, 46, 71, 31);
		f.getContentPane().add(lblNewLabel_1);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.DARK_GRAY);
		panel.setBounds(22, 87, 404, 182);
		f.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBounds(12, 10, 380, 156);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("회원이름");
		lblNewLabel_2.setBounds(41, 11, 70, 25);
		panel_1.add(lblNewLabel_2);
		
		t1 = new JLabel();
		t1.setBounds(142, 13, 116, 21);
		panel_1.add(t1);
		t1.setText(dto.getId()); // 회원 id 출력
		
		JLabel lblNewLabel_2_1 = new JLabel("시작일시");
		lblNewLabel_2_1.setBounds(41, 40, 67, 26);
		panel_1.add(lblNewLabel_2_1);
		
		t2 = new JLabel();
		t2.setBounds(142, 43, 116, 21);
		panel_1.add(t2);
		t2.setText(format1.format(dto.getTime_login()));
		
		
		
		JLabel lblNewLabel_2_2 = new JLabel("사용시간");
		lblNewLabel_2_2.setBounds(41, 70, 65, 24);
		panel_1.add(lblNewLabel_2_2);
		
		t3 = new JLabel();
		t3.setBounds(142, 72, 116, 21);
		panel_1.add(t3);
		
		TimeThread tt = new TimeThread(dto); // Thread !!!!!
		tt.start();
		
		JLabel lblNewLabel_2_3 = new JLabel("남은시간");
		lblNewLabel_2_3.setBounds(41, 97, 67, 28);
		panel_1.add(lblNewLabel_2_3);
		
		t4 = new JLabel();
		t4.setBounds(142, 101, 116, 21);
		panel_1.add(t4);
		
		JButton btnNewButton = new JButton("정보수정");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Join j = new Join();
				j.join(dto);				
			}
		});
		btnNewButton.setBounds(322, 56, 104, 23);
		f.getContentPane().add(btnNewButton);
		
		JButton b2 = new JButton("자리이동");
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				long time = tt.returnValue();
				DaoCrud dao = new DaoCrud();
				dto.setTime_left(time);
				dao.update(dto);
				System.out.println("userinter"+ dto);
				SeatsGraphic sg = new SeatsGraphic();
				sg.seatsgraphic(dto);
				f.dispose();
			}
		});
		b2.setBounds(122, 279, 97, 23);
		f.getContentPane().add(b2);
		
		JButton b3 = new JButton("사용종료");
		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				long time = tt.returnValue();
				DaoCrud dao = new DaoCrud();
				dto.setTime_left(time);
				dao.update(dto);	
				SeatsGraphic sc = new SeatsGraphic() ;
				sc.seats();
				f.dispose();
			}
		});
		b3.setBounds(246, 279, 97, 23);
		f.getContentPane().add(b3);
		
		
		
		f.setVisible(true);
	}
	
	public class TimeThread extends Thread{ // 스레드를 해주어서 계속 줄어들게 한다.
		private long time1 = System.currentTimeMillis();
		private long time2 = 0;
		private long time_result= 0;
		public TimeThread(DtoMember dto) {  // 안에 변수를 받기 위한 함수이다.
			this.time2 = dto.getTime_left();
		}
		
		public void run() {			// 동작함수
			while(true) {
				try {
					Thread.sleep(1000);	
					long time3 = System.currentTimeMillis();
					t3.setText(ttr.timetrans((time3 - time1)/1000));
					time_result = time2-((time3 - time1)/1000);
					t4.setText(ttr.timetrans(time_result));
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
		
		public long returnValue() {
			return time_result;
		}
	}
	



	
	
}

// Thread ★★★★★★★★

