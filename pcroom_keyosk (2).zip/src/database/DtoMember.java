package database;

import java.util.Calendar;
import java.util.Date;

public class DtoMember {
	public String id;
	public String pw;
	public String name;
	public String gender;
	public String birth;
	public String tel;
	public String email;
	public String addr;
	public long time_left;
	public Date time_login;
	
	
	@Override
	public String toString() {
		return "DtoMember [id=" + id + ", pw=" + pw + ", name=" + name + ", gender=" + gender + ", birth=" + birth
				+ ", tel=" + tel + ", email=" + email + ", addr=" + addr + ", time_left=" + time_left + ", time_login="
				+ time_login + ", seat_num=" + seat_num + "]";
	}
	public long getTime_left() {
		return time_left;
	}
	public Date getTime_login() {
		return time_login;
	}
	public void setTime_left(long time_left) {
		this.time_left = time_left;
	}
	public void setTime_login(Date time_login) {
		this.time_login = time_login;
	}
	public int seat_num;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	
	public int getSeat_num() {
		return seat_num;
	}
	public void setSeat_num(int seat_num) {
		this.seat_num = seat_num;
	}
	
	
}
