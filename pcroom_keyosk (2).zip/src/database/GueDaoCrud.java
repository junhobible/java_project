package database;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class GueDaoCrud {
	
	DaoConn con = new DaoConn();
	Connection con1 =con.conn();
	
	
	public void update(DtoGuest dto) {
		try {
			String s = "update guest set expired_time =?, expired_yn = ?, "
					+ " time_left =?, time_login = ?, seat_num = ?, adult_YN = ? where login_id = ?";			
			PreparedStatement ps = con1.prepareStatement(s);
			SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			java.util.Date time = dto.getTime_login();
			Timestamp t = Timestamp.valueOf(format1.format(time));			
			Calendar cal = Calendar(time);
			cal.add(Calendar.HOUR, 24);
			java.util.Date time_expired = cal.getTime();
			Timestamp t2 = Timestamp.valueOf(format1.format(time_expired));		
			ps.setTimestamp(1, t2);
			ps.setString(2, dto.getExpired_YN());
			ps.setLong(3, dto.getTime_left());
			ps.setTimestamp(4, t);
			ps.setInt(5, dto.getSeat_num());
			ps.setString(6, dto.getAdult_YN());
			ps.setInt(7, dto.getLogin_num());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private Calendar Calendar(java.util.Date time) {
		// TODO Auto-generated method stub
		return null;
	}

	public DtoGuest select(int id) {
		
		String sql = "select * from guest where id = ?";
		DtoGuest dto = null;
		try {
			PreparedStatement ps= con1.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs =ps.executeQuery();
			if(rs.next()) {
				dto = new DtoGuest();
				dto.setLogin_num(rs.getInt(1));
				dto.setExpired_time(rs.getTimestamp(2));
				dto.setExpired_YN(rs.getString(3));
				dto.setTime_left(rs.getLong(4));
				dto.setTime_login(rs.getTimestamp(5));
				dto.setSeat_num(rs.getInt(6));
				dto.setAdult_YN(rs.getString(7));
				System.out.println("select : " + dto);
			}else {
				System.out.println("셀렉트 함수가 자료가 없습니다.");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return dto;
	}	
	
	public Boolean read_for_id(int choice) { // id를 검색하는 메서드			
		try {
			String s = "select * from guest";			
			PreparedStatement ps = con1.prepareStatement(s);
			ResultSet rs = ps.executeQuery(); //읽어들일때는 ResultSet과 아래를 쓴다.
			while(rs.next()) {
				if(rs.getInt("login_num") == choice) {
					return true;
				}
			}				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public int read_for_time_left(String id) {
		int result = 0;
		String sql = "select * from member where id = ?";
		PreparedStatement ps;
		try {
			ps = con1.prepareStatement(sql);
			ps.setString(1, id);
			ResultSet rs =ps.executeQuery();
			if(rs.next()) {
				result = rs.getInt(9);
			}else {
				System.out.println("데이터를 불러오는데 실패했습니다.");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}
}
