package control;

public class TimeTrans {
	
	public String timetrans(long time) {
		long hour, min, sec;
		
		sec = time;
		min = sec/60;
		hour = min/60;
		sec = sec % 60;
		min = min % 60;
		
		String result = "" + hour + ":" + min + ":" + sec; 
		return result;
	}
}
