package user_join;

public class main {

	public static void main(String[] args) {
		SeatsGraphic sg = new SeatsGraphic();
		sg.seatsgraphic(null);
	}

}
