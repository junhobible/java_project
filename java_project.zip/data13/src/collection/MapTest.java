package collection;

import java.util.HashMap;

public class MapTest {
	public static void main(String[] args) {
		//Map은 키:값의 쌍으로 저장해야 하는 경우!
		//각 언어, 각 영역 간의 데이터를 보낼 때 설명을 알리기 위래 meta 데이터 넣어서 준다.
		// jason, dictionary, map를 중요하게 알아두어라!
		
		HashMap dic = new HashMap();
		dic.put("apple", "사과"); // 다른 자료형은 add
		dic.put("banana", "바나나");
		dic.put("melon", "멜롱");
		
//		dic.clear() : 제거
		dic.replace("apple", "사과짱"); // update
		System.out.println(dic.get("apple"));
		
		
		
		
	}
}
