package collection;

import java.util.ArrayList;

public class ListTest4 {
	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>(); 
		// E : element 인자의 타입을 고정해서 object에서 계속 변환하는 작업을 방지하여 속도를 높임
		
		list.add("홍길동");
		list.add("박길동");
		list.add("정길동");
		String name = list.get(0);
		// E를 설정안하면 반환값이 object이기 때문에 앞에 타입을 반드시 재설정해주어야 한다.
	}
}
