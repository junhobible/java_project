package collection;

import java.util.ArrayList;

public class ListTest5 {
	public static void main(String[] args) {
		ArrayList<MemberDTO> list = new ArrayList<>();
		
		MemberDTO dto = new MemberDTO();
		dto.setId("park");
		dto.setPw("park");
		dto.setName("park");
		dto.setTel("park");
		list.add(dto);
		
		MemberDTO dto2 = new MemberDTO();
		dto.setId("park2");
		dto.setPw("park2");
		dto.setName("park2");
		dto.setTel("park2");
		list.add(dto2);
		
		System.out.println(list);
	}
}
