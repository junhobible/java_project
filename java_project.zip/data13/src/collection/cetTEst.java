package collection;

import java.util.HashSet;

public class cetTEst {

	public static void main(String[] args) {
		//set(집합) : 중복을 허용하지 않는 데이터의 모음
		// 순서는 의미가 없다. 순서대로 들어가지 않는다.
		
		HashSet	bag = new HashSet();
		
		bag.add("책");
		bag.add("볼펜");
		bag.add(5000);
		bag.add("커피");
		bag.add("책"); // 자동으로 체크해서 중복된 것은 제외한다.
		System.out.println(bag);
		
	}

}
