package collection;

public class 설명 {
//	컬렉션(collection)
//	- 모음, 묶음
//	- 모여있는 데이터의 특징에 따라서 다양한 클래스 존재
//	1) 집합(set) : 중복을 허용하지 않는 데이터들(HashSet)
//	2) 큐(queue) : First Input First Output(FIFO) -> LinkedList
//	3) 스택(stack, 저장, 누적) : First Input Last Output(FILO)
//  4) 목록(list) : 순서가 중요한 데이터(*)
//  5) 사전(map) : key와 value(apple:사과)
	
	
// checkList !!
	
//	1) DTO는 table의 무엇과 맵핑되나요?
//	table의 record 각 한줄과 맵핑
//	2) DTO의 멤버변수들은 table의 무엇과 맵핑되나요?
//	table의 field 와 맵핑됩니다.
//	3) orm이란 무엇의 약자인가요? 왜 필요한가
//	object rdb mapping으로 각 객체의 관계를 시각화하여 파악을 용이하게 한다.
//	4) insert할 때 orm을 어떻게 코딩해주어야 하나요?
//	DAO에 DTO를 넣어 데이터베이스에 insert로 삽입해준다.
//	5) select할 때 orm을 어떻게 코딩해주어야 하나요?
//	DAO에서 데이터베이스 내 자료를 다 불어와서 DTO를 반환하도록 해야한다.
//	6) JDBC란?
//	자바와 데이터베이스를 연겨라고 관리하도록 해주는 프로그램
//	7) JDBC 프로그래밍시 arraylist의 용도는 ?
//	다양한 타입의 데이터를 넣을 수 있어 dto로 쓰인다.
//	8) arraylist의 특징은 ? 배열과의 차이점은?
//	데이터 타입이 다르게 요소를 삽입할 수 있다. 크기를 정하지 않아도 된다.
//	9) arraylist의 개수를 알고자 할 때 사용하는 메소드는?
//	size()
//	10) 테이블 전체 검색하는 메소드의 반환타입은?
//	arrayList
//	11) Resultset rs일 때 rs에 들어있는것은?
//	table(항목명 + 인스턴스) = > schema + record
//	12) while(rs.next) 의 의미는?
//	rs객체에 있는 데이터 한줄씩 없을 때까지 유무를 확인하는 것
//	13) all() 메소드호출 후 반환받은 list 중 list.get(인덱스)의 결과는?
//	dto
//	14) jdbc프로그래밍의 절차 4가지
//	connector(driver) - > db연동 (url, user, password) -> sql문 결정 -> sql문 전송
//	jdbc import - > connection(login) - > prepare -> execute
//	15) ui --- dao - dbms(table) 구조에서 all()을 호출 후 일어나는 순서
//	ui에서 이벤트 --> dto에 저장되어 dao에 전달  - > dao에서 데이터베이스 연결 후 처리 ->
//	dao에서 처리후 dto 반환하여 ui에서 출력
	
	
}
