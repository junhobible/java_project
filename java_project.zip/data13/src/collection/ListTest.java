package collection;

import java.util.ArrayList;

public class ListTest {

	public static void main(String[] args) {
		// arraylist 좋은점
		// 배열보다 좋은 점 : 1) 크기조정 가능. 2) 아무 타입이나 넣을 수 있다.
		// 배열과 동일한 점 : 1) 인덱스가 있다. 2) 많은 데이터를 묶을 때 효율적.
		
		ArrayList list = new ArrayList();
		list.add("홍길동");
		list.add(100);
		list.add(11.22);
		list.add(true);
		list.add('a');
		list.set(4, null); // 값 update
		System.out.println(list); // ArrayList는 자동으로  toString이 들어가있다.
		
	}

}
