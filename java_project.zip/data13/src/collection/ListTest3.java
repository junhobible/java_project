package collection;

import java.util.ArrayList;

public class ListTest3 {
	public static void main(String[] args) {
		
		
		ArrayList list = new ArrayList();
		
		list.add("김연아");
		list.add("송연아");
		list.add("정연아");
		
		System.out.println(list.get(2));
		for (int i = 0; i < list.size(); i++) {
			System.out.println((i+1) + "등 : " + list.get(i));
		}
		list.remove(1); // list 제거
		list.set(1, "송송송");
		System.out.println(list);
		//가운데 삽입
		list.add(1, "박연아");
		System.out.println(list);
		
	}
}
