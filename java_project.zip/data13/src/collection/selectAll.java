package collection;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import java.awt.Font;

public class selectAll {

	public static void main(String[] args) {
		JFrame	f = new JFrame();
		f.setSize(500, 494);
		
		JTextArea textArea = new JTextArea();
		textArea.setFont(new Font("Monospaced", Font.PLAIN, 25));
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setBounds(0, 55, 484, 406);
		f.getContentPane().add(scrollPane);	
	
		scrollPane.setViewportView(textArea);
		
		
		
		JButton btnNewButton = new JButton("전체목록가져오기");
		btnNewButton.setBounds(0, 0, 484, 57);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				MemberDAO dao = new MemberDAO();
				
				
				ArrayList<MemberDTO> list = dao.all();
				
				for (int i = 0; i < list.size(); i++) {
					MemberDTO dto = list.get(i);
					textArea.append(dto.getId() + " " +
                            dto.getPw() + " " + 
                            dto.getName() + " " +
                            dto.getTel() + "\n");
				}
				
				
			}
		});
		f.getContentPane().setLayout(null);
		f.getContentPane().add(btnNewButton);
		
	
		
		

		
		
		
		f.setVisible(true);
	}
}
