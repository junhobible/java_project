package constructorTest;

import javax.swing.JOptionPane;

public class TvUser {

	public static void main(String[] args) {
		설명Tv myTv = new 설명Tv("빨강", 10);
		설명Tv myTv2 = new 설명Tv("파랑", 20);
		설명Tv myTv3 = new 설명Tv(); // 이렇게 하면(생성자) 코드를 간편하게 할수 있다.
		//객체 생성시 각 객체에 맞는 인스턴스를 넣기위해
		//힙영역에 객체별로 따로 복사되는 멤버변수
		//인스턴스 변수
		//동일한 이름으로 여러개 만들 수 있다.(다형성)
		//입력값으로 구분한다(매개변수의 개수, 순서, 타입으로 구분)
	
		String color = JOptionPane.showInputDialog("TV색 입력");
		String size = JOptionPane.showInputDialog("사이즈입력");
		int size2= Integer.parseInt(size);
		
		myTv3.color = color;
		myTv3.size = size2;
		System.out.println(myTv3);
		
	}

}
