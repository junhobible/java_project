package constructorTest;

import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Tv {

	public static void main(String[] args) {
		JFrame f = new JFrame("나의 윈도우");
		f.setSize(500, 500);
		f.setLayout(new FlowLayout());
		JButton j = new JButton("나를 눌러요");
		f.add(j);		
		f.setVisible(true);
	}
	
	
	
}
