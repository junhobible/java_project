package constructorTest;

public class constructTest1 {

	public static void main(String[] args) {
		
		
	}

}
