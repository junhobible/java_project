package constructorTest;

import java.util.Date;

public class test {

	public static void main(String[] args) {
		Date d = new Date();
		System.out.println(d.getDay());
	}

}
