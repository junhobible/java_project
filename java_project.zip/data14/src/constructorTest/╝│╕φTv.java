package constructorTest;

public class 설명Tv {
	
	String color;
	int size;
	//생성자 왜 사용하나요?(consrtructor)
	//객체 생성시 자동으로 해야할 작업이 있으면 생성자내에 넣어주면 된다.
	//객체 생성시 자동으로 해야할 작업이 무엇인가?
	//멤버변수 초기하
	//생성자는 메소드이다. - 반환여부를 명시하지 않는다. 무조건 void
	//대문자로 시작하는 유일한 메소드
	
	//생성자 --> 파라미터가 있는 생성자가 없는 경우는 자동으로 만들어줌
	//파라메터가 있는 생성자가 있는 경우는 자동으로 만들어주지 않음.
	//default --> 변수를 넣으려면 작성해주어야 함. 클래스가 호출되면 자동으로 동작하게 해주는 것: 생성자
	public 설명Tv(String color, int size) { // parameter 생성자, 명시적 생성자
		System.out.println("클래스 이름과 동일한 내가 호출됨");
		this.color = color;
		this.size = size;
	}
	
	// 입력값 없는 것으로 동시에 만들고자 할 때는 동시에 해주어야어 한다.(명시적으로 변경) 
	public 설명Tv() { // 기본생성자, default 생성자, 묵시적 생성자
		
	}
	

	@Override
	public String toString() {
		return "Tv [color=" + color + ", size=" + size + "]";
	}
	
}
