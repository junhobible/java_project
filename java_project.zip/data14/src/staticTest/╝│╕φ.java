package staticTest;

public class 설명 {

	public static void main(String[] args) {
//		static(스태틱, 정적) 
//		공유할 변수가 있으면 static 변수를 사용한다. 
		
//		String color ;
//		int price;
//		int count;
//		static int total; // 전역변수로 사용된다. 
//		static final String COMPANY = "웰킵스"; // final은 절대 변경할 수 없게 한 것이다. 그래서 상수라고 한다. 대문자로 꼭 쓴다.
//		
////		public static int getCount() {
////			return count;
////		} 요렇게 사용하면 안된다
//		public static int getTotal() {
//			return total;
//			//static 메소드를 사용한 경우,
//			// 멤버변수는 static변수여야 한다.
//			//객체 생성과 상관없이 접근하는 메서드와 멤버변수를 사용해야 한다.
			// integer.parseInt(), Class.forName(), Jsoup.connect() 등 모두가 static method이다.
//		}
		
	}

}
