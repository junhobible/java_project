package staticTest;

public class maskMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		maskTest m1 = new maskTest("흰색", 3000, 5);
		System.out.println(maskTest.total); // 클래스 이름으로 선언해준다.(전역변수)
		// setBackground(Color.Blue)도 그 예이다.
		maskTest m2 = new maskTest("검정색", 2500, 2);
		System.out.println(m2.total);
		
		System.out.println(m1);
		System.out.println(m2);
	}

}
