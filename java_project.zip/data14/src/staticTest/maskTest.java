package staticTest;

public class maskTest {
	String color ;
	int price;
	int count;
	static int total; // 전역변수로 사용된다. 
	static final String COMPANY = "웰킵스"; // final은 절대 변경할 수 없게 한 것이다. 그래서 상수라고 한다. 대문자로 꼭 쓴다.
	
//	public static int getCount() {
//		return count;
//	} 요렇게 사용하면 안된다
	public static int getTotal() {
		return total;
		//static 메소드를 사용한 경우,
		// 멤버변수는 static변수여야 한다.
		//객체 생성과 상관없이 접근하는 메서드와 멤버변수를 사용해야 한다.
	}
	
	public maskTest(String color, int price, int count) { // 생성자
		super();
		this.color = color;
		this.price = price;
		this.count = count;
		 
		total++; // 만들어진 마스크 개수를 세어보자.
	}

	public maskTest() { // 기본 생성자
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "maskTest [color=" + color + ", price=" + price + ", count=" + count + "]";
	}
	
	
	
	
}
