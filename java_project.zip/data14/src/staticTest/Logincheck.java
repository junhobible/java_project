package staticTest;

import javax.swing.JOptionPane;

public class Logincheck {
	static String logId ;
	public static void main(String[] args) {
		String saveId = "root";
		String savePw = "1234";
		
		
		String id = JOptionPane.showInputDialog("아이디 입력");
		String pw = JOptionPane.showInputDialog("패스워드 입력");
		
		if(saveId.equals(id) && savePw.equals(pw)) {
			
			JOptionPane.showMessageDialog(null, "로그인이 되었습니다.");
			logId = id;//원하는 곳에서 id를 사용할 수 있도록 static으로.
			News n = new News();
			n.news();
			
			Mail m = new Mail();
			m.mail();
		}else {
			JOptionPane.showMessageDialog(null, "로그인 실패하였습니다.");
		}
	}

}
