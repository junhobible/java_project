package staticTest;

import javax.swing.JOptionPane;

public class Mail {
	
	public void mail() {
		JOptionPane.showMessageDialog(null, "메일 :" + Logincheck.logId + "님 환영합니다.");
	}
}
