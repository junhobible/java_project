package staticTest;

public class Day {
	String doing;
	int time;
	String location;
	static int dayLong; // 일 누적
	static int sum; // 하는 시간 누적
	
	public Day(String doing, int time, String location) {
		this.doing = doing;
		this.time = time;
		this.location = location;
		dayLong++;
		sum = sum + time;
	}
	public Day() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Day [doing=" + doing + ", time=" + time + ", location=" + location + "]";
	}
	
	
	
	
}
