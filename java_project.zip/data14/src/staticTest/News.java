package staticTest;

import javax.swing.JOptionPane;

public class News {

	public void news() {
		// TODO Auto-generated method stub
		JOptionPane.showMessageDialog(null, "뉴스 :" + Logincheck.logId + "님 환영합니다.");
		
	}

}
