package staticTest;

public class emp {
	
	String name;
	String gender;
	int age;
	static int count;
	static int sumAge;
	
	public emp(String name, String gender, int age) {
		this.name = name;
		this.gender = gender;
		this.age = age;

		count++;
		sumAge = sumAge + age;
		
	}

	public emp() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
