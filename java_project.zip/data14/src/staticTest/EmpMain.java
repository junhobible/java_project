package staticTest;

public class EmpMain {

	public static void main(String[] args) {
		emp wk1 = new emp("임아무개", "남", 24);
		emp wk2 = new emp("김아무개", "여", 23);
		emp wk3 = new emp("박아무개", "남", 25);
		
		System.out.println("전체 직원 수는 : " + emp.count);
		System.out.println("전체 직원 나이 합은 : " + emp.sumAge);
	}
	
	
	
	
}
