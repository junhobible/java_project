package staticTest;

public class DayMain {

	public static void main(String[] args) {
		
		Day day1 = new Day("자바공부", 10, "강남");
		Day day2 = new Day("여행", 15, "강원도");
		Day day3 = new Day("운동", 11, "피트니스");
		
		System.out.println(day1);
		System.out.println(day2);
		System.out.println(day3);
		System.out.println("총 날 : " + Day.dayLong);
		System.out.println("총 시간 : " + Day.sum);
		System.out.println("평균 : " + Day.sum/Day.dayLong);
		
	
	}

}
