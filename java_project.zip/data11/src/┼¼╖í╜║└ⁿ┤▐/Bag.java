package 클래스전달;

public class Bag { // 한번에 묶어서 전송하려고!
	//Data transfer Object(DTO, VO : value Object0
	
	public String id; // public을 하면 전 프로젝트에서 사용하근
	public String pw;
	public String name;
	public int age;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	

	
	
}
