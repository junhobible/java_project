package 콜렉션전달;

public class Collection {

	public static void main(String[] args) {
		
		// 변수 -> 배열       ->     클래스                   -> Collection
		//    (변수 여러개) (타입이 여려개일 경우)  (클래스가 여러개 일 경우)
	}

}
