package 배열로전달;

public class 배열 {
	
	public void call(String[] list) {
		System.out.println("첫번째 값은 " + list[0]);
		System.out.println("첫번째 값은 " + list[1]);
	}
	
	public String[] call() {
//		System.out.println("call 메소드 호출됨"); 
		// 함수 이름이 같아도된다.(인자로 구분)
		// ★★★★★메서드 오버로딩(다형성)★★★★★★★
		// 하나의 이름으로 입력값이 다양한 형태를 쓰고 있다.
		String hobby = "달리기";
		String company = "mega";
//		return hobby, company; 파이썬만 가능, return 할 때는 하나씩 보낼 수 없다.
//		무조건 하나로 묶어야 한다.
		String[] array = {hobby, company};
		return array;
	}
}
