package 배열로전달;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import 배열로전달.배열;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class 변수로전달 {

	public static void main(String[] args) {
				
		
		JFrame f = new JFrame();
		f.setSize(300,300);
		f.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("변수로전달");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
//				String name = "홍길동";
//				int age = 100;
//				배열 var = new 배열();
//				var.call(name, age);
//				JOptionPane.showMessageDialog(null, "받은 값 : " + var.call2());
//				var.call();
			}
		});
		btnNewButton.setBounds(88, 10, 97, 23);
		f.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("배열로전달");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				배열로전달.배열 배열 = new 배열로전달.배열();
				String[] result  = 배열.call();
				JOptionPane.showMessageDialog(null, "취미는 " + result[0]);
				JOptionPane.showMessageDialog(null, "회사는 " + result[1]);
				
				String[]	list = {"달리기", "자전거 타기"};
				배열.call(list);
			}
		});
		btnNewButton_1.setBounds(88, 59, 97, 23);
		f.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("클래스전달");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_2.setBounds(88, 113, 97, 23);
		f.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("컬렉션전달");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_3.setBounds(88, 169, 97, 23);
		f.getContentPane().add(btnNewButton_3);
		
		
		
		f.setVisible(true);
	}

}
