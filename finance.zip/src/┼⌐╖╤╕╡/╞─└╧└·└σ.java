package 크롤링;

import java.io.FileWriter;
import java.io.IOException;

public class 파일저장 {
	public void save(String s, String[] contents) {
		
		try {
			FileWriter file = new FileWriter(s, true);
			for (int i = 0; i < contents.length; i++) {
				file.write(" "+ contents[i] + " ");
			}
				file.write("\n");
			file.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//file에 삽입하기//		FileWriter file = new FileWriter("naver.txt");
//		for (String s : contents) {
//			file.write(s + "\n");
//		}
//		file.close();
	}
}
