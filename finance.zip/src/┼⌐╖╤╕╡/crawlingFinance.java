package 크롤링;

import java.awt.Color;
import java.awt.Font;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class crawlingFinance {
	
	public static void main(String[] args) {
		crawlingFinance2 cr = new crawlingFinance2();	
		String s = "td em .blind";
		
		String[][] total = new String[7][];
		String[][] totalPerCom = new String[10][];
		total[0] = cr.forName(".wrap_company h2 a");				
		total[1] = cr.forLast(".no_today span");
		total[2] = cr.forStart(s);		
		total[3] = cr.forYester(s);		
		total[4] = cr.forHigh(s);
		total[5] = cr.forLow(s);
		total[6] = cr.forQuan(s);
		
		파일저장 file = new 파일저장();
		for (int i = 0; i < 7; i++) {
			file.save("naverfinance.txt", total[i]);
		}
		
//		for (int i = 2; i < 4; i++) {
//			for (int j = 0; j < 10; j++) {
//				System.out.print(total[i][j] + " ");
//				
//			}
//			System.out.println();
//		}
//		
		//		for (int i = 0; i < totalPerCom.length; i++) {
//			for (int j = 0; j < total.length; j++) {
//				for (int j2 = 0; j2 < total.length; j2++) {
//					totalPerCom[i][j] = total[j][j2];
//				}
//				
//			}
//		}
		
		//그래픽
		
		JFrame f = new JFrame();
		f.setTitle("주식 정보 검색");
		f.getContentPane().setBackground(Color.GRAY);
		f.setSize(600,550);
		f.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("회사명:");
		lblNewLabel.setFont(new Font("굴림", Font.BOLD, 27));
		lblNewLabel.setBounds(74, 239, 100, 42);
		f.getContentPane().add(lblNewLabel);
		
		JTextField t1 = new JTextField();
		t1.setFont(new Font("굴림", Font.BOLD, 26));
		t1.setBounds(177, 240, 206, 42);
		f.getContentPane().add(t1);
		t1.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("주식정보 검색");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("굴림", Font.BOLD, 30));
		lblNewLabel_1.setBounds(177, 21, 242, 42);
		f.getContentPane().add(lblNewLabel_1);
		
				
		JPanel panel = new JPanel();
		panel.setBounds(12, 76, 560, 127);
		f.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_2_1 = new JLabel("삼성전자  한진칼  JW중외제약  씨젠  에이치엘비");
		lblNewLabel_2_1.setBounds(72, 38, 436, 50);
		panel.add(lblNewLabel_2_1);
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1.setFont(new Font("굴림", Font.PLAIN, 18));
		
		JLabel lblNewLabel_2 = new JLabel("셀트리온  국동  흥아해운  모나미  프로스테믹스");
		lblNewLabel_2.setBounds(72, 77, 436, 50);
		panel.add(lblNewLabel_2);
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("굴림", Font.PLAIN, 18));
		
		JLabel lblNewLabel_2_1_1 = new JLabel("<검색 가능한 회사 목록>");
		lblNewLabel_2_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1_1.setFont(new Font("굴림", Font.BOLD, 17));
		lblNewLabel_2_1_1.setBounds(89, 0, 394, 50);
		panel.add(lblNewLabel_2_1_1);
		
		JLabel lblNewLabel_3 = new JLabel("현재가");
		lblNewLabel_3.setFont(new Font("굴림", Font.BOLD, 20));
		lblNewLabel_3.setBounds(27, 326, 74, 42);
		f.getContentPane().add(lblNewLabel_3);
		
		JTextField t2 = new JTextField();
		t2.setFont(new Font("굴림", Font.BOLD, 18));
		t2.setBounds(95, 326, 160, 42);
		f.getContentPane().add(t2);
		t2.setColumns(10);
		
		JLabel lblNewLabel_3_1 = new JLabel("고가");
		lblNewLabel_3_1.setFont(new Font("굴림", Font.BOLD, 20));
		lblNewLabel_3_1.setBounds(289, 326, 74, 42);
		f.getContentPane().add(lblNewLabel_3_1);
		
		JTextField t5 = new JTextField();
		t5.setFont(new Font("굴림", Font.BOLD, 18));
		t5.setColumns(10);
		t5.setBounds(357, 326, 160, 42);
		f.getContentPane().add(t5);
		
		JLabel lblNewLabel_3_2 = new JLabel("시가");
		lblNewLabel_3_2.setFont(new Font("굴림", Font.BOLD, 20));
		lblNewLabel_3_2.setBounds(27, 378, 74, 42);
		f.getContentPane().add(lblNewLabel_3_2);
		
		JTextField t3 = new JTextField();
		t3.setFont(new Font("굴림", Font.BOLD, 18));
		t3.setColumns(10);
		t3.setBounds(95, 378, 160, 42);
		f.getContentPane().add(t3);
		
		JLabel lblNewLabel_3_3 = new JLabel("저가");
		lblNewLabel_3_3.setFont(new Font("굴림", Font.BOLD, 20));
		lblNewLabel_3_3.setBounds(289, 378, 74, 42);
		f.getContentPane().add(lblNewLabel_3_3);
		
		JTextField t6 = new JTextField();
		t6.setFont(new Font("굴림", Font.BOLD, 18));
		t6.setColumns(10);
		t6.setBounds(357, 378, 160, 42);
		f.getContentPane().add(t6);
		
		JLabel lblNewLabel_3_4 = new JLabel("전일가");
		lblNewLabel_3_4.setFont(new Font("굴림", Font.BOLD, 20));
		lblNewLabel_3_4.setBounds(27, 430, 74, 42);
		f.getContentPane().add(lblNewLabel_3_4);
		
		JTextField t4 = new JTextField();
		t4.setFont(new Font("굴림", Font.BOLD, 18));
		t4.setColumns(10);
		t4.setBounds(95, 430, 160, 42);
		f.getContentPane().add(t4);
		
		JLabel lblNewLabel_3_5 = new JLabel("거래량");
		lblNewLabel_3_5.setFont(new Font("굴림", Font.BOLD, 20));
		lblNewLabel_3_5.setBounds(289, 430, 74, 42);
		f.getContentPane().add(lblNewLabel_3_5);
		
		JTextField t7 = new JTextField();
		t7.setFont(new Font("굴림", Font.BOLD, 18));
		t7.setColumns(10);
		t7.setBounds(357, 430, 160, 42);
		f.getContentPane().add(t7);
		
		JButton btnNewButton = new JButton("검색");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name =t1.getText();
				for (int j = 0; j < 10; j++) {
					if (total[0][j].equals(name)) {
						t2.setText(total[1][j]);
						t3.setText(total[2][j]);
						t4.setText(total[3][j]);
						t5.setText(total[4][j]);
						t6.setText(total[5][j]);
						t7.setText(total[6][j]);								
					}
				}				
			}
		});
		btnNewButton.setBackground(Color.CYAN);
		btnNewButton.setFont(new Font("굴림", Font.BOLD, 30));
		btnNewButton.setBounds(395, 227, 107, 64);
		f.getContentPane().add(btnNewButton);
		
		
		f.setVisible(true);

//		
			
		
		}//main
	}//class



