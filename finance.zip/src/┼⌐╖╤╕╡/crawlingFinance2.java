package 크롤링;

import java.io.IOException;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class crawlingFinance2 {
	
	// 1.삼성전자  2.한진칼  3.jw 중외제약  4.씨젠. 5.이이치엘비
	// 6.셀트리온  7.국동     8.흥아해운       9.모나미 10.프로스테믹스
	String [] comNum = {"005930", "180640", "001060", "096530", "028300",
						"068270", "005320", "003280", "005360", "203690"};	
	Connection[] conNum = new Connection [10];
	Document[] docNum = new Document [10];
	Elements[] listNum = new Elements [10];
	
	
	public String[] forName(String s) {
		String[] nameList = new String [10];
		for (int i = 0; i < conNum.length; i++) {
			conNum[i] = Jsoup.connect("https://finance.naver.com/item/main.nhn?code=" + comNum[i]);
			try {
				docNum[i] = conNum[i].get();			
				listNum[i] = docNum[i].select(s);				
				System.out.println();
				nameList[i] = listNum[i].get(0).text();					
			} catch (Exception e) {
				System.out.println("예외가 있습니다. 처리하세요");
				e.getStackTrace();
			}
		}
			for (String s1 : nameList) {
				System.out.println(s1);
		}
			return nameList;
	
	}
	
	public String[] forLast(String s) {
		String[] lastList = new String [10];
		for (int i = 0; i < conNum.length; i++) {
			conNum[i] = Jsoup.connect("https://finance.naver.com/item/main.nhn?code=" + comNum[i]);
			try {
				docNum[i] = conNum[i].get();			
				listNum[i] = docNum[i].select(s);				
				System.out.println();
				lastList[i] = listNum[i].get(0).text();				
			} catch (Exception e) {
				System.out.println("예외가 있습니다. 처리하세요");
				e.getStackTrace();
			}
		}
				for (String s1 : lastList) {
					System.out.println(s1);
			}
				return lastList;
	}
	
	public String[] forStart(String s) {
		String[] everyThing = new String [10];
		for (int i = 0; i < conNum.length; i++) {
			conNum[i] = Jsoup.connect("https://finance.naver.com/item/main.nhn?code=" + comNum[i]);
			try {
				docNum[i] = conNum[i].get();			
				listNum[i] = docNum[i].select(s);				
				System.out.println();
//				String [] listTemp = new String[listNum[i].size()];
//				for (int j = 0; j < listTemp.length; j++) {
//					listTemp[j] = listNum[i].get(j).text();	
//				}
				everyThing[i] = listNum[i].get(4).text();		
			} catch (Exception e) {
				System.out.println("예외가 있습니다. 처리하세요");
				e.getStackTrace();
			}
		}	
		for (int i = 0; i < 10; i++) {
			System.out.println(everyThing[i]);
		}
		return everyThing;
	}
	
	public String[] forYester(String s) {
		String[] everyThing = new String [10];
		for (int i = 0; i < conNum.length; i++) {
			conNum[i] = Jsoup.connect("https://finance.naver.com/item/main.nhn?code=" + comNum[i]);
			try {
				docNum[i] = conNum[i].get();			
				listNum[i] = docNum[i].select(s);				
				System.out.println();
//				String [] listTemp = new String[listNum[i].size()];
//				for (int j = 0; j < listTemp.length; j++) {
//					listTemp[j] = listNum[i].get(j).text();	
//				}
				everyThing[i] = listNum[i].get(0).text();		
			} catch (Exception e) {
				System.out.println("예외가 있습니다. 처리하세요");
				e.getStackTrace();
			}
		}	
		for (int i = 0; i < 10; i++) {
			System.out.println(everyThing[i]);
		}
		return everyThing;
	}
	
	public String[] forHigh(String s) {
		String[] everyThing = new String [10];
		for (int i = 0; i < conNum.length; i++) {
			conNum[i] = Jsoup.connect("https://finance.naver.com/item/main.nhn?code=" + comNum[i]);
			try {
				docNum[i] = conNum[i].get();			
				listNum[i] = docNum[i].select(s);				
				System.out.println();
//				String [] listTemp = new String[listNum[i].size()];
//				for (int j = 0; j < listTemp.length; j++) {
//					listTemp[j] = listNum[i].get(j).text();	
//				}
				everyThing[i] = listNum[i].get(1).text();		
			} catch (Exception e) {
				System.out.println("예외가 있습니다. 처리하세요");
				e.getStackTrace();
			}
		}	
		for (int i = 0; i < 10; i++) {
			System.out.println(everyThing[i]);
		}
		return everyThing;
	}
	
	public String[] forLow(String s) {
		String[] everyThing = new String [10];
		for (int i = 0; i < conNum.length; i++) {
			conNum[i] = Jsoup.connect("https://finance.naver.com/item/main.nhn?code=" + comNum[i]);
			try {
				docNum[i] = conNum[i].get();			
				listNum[i] = docNum[i].select(s);				
				System.out.println();
//				String [] listTemp = new String[listNum[i].size()];
//				for (int j = 0; j < listTemp.length; j++) {
//					listTemp[j] = listNum[i].get(j).text();	
//				}
				everyThing[i] = listNum[i].get(5).text();		
			} catch (Exception e) {
				System.out.println("예외가 있습니다. 처리하세요");
				e.getStackTrace();
			}
		}	
		for (int i = 0; i < 10; i++) {
			System.out.println(everyThing[i]);
		}
		return everyThing;
	}
	
	public String[] forQuan(String s) {
		String[] everyThing = new String [10];
		for (int i = 0; i < conNum.length; i++) {
			conNum[i] = Jsoup.connect("https://finance.naver.com/item/main.nhn?code=" + comNum[i]);
			try {
				docNum[i] = conNum[i].get();			
				listNum[i] = docNum[i].select(s);				
				System.out.println();
//				String [] listTemp = new String[listNum[i].size()];
//				for (int j = 0; j < listTemp.length; j++) {
//					listTemp[j] = listNum[i].get(j).text();	
//				}
				everyThing[i] = listNum[i].get(3).text();		
			} catch (Exception e) {
				System.out.println("예외가 있습니다. 처리하세요");
				e.getStackTrace();
			}
		}	
		for (int i = 0; i < 10; i++) {
			System.out.println(everyThing[i]);
		}
		return everyThing;
	}
	
}
