package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;


import com.mysql.fabric.xmlrpc.base.Data;

public class GueDaoCrud {
	
	DaoConn con = new DaoConn();
	Connection con1 =con.conn();
	
	
	public void update(DtoGuest gdto) {
		System.out.println("login이 넘긴 자료 : " + gdto);
		try {
			String s = "update guest set expired_time =?, expired_yn = ?, "
					+ " time_left =?, time_login = ?, seat_num = ?, adult_YN = ? where login_num = ?";			
			PreparedStatement ps = con1.prepareStatement(s);
			SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			java.util.Date time = gdto.getTime_login();
			Timestamp t = Timestamp.valueOf(format1.format(time));	
			System.out.println(t);
			Calendar cal = Calendar.getInstance();
			cal.setTime(t);
			cal.add(Calendar.HOUR, 24);
			System.out.println(cal.getTime());
			java.util.Date time_expired = cal.getTime();
			Timestamp t2 = Timestamp.valueOf(format1.format(time_expired));		
			ps.setTimestamp(1, t2);
			ps.setString(2, gdto.getExpired_YN());
			ps.setLong(3, gdto.getTime_left());
			ps.setTimestamp(4, t);
			ps.setInt(5, gdto.getSeat_num());
			ps.setString(6, gdto.getAdult_YN());
			ps.setInt(7, gdto.getLogin_num());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

	public DtoGuest select(int id) {
		
		String sql = "select * from guest where login_num = ?";
		DtoGuest gdto = null;
		try {
			PreparedStatement ps= con1.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs =ps.executeQuery();
			if(rs.next()){
				gdto = new DtoGuest();
				gdto.setLogin_num(rs.getInt(1));
//				System.out.println(rs.getTimestamp(2));
//				SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//				java.util.Date d = new java.util.Date(rs.getTimestamp(2).getTime());
				gdto.setExpired_time(rs.getTimestamp(2));
				gdto.setExpired_YN(rs.getString(3));
				gdto.setTime_left(rs.getLong(4));
//				java.util.Date d2 = new java.util.Date(rs.getTimestamp(5).getTime());
				gdto.setTime_login(rs.getTimestamp(5));
				gdto.setSeat_num(rs.getInt(6));
				gdto.setAdult_YN(rs.getString(7));
				System.out.println("select : " + gdto);
				}else {
				 System.out.println("게스트 셀렉트 함수가 자료가 없습니다.");
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return gdto;
	}	
	
	public ArrayList<DtoGuest> select() {
		
		String sql = "select * from guest";
		DtoGuest gdto = null;
		ArrayList<DtoGuest> list = null;
		try {
			PreparedStatement ps= con1.prepareStatement(sql);
			ResultSet rs =ps.executeQuery();
			list = new ArrayList<DtoGuest>();
			while(rs.next()) {
				gdto = new DtoGuest();				
				gdto.setLogin_num(rs.getInt(1));
				gdto.setExpired_time(rs.getTimestamp(2));
				gdto.setExpired_YN(rs.getString(3));
				gdto.setTime_left(rs.getLong(4));
				gdto.setTime_login(rs.getTimestamp(5));
				gdto.setSeat_num(rs.getInt(6));
				gdto.setAdult_YN(rs.getString(7));
				System.out.println("select : " + gdto);
				list.add(gdto);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}	
	
	public Boolean read_for_id(int choice) { // id를 검색하는 메서드			
		try {
			String s = "select * from guest";			
			PreparedStatement ps = con1.prepareStatement(s);
			ResultSet rs = ps.executeQuery(); //읽어들일때는 ResultSet과 아래를 쓴다.
			while(rs.next()) {
				if(rs.getInt("login_num") == choice) {
					System.out.println("id check true");
					return true;
					
				}
			}				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("id check false");
		return false;
	}
	
	public int read_for_time_left(int choice) {
		int result = 0;
		String sql = "select * from guest where id = ?";
		PreparedStatement ps;
		try {
			ps = con1.prepareStatement(sql);
			ps.setInt(1, choice);
			ResultSet rs =ps.executeQuery();
			if(rs.next()) {
				result = rs.getInt(4);
			}else {
				System.out.println("데이터를 불러오는데 실패했습니다.");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}
}
