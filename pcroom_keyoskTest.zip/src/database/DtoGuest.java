package database;

import java.util.Calendar;
import java.util.Date;

public class DtoGuest {
	public int login_num;
	public Date expired_time;
	public String expired_YN;
	public long time_left;
	public Date time_login;
	public int seat_num;
	public String adult_YN;
	
	
	public int getLogin_num() {
		return login_num;
	}


	public void setLogin_num(int login_num) {
		this.login_num = login_num;
	}


	public Date getExpired_time() {
		return expired_time;
	}


	public void setExpired_time(Date expired_time) {
		this.expired_time = expired_time;
	}


	public String getExpired_YN() {
		return expired_YN;
	}


	public void setExpired_YN(String expired_YN) {
		this.expired_YN = expired_YN;
	}


	public long getTime_left() {
		return time_left;
	}


	public void setTime_left(long time_left) {
		this.time_left = time_left;
	}


	public Date getTime_login() {
		return time_login;
	}


	public void setTime_login(Date time_login) {
		this.time_login = time_login;
	}


	public int getSeat_num() {
		return seat_num;
	}


	public void setSeat_num(int seat_num) {
		this.seat_num = seat_num;
	}


	public String getAdult_YN() {
		return adult_YN;
	}


	public void setAdult_YN(String adult_YN) {
		this.adult_YN = adult_YN;
	}


	@Override
	public String toString() {
		return "DtoGuest [login_num=" + login_num + ", expired_time=" + expired_time + ", expired_YN=" + expired_YN
				+ ", time_left=" + time_left + ", time_login=" + time_login + ", seat_num=" + seat_num + ", adult_YN="
				+ adult_YN + "]";
	}
	
	
	
	
	
}
