package user_join;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.stream.IntStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import control.CheckSeat;
import database.DtoMember;
import database.MemDaoCrud;

public class SeatsGraphic2 {

	static JFrame fFirst = null;
	int num =0;

	/**
	 * @wbp.parser.entryPoint
	 */
	public void seatsgraphic(DtoMember dto) {

		if (dto == null) {
			seats();
		} else {
			seats2(dto);
		}

	}

	public void seats() {
		fFirst = new JFrame();
		MemDaoCrud dao = new MemDaoCrud();
		ArrayList<DtoMember> dtoList = dao.select();
		int[] seatNum = new int[dtoList.size()];
		
		for (int i = 0; i < dtoList.size(); i++) {
			seatNum[i] = dtoList.get(i).getSeat_num();
			System.out.println(seatNum[i]);
		}


		
		
		fFirst.setSize(564, 420);
		fFirst.getContentPane().setLayout(null);
		SeatPopup sp = new SeatPopup();
		
//		Arrays.stream(배열).anyMatch(특정 값::equals);
//		(equals 외에 String 의 다른 메소드도 사용이 가능하다.)
//		IntStream.of(배열).anyMatch(x -> x == 특정 숫자);
		
		JButton[] button_list = new JButton[16];
		
		for(num = 0; num < button_list.length; num++) {
			System.out.println(num);
			String number = Integer.toString(num+1);
			
			button_list[num] = new JButton(number);
			
			button_list[num].addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					if(IntStream.of(seatNum).anyMatch(x -> x == (num+1))) {
						JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
					}else {
						JButton button = button_list[num];
						sp.popup(button, num+1, fFirst); // button 자체를 넘겨준다.
					}
					
				}
			});
		}
		
				
		
		
		button_list[1].setBackground(Color.LIGHT_GRAY);
		button_list[1].setBounds(121, 45, 97, 62);
		fFirst.getContentPane().add(button_list[1]);

		
		button_list[2].setBackground(Color.LIGHT_GRAY);
		button_list[2].setBounds(12, 117, 97, 62);
		fFirst.getContentPane().add(button_list[2]);

		
		button_list[3].setBackground(Color.LIGHT_GRAY);
		button_list[3].setBounds(121, 117, 97, 62);
		fFirst.getContentPane().add(button_list[3]);

		
		button_list[4].setBackground(Color.LIGHT_GRAY);
		button_list[4].setBounds(12, 189, 97, 62);
		fFirst.getContentPane().add(button_list[4]);

		
		button_list[5].setBackground(Color.LIGHT_GRAY);
		button_list[5].setBounds(121, 189, 97, 62);
		fFirst.getContentPane().add(button_list[5]);

		
		button_list[6].setBackground(Color.LIGHT_GRAY);
		button_list[6].setBounds(12, 261, 97, 62);
		fFirst.getContentPane().add(button_list[6]);

		
		button_list[7].setBackground(Color.LIGHT_GRAY);
		button_list[7].setBounds(121, 261, 97, 62);
		fFirst.getContentPane().add(button_list[7]);

		
		button_list[8].setBackground(Color.LIGHT_GRAY);
		button_list[8].setBounds(330, 45, 97, 62);
		fFirst.getContentPane().add(button_list[8]);

		
		button_list[9].setBackground(Color.LIGHT_GRAY);
		button_list[9].setBounds(439, 45, 97, 62);
		fFirst.getContentPane().add(button_list[9], fFirst);

		button_list[10].setBackground(Color.LIGHT_GRAY);
		button_list[10].setBounds(330, 117, 97, 62);
		fFirst.getContentPane().add(button_list[10]);
		
		button_list[11].setBackground(Color.LIGHT_GRAY);
		button_list[11].setBounds(439, 117, 97, 62);
		fFirst.getContentPane().add(button_list[11]);

		button_list[12].setBackground(Color.LIGHT_GRAY);
		button_list[12].setBounds(330, 189, 97, 62);
		fFirst.getContentPane().add(button_list[12]);

		
		button_list[13].setBackground(Color.LIGHT_GRAY);
		button_list[13].setBounds(439, 189, 97, 62);
		fFirst.getContentPane().add(button_list[13]);

		
		button_list[14].setBackground(Color.LIGHT_GRAY);
		button_list[14].setBounds(330, 261, 97, 62);
		fFirst.getContentPane().add(button_list[14]);

		button_list[15].setBackground(Color.LIGHT_GRAY);
		button_list[15].setBounds(439, 261, 97, 62);
		fFirst.getContentPane().add(button_list[15]);
		
		for (int i : seatNum) {
			if(i == 0) {
				System.out.println("자리가 0번입니다.");
			}else {
				button_list[i -1].setBackground(Color.BLUE);
			}
		}
		

		
		fFirst.setVisible(true);
	}

	/////////////////////////////////////////////////////////
	public void seats2(DtoMember dto) { // 로그인후 자리변경하기
		System.out.println("자리함수" + dto);
		int seatNum = dto.getSeat_num();
		JFrame f = new JFrame();
		f.setSize(564, 420);
		f.getContentPane().setLayout(null);
		SeatPopup sp = new SeatPopup();
		CheckSeat cs = new CheckSeat();

		JButton[] button_list = new JButton[16];
		for (int i = 0; i < button_list.length; i++) {
			String j = Integer.toString(i + 1);
			button_list[i] = new JButton(j);
		}

		button_list[0].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				cs.checkseat(f, 1, seatNum, dto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
			}
		});
		button_list[0].setBackground(Color.LIGHT_GRAY);
		button_list[0].setBounds(12, 45, 97, 62);
		f.getContentPane().add(button_list[0]);

		button_list[1].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f, 2, seatNum, dto, sp);
			}
		});
		button_list[1].setBackground(Color.LIGHT_GRAY);
		button_list[1].setBounds(121, 45, 97, 62);
		f.getContentPane().add(button_list[1]);

		button_list[2] = new JButton("3");
		button_list[2].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f, 3, seatNum, dto, sp);
			}
		});
		button_list[2].setBackground(Color.LIGHT_GRAY);
		button_list[2].setBounds(12, 117, 97, 62);
		f.getContentPane().add(button_list[2]);

		button_list[3].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f, 4, seatNum, dto, sp);
			}
		});
		button_list[3].setBackground(Color.LIGHT_GRAY);
		button_list[3].setBounds(121, 117, 97, 62);
		f.getContentPane().add(button_list[3]);

		button_list[4].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f, 5, seatNum, dto, sp);
			}
		});
		button_list[4].setBackground(Color.LIGHT_GRAY);
		button_list[4].setBounds(12, 189, 97, 62);
		f.getContentPane().add(button_list[4]);

		button_list[5].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f, 6, seatNum, dto, sp);
			}
		});
		button_list[5].setBackground(Color.LIGHT_GRAY);
		button_list[5].setBounds(121, 189, 97, 62);
		f.getContentPane().add(button_list[5]);

		button_list[6].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f, 7, seatNum, dto, sp);
			}

		});
		button_list[6].setBackground(Color.LIGHT_GRAY);
		button_list[6].setBounds(12, 261, 97, 62);
		f.getContentPane().add(button_list[6]);

		button_list[7].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f, 7, seatNum, dto, sp);
			}
		});
		button_list[7].setBackground(Color.LIGHT_GRAY);
		button_list[7].setBounds(121, 261, 97, 62);
		f.getContentPane().add(button_list[7]);

		button_list[8].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f, 9, seatNum, dto, sp);
			}
		});
		button_list[8].setBackground(Color.LIGHT_GRAY);
		button_list[8].setBounds(330, 45, 97, 62);
		f.getContentPane().add(button_list[8]);

		button_list[9].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f, 10, seatNum, dto, sp);
			}
		});
		button_list[9].setBackground(Color.LIGHT_GRAY);
		button_list[9].setBounds(439, 45, 97, 62);
		f.getContentPane().add(button_list[9], f);

		button_list[10] = new JButton("11");
		button_list[10].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f, 11, seatNum, dto, sp);
			}
		});
		button_list[10].setBackground(Color.LIGHT_GRAY);
		button_list[10].setBounds(330, 117, 97, 62);
		f.getContentPane().add(button_list[10]);

		button_list[11].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f, 12, seatNum, dto, sp);
			}
		});
		button_list[11].setBackground(Color.LIGHT_GRAY);
		button_list[11].setBounds(439, 117, 97, 62);
		f.getContentPane().add(button_list[11]);

		button_list[12].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f, 13, seatNum, dto, sp);
			}
		});
		button_list[12].setBackground(Color.LIGHT_GRAY);
		button_list[12].setBounds(330, 189, 97, 62);
		f.getContentPane().add(button_list[12]);

		button_list[13].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f, 14, seatNum, dto, sp);
			}
		});
		button_list[13].setBackground(Color.LIGHT_GRAY);
		button_list[13].setBounds(439, 189, 97, 62);
		f.getContentPane().add(button_list[13]);

		button_list[14].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f, 15, seatNum, dto, sp);
			}
		});
		button_list[14].setBackground(Color.LIGHT_GRAY);
		button_list[14].setBounds(330, 261, 97, 62);
		f.getContentPane().add(button_list[14]);

		button_list[15].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cs.checkseat(f, 16, seatNum, dto, sp);
			}
		});
		button_list[15].setBackground(Color.LIGHT_GRAY);
		button_list[15].setBounds(439, 261, 97, 62);
		f.getContentPane().add(button_list[15]);

		button_list[seatNum - 1].setBackground(Color.BLUE);

		f.setVisible(true);
	}

}
