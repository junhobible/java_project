package user_join;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import database.DtoGuest;
import database.DtoMember;
import database.GueDaoCrud;
import database.MemDaoCrud;

public class SeatPopup {
	/**
	 * @wbp.parser.entryPoint
	 */
	
	MemDaoCrud dao = new MemDaoCrud();
	public void popup(JButton button, int seatNum, JFrame j) {

		JFrame f = new JFrame();
		f.setSize(451, 160);
		f.setLocation(200, 200);
		Login log = new Login();
		f.getContentPane().setLayout(null);
		JButton b1 = new JButton("yes");
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				log.login(button, seatNum, j);
				f.dispose();

			}
		});
		b1.setBounds(104, 60, 89, 36);
		f.getContentPane().add(b1);

		JButton b2 = new JButton("no");
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String result = b2.getText();
				System.out.println(result);
				f.dispose();
			}
		});
		b2.setBounds(245, 60, 89, 36);
		f.getContentPane().add(b2);

		JLabel lblNewLabel = new JLabel("좌석을 선택하시겠습니까?");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(26, 22, 386, 28);
		f.getContentPane().add(lblNewLabel);

		f.setVisible(true);
	}

	public void popup2(JFrame j, DtoMember dto) {
		
	JFrame f = new JFrame();
	f.setSize(451, 160);
	f.setLocation(1300, 200);
	Login log = new Login();
	f.getContentPane().setLayout(null);
	JButton b1 = new JButton("yes");
	b1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {					
				UserInter ui = new UserInter();
				
				dao.update(dto);
				SeatsGraphic.fFirst.dispose();
				SeatsGraphic sg = new SeatsGraphic();
				DtoMember dto_temp = null;

				sg.seatsgraphic(dto_temp);
				ui.userInter(dto, j);
				j.dispose();
				f.dispose();
		}
	});
	b1.setBounds(104, 60, 89, 36);
	f.getContentPane().add(b1);
	
	JButton b2 = new JButton("no");
	b2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			String result = b2.getText();
			System.out.println(result);
			f.dispose();
		}
	});
	b2.setBounds(245, 60, 89, 36);
	f.getContentPane().add(b2);
	
	JLabel lblNewLabel = new JLabel("좌석을 선택하시겠습니까?");
	lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
	lblNewLabel.setBounds(26, 22, 386, 28);
	f.getContentPane().add(lblNewLabel);
	
	
	f.setVisible(true);
}
	
	public void popup2(JFrame j, DtoGuest gdto) { // 게스트용 다형성
		
		JFrame f = new JFrame();
		GueDaoCrud gdao = new GueDaoCrud();
		f.setSize(451, 160);
		f.setLocation(1300, 200);
		Login log = new Login();
		f.getContentPane().setLayout(null);
		JButton b1 = new JButton("yes");
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {					
					UserInter ui = new UserInter();
					
					gdao.update(gdto);
					SeatsGraphic.fFirst.dispose();
					SeatsGraphic sg = new SeatsGraphic();
					  DtoMember dto_temp = null;

					sg.seatsgraphic(dto_temp);
					ui.userInter(gdto, j);
					j.dispose();
					f.dispose();
			}
		});
		b1.setBounds(104, 60, 89, 36);
		f.getContentPane().add(b1);
		
		JButton b2 = new JButton("no");
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String result = b2.getText();
				System.out.println(result);
				f.dispose();
			}
		});
		b2.setBounds(245, 60, 89, 36);
		f.getContentPane().add(b2);
		
		JLabel lblNewLabel = new JLabel("좌석을 선택하시겠습니까?");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(26, 22, 386, 28);
		f.getContentPane().add(lblNewLabel);
		
		
		f.setVisible(true);
	}
}
