package project;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.SwingConstants;

import dbprocess.MemberDTO;

public class Manager {
	public  void goManager() {
		JFrame f = new JFrame();
		f.getContentPane().setBackground(Color.DARK_GRAY);
		f.setSize(500, 450);
		f.setLocation(1050, 0);
		f.getContentPane().setLayout(null);
		f.setTitle("관리자 화면");
		f.setResizable(false);
		User user = new User();
		MemberDTO dto = new MemberDTO();
		BlackList bl_list = new BlackList();
		PasswordInit init_pw = new PasswordInit();
		NonAdult ad = new NonAdult();

		JButton b1 = new JButton("1");
		b1.setBackground(Color.WHITE);
		b1.setVerticalAlignment(SwingConstants.TOP);
		b1.setHorizontalAlignment(SwingConstants.LEFT);
		b1.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		b1.setBounds(30, 75, 88, 55);

		f.getContentPane().add(b1);

		JButton b5 = new JButton("5");
		b5.setBackground(Color.WHITE);
		b5.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		b5.setVerticalAlignment(SwingConstants.TOP);
		b5.setHorizontalAlignment(SwingConstants.LEFT);
		b5.setBounds(123, 75, 88, 55);
		f.getContentPane().add(b5);

		JButton b2 = new JButton("2");
		b2.setBackground(Color.WHITE);
		b2.setVerticalAlignment(SwingConstants.TOP);
		b2.setHorizontalAlignment(SwingConstants.LEFT);
		b2.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		b2.setBounds(30, 140, 88, 55);
		f.getContentPane().add(b2);

		JButton b6 = new JButton("6");
		b6.setBackground(Color.WHITE);
		b6.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		b6.setVerticalAlignment(SwingConstants.TOP);
		b6.setHorizontalAlignment(SwingConstants.LEFT);
		b6.setBounds(123, 140, 88, 55);
		f.getContentPane().add(b6);

		JButton b3 = new JButton("3");
		b3.setBackground(Color.WHITE);
		b3.setVerticalAlignment(SwingConstants.TOP);
		b3.setHorizontalAlignment(SwingConstants.LEFT);
		b3.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		b3.setBounds(30, 205, 88, 55);
		f.getContentPane().add(b3);

		JButton b7 = new JButton("7");
		b7.setBackground(Color.WHITE);
		b7.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		b7.setVerticalAlignment(SwingConstants.TOP);
		b7.setHorizontalAlignment(SwingConstants.LEFT);
		b7.setBounds(123, 205, 88, 55);
		f.getContentPane().add(b7);

		JButton b4 = new JButton("4");
		b4.setBackground(Color.WHITE);
		b4.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		b4.setVerticalAlignment(SwingConstants.TOP);
		b4.setHorizontalAlignment(SwingConstants.LEFT);
		b4.setBounds(30, 270, 88, 55);
		f.getContentPane().add(b4);

		JButton b8 = new JButton("8");
		b8.setBackground(Color.WHITE);
		b8.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		b8.setVerticalAlignment(SwingConstants.TOP);
		b8.setHorizontalAlignment(SwingConstants.LEFT);
		b8.setBounds(123, 270, 88, 55);
		f.getContentPane().add(b8);

		JButton b9 = new JButton("9");
		b9.setBackground(Color.WHITE);
		b9.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		b9.setVerticalAlignment(SwingConstants.TOP);
		b9.setHorizontalAlignment(SwingConstants.LEFT);
		b9.setBounds(265, 75, 88, 55);
		f.getContentPane().add(b9);

		JButton b13 = new JButton("13");
		b13.setBackground(Color.WHITE);
		b13.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		b13.setVerticalAlignment(SwingConstants.TOP);
		b13.setHorizontalAlignment(SwingConstants.LEFT);
		b13.setBounds(365, 75, 88, 55);
		f.getContentPane().add(b13);

		JButton b10 = new JButton("10");
		b10.setBackground(Color.WHITE);
		b10.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		b10.setVerticalAlignment(SwingConstants.TOP);
		b10.setHorizontalAlignment(SwingConstants.LEFT);
		b10.setBounds(265, 140, 88, 55);
		f.getContentPane().add(b10);

		JButton b14 = new JButton("14");
		b14.setBackground(Color.WHITE);
		b14.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		b14.setVerticalAlignment(SwingConstants.TOP);
		b14.setHorizontalAlignment(SwingConstants.LEFT);
		b14.setBounds(365, 140, 88, 55);
		f.getContentPane().add(b14);

		JButton b11 = new JButton("11");
		b11.setBackground(Color.WHITE);
		b11.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		b11.setVerticalAlignment(SwingConstants.TOP);
		b11.setHorizontalAlignment(SwingConstants.LEFT);
		b11.setBounds(265, 205, 88, 55);
		f.getContentPane().add(b11);

		JButton b15 = new JButton("15");
		b15.setBackground(Color.WHITE);
		b15.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		b15.setVerticalAlignment(SwingConstants.TOP);
		b15.setHorizontalAlignment(SwingConstants.LEFT);
		b15.setBounds(365, 205, 88, 55);
		f.getContentPane().add(b15);

		JButton b12 = new JButton("12");
		b12.setBackground(Color.WHITE);
		b12.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		b12.setVerticalAlignment(SwingConstants.TOP);
		b12.setHorizontalAlignment(SwingConstants.LEFT);
		b12.setBounds(265, 270, 88, 55);
		f.getContentPane().add(b12);

		JButton b16 = new JButton("16");
		b16.setBackground(Color.WHITE);
		b16.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		b16.setVerticalAlignment(SwingConstants.TOP);
		b16.setHorizontalAlignment(SwingConstants.LEFT);
		b16.setBounds(365, 270, 88, 55);
		f.getContentPane().add(b16);

		JButton b_black = new JButton("<html>블랙리스트<br />관리</html>");
		b_black.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bl_list.black_list();
			}
		});
		b_black.setForeground(Color.BLACK);
		b_black.setFont(new Font("맑은 고딕", Font.BOLD, 9));
		b_black.setBackground(Color.LIGHT_GRAY);
		b_black.setBounds(365, 335, 83, 46);
		f.getContentPane().add(b_black);

		JButton b_pw = new JButton("<html>비밀번호<br />초기화</html>");
		b_pw.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				init_pw.init();
			}
		});
		b_pw.setForeground(Color.BLACK);
		b_pw.setFont(new Font("맑은 고딕", Font.BOLD, 10));
		b_pw.setBackground(Color.LIGHT_GRAY);
		b_pw.setBounds(270, 335, 83, 46);
		f.getContentPane().add(b_pw);

		JButton b_pw_1 = new JButton("<html>미성년자<br />해제</html>");
		b_pw_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ad.adult();
			}
		});
		b_pw_1.setForeground(Color.BLACK);
		b_pw_1.setFont(new Font("맑은 고딕", Font.BOLD, 10));
		b_pw_1.setBackground(Color.LIGHT_GRAY);
		b_pw_1.setBounds(175, 335, 83, 46);
		f.getContentPane().add(b_pw_1);

		dto.setB1(b1);
		dto.setB2(b2);
		dto.setB3(b3);
		dto.setB4(b4);
		dto.setB5(b5);
		dto.setB6(b6);
		dto.setB7(b7);
		dto.setB8(b8);
		dto.setB9(b9);
		dto.setB10(b10);
		dto.setB11(b11);
		dto.setB12(b12);
		dto.setB13(b13);
		dto.setB14(b14);
		dto.setB15(b15);
		dto.setB16(b16);
		user.user(dto);
		f.setVisible(true);
	}
}
