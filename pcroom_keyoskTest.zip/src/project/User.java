package project;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import dbprocess.MemberDAO;
import dbprocess.MemberDTO;

public class User {

	public void user(MemberDTO dto) {
		JFrame f = new JFrame();
		f.getContentPane().setBackground(Color.DARK_GRAY);
		f.setSize(500, 450);
		f.getContentPane().setLayout(null);
		f.setLocation(500, 0);
		f.setTitle("이용자 화면");
		f.setResizable(false);
		Login log = new Login();
		MemberDAO m_dao = new MemberDAO();

		JButton button1 = new JButton("1");
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number = "1";
				int number2 = 1;
				JButton button = button1;
				JButton button2 = dto.getB1();
				ArrayList seat_number = new ArrayList();
				seat_number = m_dao.search_seat();
				if (seat_number.contains(number2)) {
					JOptionPane.showMessageDialog(null, "이미 사용중인 자리입니다.");
				} else {
					log.logIn(number, button, button2);
				}

			}
		});
		button1.setVerticalAlignment(SwingConstants.TOP);
		button1.setHorizontalAlignment(SwingConstants.LEFT);
		button1.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		button1.setBounds(30, 75, 88, 55);
		f.getContentPane().add(button1);

		JButton button2 = new JButton("2");
		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number = "2";
				int number2 = 2;
				JButton button = button2;
				JButton button2 = dto.getB2();
				ArrayList seat_number = new ArrayList();
				seat_number = m_dao.search_seat();
				if (seat_number.contains(number2)) {
					JOptionPane.showMessageDialog(null, "이미 사용중인 자리입니다.");
				} else {
					log.logIn(number, button, button2);
				}
			}
		});
		button2.setVerticalAlignment(SwingConstants.TOP);
		button2.setHorizontalAlignment(SwingConstants.LEFT);
		button2.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		button2.setBounds(30, 140, 88, 55);
		f.getContentPane().add(button2);

		JButton button3 = new JButton("3");
		button3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number = "3";
				int number2 = 3;
				JButton button = button3;
				JButton button2 = dto.getB3();
				ArrayList seat_number = new ArrayList();
				seat_number = m_dao.search_seat();
				if (seat_number.contains(number2)) {
					JOptionPane.showMessageDialog(null, "이미 사용중인 자리입니다.");
				} else {
					log.logIn(number, button, button2);
				}
			}
		});
		button3.setVerticalAlignment(SwingConstants.TOP);
		button3.setHorizontalAlignment(SwingConstants.LEFT);
		button3.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		button3.setBounds(30, 205, 88, 55);
		f.getContentPane().add(button3);

		JButton button4 = new JButton("4");
		button4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number = "4";
				int number2 = 4;
				JButton button = button4;
				JButton button2 = dto.getB4();
				ArrayList seat_number = new ArrayList();
				seat_number = m_dao.search_seat();
				if (seat_number.contains(number2)) {
					JOptionPane.showMessageDialog(null, "이미 사용중인 자리입니다.");
				} else {
					log.logIn(number, button, button2);
				}
			}
		});
		button4.setVerticalAlignment(SwingConstants.TOP);
		button4.setHorizontalAlignment(SwingConstants.LEFT);
		button4.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		button4.setBounds(30, 270, 88, 55);
		f.getContentPane().add(button4);

		JButton button5 = new JButton("5");
		button5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number = "5";
				int number2 = 5;
				JButton button = button5;
				JButton button2 = dto.getB5();
				ArrayList seat_number = new ArrayList();
				seat_number = m_dao.search_seat();
				if (seat_number.contains(number2)) {
					JOptionPane.showMessageDialog(null, "이미 사용중인 자리입니다.");
				} else {
					log.logIn(number, button, button2);
				}
			}
		});
		button5.setVerticalAlignment(SwingConstants.TOP);
		button5.setHorizontalAlignment(SwingConstants.LEFT);
		button5.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		button5.setBounds(130, 75, 88, 55);
		f.getContentPane().add(button5);

		JButton button6 = new JButton("6");
		button6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number = "6";
				int number2 = 6;
				JButton button = button6;
				JButton button2 = dto.getB6();
				ArrayList seat_number = new ArrayList();
				seat_number = m_dao.search_seat();
				if (seat_number.contains(number2)) {
					JOptionPane.showMessageDialog(null, "이미 사용중인 자리입니다.");
				} else {
					log.logIn(number, button, button2);
				}
			}
		});
		button6.setVerticalAlignment(SwingConstants.TOP);
		button6.setHorizontalAlignment(SwingConstants.LEFT);
		button6.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		button6.setBounds(130, 142, 88, 55);
		f.getContentPane().add(button6);

		JButton button7 = new JButton("7");
		button7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number = "7";
				int number2 = 7;
				JButton button = button7;
				JButton button2 = dto.getB7();
				ArrayList seat_number = new ArrayList();
				seat_number = m_dao.search_seat();
				if (seat_number.contains(number2)) {
					JOptionPane.showMessageDialog(null, "이미 사용중인 자리입니다.");
				} else {
					log.logIn(number, button, button2);
				}
			}
		});
		button7.setVerticalAlignment(SwingConstants.TOP);
		button7.setHorizontalAlignment(SwingConstants.LEFT);
		button7.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		button7.setBounds(130, 207, 88, 55);
		f.getContentPane().add(button7);

		JButton button8 = new JButton("8");
		button8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number = "8";
				int number2 = 8;
				JButton button = button8;
				JButton button2 = dto.getB8();
				ArrayList seat_number = new ArrayList();
				seat_number = m_dao.search_seat();
				if (seat_number.contains(number2)) {
					JOptionPane.showMessageDialog(null, "이미 사용중인 자리입니다.");
				} else {
					log.logIn(number, button, button2);
				}
			}
		});
		button8.setVerticalAlignment(SwingConstants.TOP);
		button8.setHorizontalAlignment(SwingConstants.LEFT);
		button8.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		button8.setBounds(130, 272, 88, 55);
		f.getContentPane().add(button8);

		JButton button9 = new JButton("9");
		button9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number = "9";
				int number2 = 9;
				JButton button = button9;
				JButton button2 = dto.getB9();
				ArrayList seat_number = new ArrayList();
				seat_number = m_dao.search_seat();
				if (seat_number.contains(number2)) {
					JOptionPane.showMessageDialog(null, "이미 사용중인 자리입니다.");
				} else {
					log.logIn(number, button, button2);
				}
			}
		});
		button9.setVerticalAlignment(SwingConstants.TOP);
		button9.setHorizontalAlignment(SwingConstants.LEFT);
		button9.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		button9.setBounds(265, 75, 88, 55);
		f.getContentPane().add(button9);

		JButton button10 = new JButton("10");
		button10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number = "10";
				int number2 = 10;
				JButton button = button10;
				JButton button2 = dto.getB10();
				ArrayList seat_number = new ArrayList();
				seat_number = m_dao.search_seat();
				if (seat_number.contains(number2)) {
					JOptionPane.showMessageDialog(null, "이미 사용중인 자리입니다.");
				} else {
					log.logIn(number, button, button2);
				}
			}
		});
		button10.setVerticalAlignment(SwingConstants.TOP);
		button10.setHorizontalAlignment(SwingConstants.LEFT);
		button10.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		button10.setBounds(265, 140, 88, 55);
		f.getContentPane().add(button10);

		JButton button11 = new JButton("11");
		button11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number = "11";
				int number2 = 11;
				JButton button = button11;
				JButton button2 = dto.getB11();
				ArrayList seat_number = new ArrayList();
				seat_number = m_dao.search_seat();
				if (seat_number.contains(number2)) {
					JOptionPane.showMessageDialog(null, "이미 사용중인 자리입니다.");
				} else {
					log.logIn(number, button, button2);
				}
			}
		});
		button11.setVerticalAlignment(SwingConstants.TOP);
		button11.setHorizontalAlignment(SwingConstants.LEFT);
		button11.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		button11.setBounds(265, 205, 88, 55);
		f.getContentPane().add(button11);

		JButton button12 = new JButton("12");
		button12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number = "12";
				int number2 = 12;
				JButton button = button12;
				JButton button2 = dto.getB12();
				ArrayList seat_number = new ArrayList();
				seat_number = m_dao.search_seat();
				if (seat_number.contains(number2)) {
					JOptionPane.showMessageDialog(null, "이미 사용중인 자리입니다.");
				} else {
					log.logIn(number, button, button2);
				}
			}
		});
		button12.setVerticalAlignment(SwingConstants.TOP);
		button12.setHorizontalAlignment(SwingConstants.LEFT);
		button12.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		button12.setBounds(265, 270, 88, 55);
		f.getContentPane().add(button12);

		JButton button13 = new JButton("13");
		button13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number = "13";
				int number2 = 13;
				JButton button = button13;
				JButton button2 = dto.getB13();
				ArrayList seat_number = new ArrayList();
				seat_number = m_dao.search_seat();
				if (seat_number.contains(number2)) {
					JOptionPane.showMessageDialog(null, "이미 사용중인 자리입니다.");
				} else {
					log.logIn(number, button, button2);
				}
			}
		});
		button13.setVerticalAlignment(SwingConstants.TOP);
		button13.setHorizontalAlignment(SwingConstants.LEFT);
		button13.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		button13.setBounds(365, 75, 88, 55);
		f.getContentPane().add(button13);

		JButton button14 = new JButton("14");
		button14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number = "14";
				int number2 = 14;
				JButton button = button14;
				JButton button2 = dto.getB14();
				ArrayList seat_number = new ArrayList();
				seat_number = m_dao.search_seat();
				if (seat_number.contains(number2)) {
					JOptionPane.showMessageDialog(null, "이미 사용중인 자리입니다.");
				} else {
					log.logIn(number, button, button2);
				}
			}
		});
		button14.setVerticalAlignment(SwingConstants.TOP);
		button14.setHorizontalAlignment(SwingConstants.LEFT);
		button14.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		button14.setBounds(365, 140, 88, 55);
		f.getContentPane().add(button14);

		JButton button15 = new JButton("15");
		button15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number = "15";
				int number2 = 15;
				JButton button = button15;
				JButton button2 = dto.getB15();
				ArrayList seat_number = new ArrayList();
				seat_number = m_dao.search_seat();
				if (seat_number.contains(number2)) {
					JOptionPane.showMessageDialog(null, "이미 사용중인 자리입니다.");
				} else {
					log.logIn(number, button, button2);
				}
			}
		});
		button15.setVerticalAlignment(SwingConstants.TOP);
		button15.setHorizontalAlignment(SwingConstants.LEFT);
		button15.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		button15.setBounds(365, 205, 88, 55);
		f.getContentPane().add(button15);

		JButton button16 = new JButton("16");
		button16.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String number = "16";
				int number2 = 16;
				JButton button = button16;
				JButton button2 = dto.getB16();
				ArrayList seat_number = new ArrayList();
				seat_number = m_dao.search_seat();
				if (seat_number.contains(number2)) {
					JOptionPane.showMessageDialog(null, "이미 사용중인 자리입니다.");
				} else {
					log.logIn(number, button, button2);
				}
			}
		});
		button16.setVerticalAlignment(SwingConstants.TOP);
		button16.setHorizontalAlignment(SwingConstants.LEFT);
		button16.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		button16.setBounds(365, 270, 88, 55);
		f.getContentPane().add(button16);

		f.setVisible(true);

	}

}
