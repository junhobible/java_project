package project;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import dbprocess.MemberDAO;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;

public class MemberInfo {
	static String name2;
	public void inform(String number, String name, String id, String birth, String time_left) {
		JFrame f = new JFrame();
		f.setTitle("회원 정보");
		f.setLocation(1150, 50);
		f.getContentPane().setBackground(Color.BLUE);
		f.setSize(300, 380);
		f.getContentPane().setLayout(null);
		f.setResizable(false);
		MemberDAO m_dao = new MemberDAO();
		String gender = m_dao.check_gender(id);
		if(gender.equals("M")) {
			String gender2="♂";
			name2=name+"("+gender2+")";
		}
		else if(gender.equals("F")) {
			String gender2="♀";
			name2=name+"("+gender2+")";
		}
		
		
		JLabel lblNewLabel = new JLabel("좌석번호");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("맑은 고딕", Font.BOLD, 15));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(27, 25, 81, 35);
		f.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("이름");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("맑은 고딕", Font.BOLD, 15));
		lblNewLabel_1.setBounds(27, 70, 81, 35);
		f.getContentPane().add(lblNewLabel_1);

		JLabel lblId = new JLabel("ID");
		lblId.setHorizontalAlignment(SwingConstants.CENTER);
		lblId.setForeground(Color.WHITE);
		lblId.setFont(new Font("맑은 고딕", Font.BOLD, 15));
		lblId.setBounds(27, 115, 81, 35);
		f.getContentPane().add(lblId);

		JLabel lblNewLabel_3 = new JLabel("생년월일");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setFont(new Font("맑은 고딕", Font.BOLD, 15));
		lblNewLabel_3.setBounds(27, 160, 81, 35);
		f.getContentPane().add(lblNewLabel_3);

		JLabel lblNewLabel_3_1 = new JLabel("남은 시간");
		lblNewLabel_3_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_1.setForeground(Color.WHITE);
		lblNewLabel_3_1.setFont(new Font("맑은 고딕", Font.BOLD, 15));
		lblNewLabel_3_1.setBounds(17, 229, 103, 40);
		f.getContentPane().add(lblNewLabel_3_1);

		JButton bt_author = new JButton("강제 종료");
		bt_author.setFont(new Font("맑은 고딕", Font.BOLD, 14));
		bt_author.setBounds(98, 294, 115, 37);
		f.getContentPane().add(bt_author);

		JPanel panel = new JPanel();
		panel.setBounds(117, 32, 128, 25);
		f.getContentPane().add(panel);

		JLabel l_seat = new JLabel(number);
		l_seat.setFont(new Font("맑은 고딕", Font.BOLD, 13));
		panel.add(l_seat);

		JPanel panel_1 = new JPanel();
		panel_1.setBounds(117, 77, 128, 25);
		f.getContentPane().add(panel_1);

		JLabel l_name = new JLabel(name2);
		l_name.setFont(new Font("맑은 고딕", Font.BOLD, 13));
		panel_1.add(l_name);

		JPanel panel_2 = new JPanel();
		panel_2.setBounds(117, 122, 128, 25);
		f.getContentPane().add(panel_2);

		JLabel l_id = new JLabel(id);
		l_id.setFont(new Font("맑은 고딕", Font.BOLD, 13));
		panel_2.add(l_id);

		JPanel panel_3 = new JPanel();
		panel_3.setBounds(117, 167, 128, 25);
		f.getContentPane().add(panel_3);

		JLabel l_birth = new JLabel(birth);
		l_birth.setFont(new Font("맑은 고딕", Font.BOLD, 13));
		panel_3.add(l_birth);

		JLabel l_time = new JLabel(time_left);
		l_time.setFont(new Font("맑은 고딕", Font.BOLD, 15));
		l_time.setForeground(Color.WHITE);
		l_time.setBounds(132, 237, 81, 25);
		f.getContentPane().add(l_time);

		f.setVisible(true);
	}
}
