package project;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;

import dbprocess.MemberDAO;
import dbprocess.MemberDTO;

import javax.swing.JTextField;

public class NonAdult {
	private static JTextField text_search;
	static ArrayList<MemberDTO> arr = null;
	static ArrayList<MemberDTO> arr2 = null;
	static JList list;
	static JScrollPane scrollPane;

	public void adult() {
		JFrame f = new JFrame();
		f.setTitle("미성년자 해제");
		f.getContentPane().setBackground(Color.WHITE);
		f.setSize(300, 280);
		f.setLocation(1150, 100);
		f.setResizable(false);
		f.getContentPane().setLayout(null);
		MemberDAO m_dao = new MemberDAO();
		MemberDTO m_dto = new MemberDTO();

		JButton bt_search = new JButton("검색");

		JLabel lblNewLabel = new JLabel("아이디 검색");
		lblNewLabel.setFont(new Font("맑은 고딕", Font.BOLD, 19));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setBounds(12, 10, 145, 24);
		f.getContentPane().add(lblNewLabel);
		arr2 = m_dao.id_total_list(m_dto);

		MemberDTO[] member_list2 = new MemberDTO[arr2.size()];

		for (int i = 0; i < arr2.size(); i++) {
			member_list2[i] = arr2.get(i);
		}
		list = new JList(member_list2);
		list.setBackground(Color.LIGHT_GRAY);
		scrollPane = new JScrollPane(list);
		scrollPane.setBounds(37, 75, 220, 133);
		f.getContentPane().add(scrollPane);
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		list.addMouseListener(new MouseListener() {
			public void mouseReleased(MouseEvent e) {
			}

			public void mousePressed(MouseEvent e) {
			}

			public void mouseExited(MouseEvent e) {
			}

			public void mouseEntered(MouseEvent e) {
			}

			public void mouseClicked(MouseEvent e) {
				String id = list.getSelectedValue().toString();
				int pos = id.indexOf('('); // 클릭한 아이디를 MemberDTO에서 String으로 바꾸는 작업
				id = id.substring(0, pos);
				int result = JOptionPane.showConfirmDialog(f, "성인인증을 하시겠습니까?", "성인인증", JOptionPane.YES_NO_OPTION);
				if (result == JOptionPane.YES_OPTION) {
					if (m_dao.check_adult(id).equals("Y")) {
						JOptionPane.showMessageDialog(f, "이미 성인 인증된 아이디입니다.");
					} else {
						m_dao.update_adult(id);
						JOptionPane.showMessageDialog(f, "성인인증 완료");
						f.dispose();
					}

				} else {
					JOptionPane.showMessageDialog(f, "성인인증 취소");
				}

			}
		});

		text_search = new JTextField();
		text_search.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		text_search.setBounds(37, 44, 152, 21);
		f.getContentPane().add(text_search);
		text_search.setColumns(10);

		bt_search.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				f.remove(list);
				f.remove(scrollPane);
				m_dto.setId(text_search.getText());
				arr = m_dao.id_list(m_dto);

				MemberDTO[] member_list = new MemberDTO[arr.size()];

				for (int i = 0; i < arr.size(); i++) {
					member_list[i] = arr.get(i);
				}
				JList list = new JList(member_list);
				list.setBackground(Color.LIGHT_GRAY);
				scrollPane = new JScrollPane(list);
				scrollPane.setBounds(37, 75, 220, 133);
				f.getContentPane().add(scrollPane);
				list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

				list.addMouseListener(new MouseListener() {
					public void mouseReleased(MouseEvent e) {
					}

					public void mousePressed(MouseEvent e) {
					}

					public void mouseExited(MouseEvent e) {
					}

					public void mouseEntered(MouseEvent e) {
					}

					public void mouseClicked(MouseEvent e) {
						String id = list.getSelectedValue().toString();
						int pos = id.indexOf('('); // 클릭한 아이디를 MemberDTO에서 String으로 바꾸는 작업
						id = id.substring(0, pos);
						int result = JOptionPane.showConfirmDialog(f, "성인인증을 하시겠습니까?", "성인인증",
								JOptionPane.YES_NO_OPTION);
						if (result == JOptionPane.YES_OPTION) {
							if (m_dao.check_adult(id).equals("Y")) {
								JOptionPane.showMessageDialog(f, "이미 성인 인증된 아이디입니다.");
							} else {
								m_dao.update_adult(id);
								JOptionPane.showMessageDialog(f, "성인인증 완료");
								f.dispose();
							}

						} else {
							JOptionPane.showMessageDialog(f, "성인인증 취소");
						}

					}
				});

				f.setVisible(true);

			}

		});
		bt_search.setBounds(195, 42, 63, 24);
		f.getContentPane().add(bt_search);

		JRootPane rootPane = f.getRootPane(); // 엔터시 검색 버튼 눌림
		rootPane.setDefaultButton(bt_search);

		f.setVisible(true);
	}
}
