package project;

import java.awt.Color;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRootPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;


import dbprocess.MemberDAO;

public class Login {
	private static JTextField t_id;
	private static JPasswordField t_pw;
	private static JTextField textField;

	static String time_left = "03:00"; // 임시저장값

	public void logIn(String number, JButton button, JButton button2) {
		JFrame f = new JFrame();
		f.getContentPane().setBackground(Color.GRAY);
		f.setSize(500, 430);
		f.getContentPane().setLayout(null);
		f.setLocation(500, 440); // 프레임 위치 조정
		f.setTitle(number + "번 PC");
		f.setResizable(false); // 프레임 크기 변경 불가
		MemberJoin j = new MemberJoin();
		MemberDAO m_dao = new MemberDAO();
		MemberInfo inf = new MemberInfo();
		

		int number2 = Integer.parseInt(number);

		JLabel lblNewLabel = new JLabel("\uB354\uC870\uC740 \uD53C\uC528\uBC29");
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("맑은 고딕", Font.PLAIN, 45));
		lblNewLabel.setBounds(89, 77, 313, 63);
		f.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("ID");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("맑은 고딕", Font.PLAIN, 27));
		lblNewLabel_1.setBounds(34, 210, 111, 46);
		f.getContentPane().add(lblNewLabel_1);

		t_id = new JTextField();
		t_id.setFont(new Font("맑은 고딕", Font.PLAIN, 27));
		t_id.setBounds(149, 214, 210, 38);
		f.getContentPane().add(t_id);
		t_id.setColumns(10);

		JLabel lblNewLabel_1_1 = new JLabel("PassWord");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setFont(new Font("맑은 고딕", Font.PLAIN, 23));
		lblNewLabel_1_1.setBounds(34, 273, 111, 46);
		f.getContentPane().add(lblNewLabel_1_1);

		t_pw = new JPasswordField();
		t_pw.setFont(new Font("맑은 고딕", Font.PLAIN, 27));
		t_pw.setColumns(10);
		t_pw.setBounds(149, 281, 210, 38);
		f.getContentPane().add(t_pw);

		JLabel lblNewLabel_1_1_1 = new JLabel("\uBE44\uD68C\uC6D0");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1_1.setFont(new Font("맑은 고딕", Font.PLAIN, 23));
		lblNewLabel_1_1_1.setBounds(34, 334, 111, 46);
		f.getContentPane().add(lblNewLabel_1_1_1);

		textField = new JTextField();
		textField.setFont(new Font("맑은 고딕", Font.PLAIN, 27));
		textField.setColumns(10);
		textField.setBounds(149, 342, 210, 38);
		f.getContentPane().add(textField);

		t_id.setFocusTraversalKeysEnabled(false); // 탭을 누르면
		t_id.addKeyListener(new KeyAdapter() { // 패스워드 입력 텍스트로 이동
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_TAB)
					t_pw.requestFocus();
			}
		});

		JButton btnNewButton = new JButton("<html>Log<br/> in</html>");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = t_id.getText();
				String pw = t_pw.getText();
				String name = m_dao.check_name(id);
				if (m_dao.overlap(id)) {
					if (m_dao.check_pw(id, pw)) { // 입력한 아이디에 해당하는 비밀번호 체크
						if (m_dao.check_seat(id) == 0) { // 해당 아이디의 db테이블 좌석번호가 0일 경우에만 로그인(이용아이디 중복 이용 방지)
							if(m_dao.search_id().contains(id)) {  //해당 아이디 블랙리스트에 있는지 체크
								JOptionPane.showMessageDialog(null, "해당 아이디는 정지되었습니다. 카운터에 문의하세요.");
							}
							else {
								JOptionPane.showMessageDialog(f, "로그인 완료");
								m_dao.update_seat(id, number2); // 해당 아이디의 db테이블 좌석번호를 해당 좌석번호로 업데이트
								button.setBackground(Color.BLUE);
								button.setForeground(Color.YELLOW);
								button.setFont(new Font("맑은 고딕", Font.BOLD, 12));
								button.setText("<html>" + number + "<br/>" + name + "</html>");
								button2.setBackground(Color.BLUE);
								button2.setForeground(Color.YELLOW);
								button2.setFont(new Font("맑은 고딕", Font.BOLD, 12));
								button2.setText("<html>" + number + "<br/>" + name + "<br/>" + time_left + "</html>");
								button2.addActionListener(new ActionListener() {

									public void actionPerformed(ActionEvent e) { //로그인 성공시 관리자 화면에서 해당 로그인 버튼
										String birth = m_dao.check_birth(id);	 //클릭 후 정보 보기 가능해짐
										inf.inform(number, name, id, birth, time_left);
									}
								});
								f.dispose();
							}
							
						} else {
							JOptionPane.showMessageDialog(f, "이미 사용중인 아이디입니다.");
						}

					} else {
						JOptionPane.showMessageDialog(f, "비밀번호가 틀렸습니다.");
					}
				} else {
					JOptionPane.showMessageDialog(f, "없는 아이디입니다.");
				}

			}
		});
		btnNewButton.setBackground(Color.DARK_GRAY);
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setFont(new Font("맑은 고딕", Font.PLAIN, 27));
		btnNewButton.setBounds(376, 235, 83, 132);

		f.getContentPane().add(btnNewButton);

		t_pw.setFocusTraversalKeysEnabled(false); // 패스워드 텍스트에서 탭을 누를시
		t_pw.addKeyListener(new KeyAdapter() {   //로그인 버튼으로 이동
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_TAB)
					btnNewButton.requestFocus();
			}
		});

		JButton btnNewButton_1 = new JButton("\uD68C\uC6D0\uAC00\uC785");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				j.join();
			}
		});
		btnNewButton_1.setBackground(Color.DARK_GRAY);
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setFont(new Font("맑은 고딕", Font.PLAIN, 19));
		btnNewButton_1.setBounds(342, 159, 117, 38);
		f.getContentPane().add(btnNewButton_1);

		JLabel lblNewLabel_2 = new JLabel(number + "번 PC");

		lblNewLabel_2.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setBounds(24, 10, 83, 39);
		f.getContentPane().add(lblNewLabel_2);

		JRootPane rootPane = f.getRootPane(); // 엔터를 누를시 로그인 버튼 눌림
		rootPane.setDefaultButton(btnNewButton);

		f.setVisible(true);

	}

}
