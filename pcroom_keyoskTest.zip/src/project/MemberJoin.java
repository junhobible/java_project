package project;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import dbprocess.MemberDAO;
import dbprocess.MemberDTO;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.JRootPane;

public class MemberJoin {
	private static JTextField join_id;
	private static JPasswordField join_pw;
	private static JTextField join_name;
	private static JTextField join_birth;
	private static JTextField join_tel;
	private static JTextField join_email;
	private static JTextField join_addr;
	static String gender;
	private static JPasswordField pw_check;

	public void join() {
		JFrame f = new JFrame();
		f.setSize(400, 550);
		f.setLocation(520, 305);
		f.getContentPane().setLayout(null);
		f.setTitle("회원가입 창");
		f.setResizable(false);
		MemberDAO db = new MemberDAO();
		MemberDTO dto = new MemberDTO();

		JLabel lblNewLabel_1 = new JLabel("\uC544\uC774\uB514");
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(0, 30, 111, 46);
		f.getContentPane().add(lblNewLabel_1);

		join_id = new JTextField();
		join_id.setFont(new Font("맑은 고딕", Font.PLAIN, 27));
		join_id.setBounds(123, 37, 169, 38);
		f.getContentPane().add(join_id);
		join_id.setColumns(10);

		JLabel lblNewLabel_1_1 = new JLabel("\uBE44\uBC00\uBC88\uD638");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setForeground(Color.BLACK);
		lblNewLabel_1_1.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
		lblNewLabel_1_1.setBounds(0, 76, 111, 46);
		f.getContentPane().add(lblNewLabel_1_1);

		JLabel lblNewLabel_1_2 = new JLabel("\uC774\uB984");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setForeground(Color.BLACK);
		lblNewLabel_1_2.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
		lblNewLabel_1_2.setBounds(0, 172, 111, 46);
		f.getContentPane().add(lblNewLabel_1_2);

		JLabel lblNewLabel_1_3 = new JLabel("\uC131\uBCC4");
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3.setForeground(Color.BLACK);
		lblNewLabel_1_3.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
		lblNewLabel_1_3.setBounds(0, 218, 111, 46);
		f.getContentPane().add(lblNewLabel_1_3);

		JLabel lblNewLabel_1_4 = new JLabel("\uC0DD\uB144\uC6D4\uC77C");
		lblNewLabel_1_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4.setForeground(Color.BLACK);
		lblNewLabel_1_4.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
		lblNewLabel_1_4.setBounds(0, 264, 111, 46);
		f.getContentPane().add(lblNewLabel_1_4);

		JLabel lblNewLabel_1_5 = new JLabel("\uC804\uD654\uBC88\uD638");
		lblNewLabel_1_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_5.setForeground(Color.BLACK);
		lblNewLabel_1_5.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
		lblNewLabel_1_5.setBounds(0, 312, 111, 46);
		f.getContentPane().add(lblNewLabel_1_5);

		JLabel lblNewLabel_1_5_1 = new JLabel("\uC774\uBA54\uC77C");
		lblNewLabel_1_5_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_5_1.setForeground(Color.BLACK);
		lblNewLabel_1_5_1.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
		lblNewLabel_1_5_1.setBounds(0, 360, 111, 46);
		f.getContentPane().add(lblNewLabel_1_5_1);

		join_pw = new JPasswordField();

		join_pw.setFont(new Font("맑은 고딕", Font.PLAIN, 27));
		join_pw.setColumns(10);
		join_pw.setBounds(123, 83, 210, 38);
		f.getContentPane().add(join_pw);

		join_name = new JTextField();
		join_name.setFont(new Font("맑은 고딕", Font.PLAIN, 27));
		join_name.setColumns(10);
		join_name.setBounds(123, 179, 210, 38);
		f.getContentPane().add(join_name);

		join_birth = new JTextField();
		join_birth.setFont(new Font("맑은 고딕", Font.PLAIN, 27));
		join_birth.setColumns(10);
		join_birth.setBounds(123, 271, 210, 38);
		f.getContentPane().add(join_birth);

		join_tel = new JTextField();
		join_tel.setFont(new Font("맑은 고딕", Font.PLAIN, 27));
		join_tel.setColumns(10);
		join_tel.setBounds(123, 319, 210, 38);
		f.getContentPane().add(join_tel);

		join_email = new JTextField();
		join_email.setFont(new Font("맑은 고딕", Font.PLAIN, 27));
		join_email.setColumns(10);
		join_email.setBounds(123, 367, 210, 38);
		f.getContentPane().add(join_email);
		JRadioButton rd_male = new JRadioButton("\uB0A8");
		JRadioButton rd_female = new JRadioButton("\uC5EC");

		ButtonGroup groupRd = new ButtonGroup();
		groupRd.add(rd_male);
		groupRd.add(rd_female);

		JButton button_join = new JButton("\uAC00\uC785 \uC644\uB8CC");
		button_join.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = join_id.getText();
				String pw = join_pw.getText();
				String pw2 = pw_check.getText();
				String name = join_name.getText();
				if (rd_male.isSelected()) {
					gender = "M";
				} else if (rd_female.isSelected()) {
					gender = "F";
				}
				String birth = join_birth.getText();
				String tel = join_tel.getText();
				String email = join_email.getText();
				String addr = join_addr.getText();

				dto.setId(id);
				dto.setPw(pw);
				dto.setName(name);
				dto.setGender(gender);
				dto.setBirth(birth);
				dto.setTel(tel);
				dto.setEmail(email);
				dto.setAddr(addr);

				if (db.overlap(id)) {
					JOptionPane.showMessageDialog(f, "중복된 아이디가 있습니다.");
				} else {
					if (pw.equals(pw2)) {
						db.insert(dto);
						JOptionPane.showMessageDialog(f, "회원가입 완료!");
						f.dispose();
					} else {
						JOptionPane.showMessageDialog(f, "비밀번호가 다릅니다.");
					}
				}
			}
		});
		button_join.setFont(new Font("맑은 고딕", Font.PLAIN, 18));
		button_join.setBounds(61, 463, 125, 37);
		f.getContentPane().add(button_join);

		JButton button_cancle = new JButton("\uCDE8\uC18C");
		button_cancle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});
		button_cancle.setFont(new Font("맑은 고딕", Font.PLAIN, 18));
		button_cancle.setBounds(224, 463, 136, 37);
		f.getContentPane().add(button_cancle);

		join_addr = new JTextField();
		join_addr.setFont(new Font("맑은 고딕", Font.PLAIN, 27));
		join_addr.setColumns(10);
		join_addr.setBounds(123, 415, 210, 38);
		f.getContentPane().add(join_addr);

		JLabel lblNewLabel_1_5_1_1 = new JLabel("\uC8FC\uC18C");
		lblNewLabel_1_5_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_5_1_1.setForeground(Color.BLACK);
		lblNewLabel_1_5_1_1.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
		lblNewLabel_1_5_1_1.setBounds(0, 408, 111, 46);
		f.getContentPane().add(lblNewLabel_1_5_1_1);

		rd_male.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
		rd_male.setBounds(146, 223, 60, 42);
		f.getContentPane().add(rd_male);

		rd_female.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
		rd_female.setBounds(241, 223, 60, 42);
		f.getContentPane().add(rd_female);

		JButton overlap = new JButton("\uC911\uBCF5\uD655\uC778");
		overlap.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = join_id.getText();
				if (db.overlap(id)) {
					JOptionPane.showMessageDialog(f, "중복된 아이디가 있습니다.");
				} else {
					JOptionPane.showMessageDialog(f, "사용 가능한 아이디입니다.");
				}

			}
		});
		overlap.setFont(new Font("맑은 고딕", Font.PLAIN, 11));
		overlap.setBounds(300, 37, 81, 38);
		f.getContentPane().add(overlap);

		pw_check = new JPasswordField();
		pw_check.setFont(new Font("맑은 고딕", Font.PLAIN, 27));
		pw_check.setColumns(10);
		pw_check.setBounds(123, 131, 210, 38);
		f.getContentPane().add(pw_check);

		JLabel label = new JLabel("\uBE44\uBC00\uBC88\uD638 \uD655\uC778");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setForeground(Color.BLACK);
		label.setFont(new Font("맑은 고딕", Font.PLAIN, 16));
		label.setBounds(0, 124, 111, 46);
		f.getContentPane().add(label);

		JRootPane rootPane = f.getRootPane(); // 엔터를 누를시 회원가입 버튼 누름
		rootPane.setDefaultButton(button_join);
		f.setVisible(true);

	}
}
