package project;

import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import dbprocess.MemberDAO;

import java.awt.Font;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PasswordInit2 {
	private static JTextField t_birth;
	private static JTextField t_tel;

	public void init_check(String id, String name, JFrame f2) {
		JFrame f = new JFrame();
		f.setTitle("초기화 확인");
		f.getContentPane().setBackground(Color.LIGHT_GRAY);
		f.getContentPane().setLayout(null);
		MemberDAO m_dao = new MemberDAO();

		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setFont(new Font("맑은 고딕", Font.BOLD, 17));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(27, 30, 57, 32);
		f.getContentPane().add(lblNewLabel);

		JLabel lblPw = new JLabel("이름");
		lblPw.setHorizontalAlignment(SwingConstants.CENTER);
		lblPw.setForeground(Color.BLACK);
		lblPw.setFont(new Font("맑은 고딕", Font.BOLD, 17));
		lblPw.setBounds(12, 72, 89, 32);
		f.getContentPane().add(lblPw);

		JLabel lblNewLabel_2 = new JLabel("생년월일");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setForeground(Color.BLACK);
		lblNewLabel_2.setFont(new Font("맑은 고딕", Font.BOLD, 17));
		lblNewLabel_2.setBounds(12, 114, 89, 32);
		f.getContentPane().add(lblNewLabel_2);

		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.YELLOW);
		panel1.setBounds(114, 36, 159, 26);
		f.getContentPane().add(panel1);

		JLabel label_id = new JLabel(id);
		label_id.setHorizontalAlignment(SwingConstants.CENTER);
		label_id.setFont(new Font("맑은 고딕", Font.PLAIN, 13));
		panel1.add(label_id);

		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.YELLOW);
		panel2.setBounds(113, 78, 159, 26);
		f.getContentPane().add(panel2);

		JLabel label_name = new JLabel(name);
		label_name.setHorizontalAlignment(SwingConstants.CENTER);
		label_name.setFont(new Font("맑은 고딕", Font.PLAIN, 13));
		panel2.add(label_name);

		t_birth = new JTextField();
		t_birth.setText("");
		t_birth.setBounds(113, 117, 159, 26);
		f.getContentPane().add(t_birth);
		t_birth.setColumns(10);
		t_birth.setHorizontalAlignment(SwingConstants.CENTER);

		JButton bt_init = new JButton("<html>비밀번호<br/> 초기화</html>");
		bt_init.setForeground(Color.WHITE);
		bt_init.setBackground(new Color(64, 64, 64));
		bt_init.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String birth = m_dao.check_birth(id);
				String tel = m_dao.check_tel(id);
				String check_birth = t_birth.getText();
				String check_tel = t_tel.getText();
				if (birth.equals(check_birth) == false) {
					JOptionPane.showMessageDialog(f, "생년월일이 다릅니다.");
				} else {
					if (tel.equals(check_tel) == false) {
						JOptionPane.showMessageDialog(f, "전화번호가 다릅니다.");
					} else {
						m_dao.update_pw(id);
						JOptionPane.showMessageDialog(f, "비밀번호가 초기화 되었습니다.");
						f.dispose();
						f2.dispose();
					}
				}
			}
		});
		bt_init.setFont(new Font("맑은 고딕", Font.BOLD, 13));
		bt_init.setBounds(43, 204, 89, 49);
		f.getContentPane().add(bt_init);

		JButton bt_close = new JButton("취소");
		bt_close.setForeground(Color.WHITE);
		bt_close.setBackground(Color.DARK_GRAY);
		bt_close.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});
		bt_close.setFont(new Font("맑은 고딕", Font.BOLD, 13));
		bt_close.setBounds(184, 204, 89, 49);
		f.getContentPane().add(bt_close);

		JLabel lblNewLabel_2_1 = new JLabel("전화번호");
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1.setForeground(Color.BLACK);
		lblNewLabel_2_1.setFont(new Font("맑은 고딕", Font.BOLD, 17));
		lblNewLabel_2_1.setBounds(12, 156, 89, 32);
		f.getContentPane().add(lblNewLabel_2_1);

		t_tel = new JTextField();
		t_tel.setText("");
		t_tel.setColumns(10);
		t_tel.setBounds(113, 158, 159, 26);
		t_tel.setHorizontalAlignment(SwingConstants.CENTER);

		f.getContentPane().add(t_tel);
		f.setSize(310, 300);
		f.setLocation(1150, 100);
		f.setResizable(false);

		JRootPane rootPane = f.getRootPane(); // 엔터시 비밀번호 초기화 버튼 눌림
		rootPane.setDefaultButton(bt_init);

		f.setVisible(true);

	}
}
