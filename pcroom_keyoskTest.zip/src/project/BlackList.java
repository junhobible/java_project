package project;

import javax.swing.JFrame;


import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRootPane;
import javax.swing.SwingConstants;



import dbprocess.MemberDAO;
import dbprocess.MemberDTO;

import java.awt.Font;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.JScrollPane;
import javax.swing.JList;

public class BlackList {
	private static JTextField text_search;
	static ArrayList<MemberDTO> arr = null;
	static ArrayList<MemberDTO> arr2 = null;
	static JList list;
	static JScrollPane scrollPane;

	public void black_list() {
		JFrame f = new JFrame();
		f.setTitle("블랙리스트 관리");
		f.getContentPane().setBackground(Color.BLACK);
		f.setSize(300, 300);
		f.setLocation(1150, 100);
		f.getContentPane().setLayout(null);
		f.setResizable(false);		
		MemberDAO m_dao = new MemberDAO();
		MemberDTO m_dto = new MemberDTO();

		JButton bt_search = new JButton("검색");

		JLabel lblNewLabel = new JLabel("블랙리스트");
		lblNewLabel.setFont(new Font("맑은 고딕", Font.BOLD, 19));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.YELLOW);
		lblNewLabel.setBounds(12, 10, 145, 24);
		f.getContentPane().add(lblNewLabel);
		arr2 = m_dao.bl_id_total_list();

		MemberDTO[] black_list2 = new MemberDTO[arr2.size()];

		for (int i = 0; i < arr2.size(); i++) {
			black_list2[i] = arr2.get(i);
		}
		list = new JList(black_list2);
		scrollPane = new JScrollPane(list);
		scrollPane.setBounds(37, 75, 220, 133);
		f.getContentPane().add(scrollPane);
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		list.addMouseListener(new MouseListener() {
			public void mouseReleased(MouseEvent e) {
			}

			public void mousePressed(MouseEvent e) {
			}

			public void mouseExited(MouseEvent e) {
			}

			public void mouseEntered(MouseEvent e) {
			}

			public void mouseClicked(MouseEvent e) {
				int result = JOptionPane.showConfirmDialog(f, list.getSelectedValue() + " 님의 블랙리스트를 해제하시겠습니까?",
						"블랙리스트 해제", JOptionPane.YES_NO_OPTION);
				if (result == JOptionPane.YES_OPTION) { // "예"를 눌렀을시
					String id = list.getSelectedValue().toString();
					int pos = id.indexOf('('); // 클릭한 아이디를 BlackListDTO에서 String으로 바꾸는 작업
					id = id.substring(0, pos);
					m_dao.delete_bl(id); // 클릭한 아이디를 블랙리스트에서 지움
					JOptionPane.showMessageDialog(null, "해제되었습니다.");
					bt_search.doClick(); // 리스트 갱신을 위한 버튼 클릭액션
				}
			}
		});

		JButton bt_add = new JButton("추가");
		bt_add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String black_id = JOptionPane.showInputDialog(f, "아이디를 입력하세요");
				if (black_id == null) {

				} else if (black_id.equals("")) {
					JOptionPane.showMessageDialog(null, "입력된 아이디가 없습니다.");
				} else {
					if (m_dao.overlap(black_id)) {
						int result = JOptionPane.showConfirmDialog(f, "해당 아이디를 블랙리스트에 추가하시겠습니까?", null,
								JOptionPane.YES_NO_OPTION);
						if (result == JOptionPane.YES_OPTION) {
							ArrayList bl_id_list = new ArrayList();
							bl_id_list = m_dao.search_id();
							if (bl_id_list.contains(black_id)) {
								System.out.println(bl_id_list);
								JOptionPane.showMessageDialog(f, "이미 블랙리스트에 추가된 아이디입니다.");
							} else {
								String ck_name = m_dao.check_name(black_id);
								m_dto.setId(black_id);
								m_dto.setName(ck_name);
								m_dao.input_bl(m_dto);
								JOptionPane.showMessageDialog(f, "아이디가 블랙리스트에 추가되었습니다.");
								bt_search.doClick(); // 리스트 갱신을 위한 버튼 클릭액션
							}

						} else {
							JOptionPane.showMessageDialog(f, "블랙리스트 등록이 취소되었습니다.");
						}
					} else {
						JOptionPane.showMessageDialog(f, "없는 아이디입니다.");
					}
				}
			}
		});
		bt_add.setForeground(Color.WHITE);
		bt_add.setFont(new Font("맑은 고딕", Font.PLAIN, 16));
		bt_add.setBackground(Color.BLUE);
		bt_add.setBounds(100, 218, 89, 33);
		f.getContentPane().add(bt_add);

		text_search = new JTextField();
		text_search.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		text_search.setBounds(37, 44, 152, 21);
		f.getContentPane().add(text_search);
		text_search.setColumns(10);

		bt_search.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.remove(list);
				f.remove(scrollPane);
				m_dto.setId(text_search.getText());
				arr = m_dao.bl_id_list(m_dto);
				MemberDTO[] black_list = new MemberDTO[arr.size()];

				for (int i = 0; i < arr.size(); i++) {
					black_list[i] = arr.get(i);
				}
				JList list = new JList(black_list);
				scrollPane = new JScrollPane(list);
				scrollPane.setBounds(37, 75, 220, 133);
				f.getContentPane().add(scrollPane);
				list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

				list.addMouseListener(new MouseListener() {
					public void mouseReleased(MouseEvent e) {
					}

					public void mousePressed(MouseEvent e) {
					}

					public void mouseExited(MouseEvent e) {
					}

					public void mouseEntered(MouseEvent e) {
					}

					public void mouseClicked(MouseEvent e) {
						int result = JOptionPane.showConfirmDialog(f, list.getSelectedValue() + " 님의 블랙리스트를 해제하시겠습니까?",
								"블랙리스트 해제", JOptionPane.YES_NO_OPTION);
						if (result == JOptionPane.YES_OPTION) { // "예"를 눌렀을시
							String id = list.getSelectedValue().toString();
							int pos = id.indexOf('('); // 클릭한 아이디를 블랙리스트에서 지움
							id = id.substring(0, pos);
							m_dao.delete_bl(id);
							JOptionPane.showMessageDialog(f, "해제되었습니다.");
							bt_search.doClick(); // 리스트 갱신을 위한 버튼 클릭액션
						}
					}
				});

				f.setVisible(true);

			}

		});
		bt_search.setBounds(195, 42, 63, 24);
		f.getContentPane().add(bt_search);
		JRootPane rootPane = f.getRootPane(); // 엔터시 로그인 버튼 눌림
		rootPane.setDefaultButton(bt_search);

		f.setVisible(true);
	}
}
