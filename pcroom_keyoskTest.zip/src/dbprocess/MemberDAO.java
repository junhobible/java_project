package dbprocess;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class MemberDAO {
	static String url = "jdbc:mysql://localhost:3708/pcroom";
	static String user = "root";
	static String password = "1234";

	public void insert(MemberDTO dto) { // 회원가입시 정보 db로 전달
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String sql = "insert into member values (?,?,?,?,?,?,?,?,null,null,0,'N','N')";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			ps.setString(2, dto.getPw());
			ps.setString(3, dto.getName());
			ps.setString(4, dto.getGender());
			ps.setString(5, dto.getBirth());
			ps.setString(6, dto.getTel());
			ps.setString(7, dto.getEmail());
			ps.setString(8, dto.getAddr());

			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public static boolean overlap(String id) { // 아이디 중복 확인
		try {

			String sql = "select id from member";
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			PreparedStatement ps = con.prepareStatement(sql);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				if (rs.getString("id").equals(id)) {
					return true;
				}

			}

		} catch (Exception e) {
			e.printStackTrace();

		}
		return false;

	}

	public static boolean check_pw(String id, String pw) { // 입력한 아이디에 해당하는 비밀번호 확인
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String sql = "select pw from member where id= (?)";
			Connection con = DriverManager.getConnection(url, user, password);
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				if (rs.getString("pw").equals(pw)) {
					return true;
				}

			}

		} catch (Exception e) {
			e.printStackTrace();

		}
		return false;
	}

	public String check_name(String id) { // 입력한 아이디에 해당하는 이름 확인
		String name = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String sql = "select name from member where id= (?)";
			Connection con = DriverManager.getConnection(url, user, password);
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				name = rs.getString("name");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return name;
	}

	public ArrayList<MemberDTO> id_list(MemberDTO m_dto) { // 검색한 문자에 해당하는 아이디와 이름 리스트로 가져옴
		ArrayList<MemberDTO> arr = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String sql = "select id, name from member " + "where id like concat('%',?,'%') "
					+ "or name like concat('%',?,'%')";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, m_dto.getId());
			ps.setString(2, m_dto.getId());
			ResultSet rs = ps.executeQuery();
			arr = new ArrayList<MemberDTO>();
			while (rs.next()) {
				MemberDTO tempDTO = new MemberDTO();
				tempDTO.setId(rs.getString("id"));
				tempDTO.setName(rs.getString("name"));
				arr.add(tempDTO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return arr;
	}

	public ArrayList<MemberDTO> id_total_list(MemberDTO m_dto) { // member 테이블 아이디와 이름 전부 가져와 리스트에 넣기
		ArrayList<MemberDTO> arr = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String sql = "select id, name from member";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			arr = new ArrayList<MemberDTO>();
			while (rs.next()) {
				MemberDTO tempDTO = new MemberDTO();
				tempDTO.setId(rs.getString("id"));
				tempDTO.setName(rs.getString("name"));
				arr.add(tempDTO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return arr;
	}

	public String check_birth(String id) { // 입력한 아이디에 해당하는 생년월일 확인
		String ck_birth = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String sql = "select birth from member where id=(?)";
			Connection con = DriverManager.getConnection(url, user, password);
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				ck_birth = rs.getString("birth");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return ck_birth;
	}

	public String check_tel(String id) { // 입력한 아이디에 해당하는 전화번호 확인
		String ck_tel = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String sql = "select tel from member where id=(?)";
			Connection con = DriverManager.getConnection(url, user, password);
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				ck_tel = rs.getString("tel");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return ck_tel;
	}

	public void update_pw(String id) { // 해당 id의 비밀번호 '123456789' 로 변경
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String sql = "update member set pw='123456789' where id=(?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id);

			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public void update_adult(String id) { // 성인인증 후 성인체크
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String sql = "update member set adult_yn='Y' where id=(?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id);

			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public String check_adult(String id) { // 해당 아이디가 성인인지 확인
		String ck_adult = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String sql = "select adult_yn from member where id=(?)";
			Connection con = DriverManager.getConnection(url, user, password);
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				ck_adult = rs.getString("adult_yn");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return ck_adult;
	}

	public void update_seat(String id, int number) { // 해당 아이디의 db테이블 좌석번호 전송
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String sql = "update member set seat_num= (?) where id=(?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, number);
			ps.setString(2, id);

			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public int check_seat(String id) { // 해당 id의 db테이블 좌석번호 확인
		int ck_seat = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String sql = "select seat_num from member where id=(?)";
			Connection con = DriverManager.getConnection(url, user, password);
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				ck_seat = rs.getInt("seat_num");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return ck_seat;
	}

	public ArrayList search_seat() { // member테이블에 있는 좌석번호 0 제외하고 리스트에 넣음(아이디 중복 로그인,이용자리 중복 이용 체크용)
		ArrayList arr = new ArrayList();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String sql = "select seat_num from member";
			PreparedStatement ps = con.prepareStatement(sql);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int m_seat = rs.getInt("seat_num");
				if (m_seat != 0) {
					arr.add(m_seat);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();

		}
		return arr;
	}
	public String check_gender(String id) { // 입력한 아이디에 해당하는 성별 확인
		String ck_gender = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String sql = "select gender from member where id=(?)";
			Connection con = DriverManager.getConnection(url, user, password);
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				ck_gender = rs.getString("gender");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return ck_gender;
	}
	public ArrayList<MemberDTO> bl_id_list(MemberDTO m_dto) { // 검색어에 해당하는 블랙리스트의 아이디와 이름 리스트로 만듦
		ArrayList<MemberDTO> arr = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String sql = "select id, name from member  " + "where (id like concat('%',?,'%') "
					+ "or name like concat('%',?,'%')) and blacklist='Y' ";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, m_dto.getId());
			ps.setString(2, m_dto.getId());
			ResultSet rs = ps.executeQuery();
			arr = new ArrayList<MemberDTO>();
			while (rs.next()) {
				MemberDTO tempDTO = new MemberDTO();
				tempDTO.setId(rs.getString("id"));
				tempDTO.setName(rs.getString("name"));
				arr.add(tempDTO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return arr;
	}

	public ArrayList<MemberDTO> bl_id_total_list() { // 블랙리스트에 있는 아이디와 이름 리스트로 만듦
		ArrayList<MemberDTO> arr = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String sql = "select id, name from member where blacklist='Y'";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			arr = new ArrayList<MemberDTO>();
			while (rs.next()) {
				MemberDTO tempDTO = new MemberDTO();
				tempDTO.setId(rs.getString("id"));
				tempDTO.setName(rs.getString("name"));
				arr.add(tempDTO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return arr;
	}

	public void input_bl(MemberDTO m_dto) { // 블랙리스트에 아이디와 이름 입력
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String sql = "update member set blacklist ='Y' where id = (?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, m_dto.getId());

			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public void delete_bl(String id) { // 해당 아이디 블랙리스트에서 제거
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String sql = "update member set blacklist = 'N' where id = (?) ";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id);

			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public ArrayList search_id() { // 블랙리스트에 있는 아이디 전부 가져와서 리스트에 저장
		ArrayList arr = new ArrayList();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String sql = "select id from member where blacklist = 'Y'";
			PreparedStatement ps = con.prepareStatement(sql);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				String bl_id = rs.getString("id");
				arr.add(bl_id);
			}

		} catch (Exception e) {
			e.printStackTrace();

		}
		return arr;
	}

}
