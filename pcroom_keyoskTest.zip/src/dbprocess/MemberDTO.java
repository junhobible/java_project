package dbprocess;

import javax.swing.JButton;

public class MemberDTO {
	String id, pw, name, gender, birth, tel, email, addr, num;

	public String getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num = num;
	}

	JButton b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16;

	public JButton getB1() {
		return b1;
	}

	public void setB1(JButton b1) {
		this.b1 = b1;
	}

	public JButton getB2() {
		return b2;
	}

	public void setB2(JButton b2) {
		this.b2 = b2;
	}

	public JButton getB3() {
		return b3;
	}

	public void setB3(JButton b3) {
		this.b3 = b3;
	}

	public JButton getB4() {
		return b4;
	}

	public void setB4(JButton b4) {
		this.b4 = b4;
	}

	public JButton getB5() {
		return b5;
	}

	public void setB5(JButton b5) {
		this.b5 = b5;
	}

	public JButton getB6() {
		return b6;
	}

	public void setB6(JButton b6) {
		this.b6 = b6;
	}

	public JButton getB7() {
		return b7;
	}

	public void setB7(JButton b7) {
		this.b7 = b7;
	}

	public JButton getB8() {
		return b8;
	}

	public void setB8(JButton b8) {
		this.b8 = b8;
	}

	public JButton getB9() {
		return b9;
	}

	public void setB9(JButton b9) {
		this.b9 = b9;
	}

	public JButton getB10() {
		return b10;
	}

	public void setB10(JButton b10) {
		this.b10 = b10;
	}

	public JButton getB11() {
		return b11;
	}

	public void setB11(JButton b11) {
		this.b11 = b11;
	}

	public JButton getB12() {
		return b12;
	}

	public void setB12(JButton b12) {
		this.b12 = b12;
	}

	public JButton getB13() {
		return b13;
	}

	public void setB13(JButton b13) {
		this.b13 = b13;
	}

	public JButton getB14() {
		return b14;
	}

	public void setB14(JButton b14) {
		this.b14 = b14;
	}

	public JButton getB15() {
		return b15;
	}

	public void setB15(JButton b15) {
		this.b15 = b15;
	}

	public JButton getB16() {
		return b16;
	}

	public void setB16(JButton b16) {
		this.b16 = b16;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getBirth() {
		return birth;
	}

	public void setBirth(String birth) {
		this.birth = birth;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public String toString() {
		return id + " (" + name + ")";
	}

}
