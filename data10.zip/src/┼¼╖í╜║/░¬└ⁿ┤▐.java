package 클래스;

public class 값전달 {

		public void add(int x) { // 값전달(복사하는 것) call by value
			System.out.println("전달 받음 " + x);
		}
		
		public void add(int[] x) {// 주소값 전달(복사) call by reference
			System.out.println("전달 받음");
			for (int i : x) {
				System.out.println("i");
			}
		}
}
