package 클래스;

public class 배열의복사 {

	public static void main(String[] args) {
		
		int a = 100;
		int b = a;
		System.out.println("a: " + a);
		System.out.println("a: " + b);
		a = 200;
		System.out.println("---------");
		System.out.println("a: " + a);
		System.out.println("a: " + b);
		
		int [] x = {1, 2, 3, 4, 5};
		int [] y = x;
		
		for (int i = 0; i < x.length; i++) {
			System.out.print(x[i] + " ");
		}
		System.out.println();
		for (int i = 0; i < y.length; i++) {
			System.out.print(y[i] + " ");
		}
		System.out.println();
		x[0] = 9;
		for (int i = 0; i < x.length; i++) {
			System.out.print(x[i] + " ");
		}
		System.out.println();	// 배열은 값 자체를 복사하지 않기 때문에 기존 값이 변경되면 복사한 값도 변경한다.
		for (int i = 0; i < y.length; i++) {
			System.out.print(y[i] + " ");
		}
		
		System.out.println();
		int[] z = x.clone(); // 깊은 복사(완전한 복사)
		
		x[0] = 8;
		for (int i = 0; i < z.length; i++) { //
			System.out.print(z[i] + " ");
		}
		
	}

}
