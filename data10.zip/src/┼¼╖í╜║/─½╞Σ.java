package 클래스;

import java.util.Scanner;

public class 카페 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		계산기 cal = new 계산기();
		Scanner sc = new Scanner(System.in);
		System.out.print("커피주문 : ");
		int coffee = sc.nextInt();
		System.out.print("와플주문 : ");
		int waffle = sc.nextInt();
		int sum = cal.mul(cal.add(coffee, waffle)); // cpu에 잠깐 저장되어있다.
		
		//vip 할인
		
		System.out.print("당신은 vip 인가요? 예)1, 아니요)2");
		String vip = sc.next();
		if (vip.equals("1")) {
			//vip 인경우
			if (cal.mul(cal.add(coffee, waffle)) > 40000) {
				
				System.out.println("당신의 총 지불금액 총액은 " + (sum-5000) + "원 입니다.");
			}else {
				System.out.println("당신의 총 지불금액 총액은 " + sum + "원 입니다.");
			}
		}
	}
	}
