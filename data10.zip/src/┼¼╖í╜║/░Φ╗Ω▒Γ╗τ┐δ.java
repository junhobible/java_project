package 클래스;

public class 계산기사용 {

	public static void main(String[] args) {
		
		업그레이드계산기 cal = new 업그레이드계산기();
		System.out.println(cal.add(100, 200));
		System.out.println(cal.add(100, 22.1));
		System.out.println(cal.add(11.1, 22.1));
		System.out.println(cal.add("Ko", "Junho"));
		System.out.println(cal.add("삼성", 100));
		int[] jumsu = cal.add(); // 주소값
		for (int i : jumsu) {
			System.out.print(i  + " ");
		}
		
	}

}
