package 클래스;

public class 계산기 {

	public int mul(int count) {
		//매개변수, 지역변수, call by value(값을 잔달)
		System.out.println("곱하기 처리");
		int price = 5000;
		int sum = price * count;
//		System.out.println("당신이 지불한 금액 총액은 " + sum + "원 입니다.");
		return sum;
	}

	// void : 없다라는 뜻 == > 자료형으로 바꾸어주어야 한다.
	public int add(int coffee, int waffle) {
		System.out.println("더하기 처리");
		int sum = coffee + waffle;
		System.out.println(sum);
		return sum;
	}
}
