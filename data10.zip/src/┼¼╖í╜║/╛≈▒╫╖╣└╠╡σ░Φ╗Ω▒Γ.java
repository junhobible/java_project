package 클래스;

public class 업그레이드계산기 {
	
	public int add(int x, int y) {
		return x + y;
	}
	
	public double add(int x, double y) { // 클래스가 이름이 같아도 자료형이 다르면 자동으로 계산이 바뀐다!!
		return x + y;
	}
	
	public double add(double x, double y) {
		return x + y ;
	}
	
	public String add(String firstName, String lastName) {
		return firstName + lastName;
	}
	
	public String add(String company , int field) {
		return company + field;
	}
	
	public int[] add() {
		int [] jumsu = {100, 99, 88};
		return jumsu;
	}
}
