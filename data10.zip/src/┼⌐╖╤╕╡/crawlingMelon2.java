package 크롤링;

import java.io.IOException;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class crawlingMelon2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con =Jsoup.connect("https://www.melon.com/chart/index.htm");
		// 사진가져오기
		try {
			Document dc = con.get();
			Elements list = dc.select(".image_typeAll img");
			System.out.println(list.size());
			System.out.println(list);
			
			
			String[] contents = new String[list.size()];
			
			for (int i = 0; i < contents.length; i++) {
				contents[i] = dc.select(".image_typeAll img").get(i).attr("src");
			}
			
			for (int i = 0; i < contents.length; i++) {
				System.out.println(contents[i]);
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
