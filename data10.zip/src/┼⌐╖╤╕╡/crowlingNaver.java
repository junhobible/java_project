package 크롤링;

import java.io.FileWriter;
import java.io.IOException;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class crowlingNaver {

	public static void main(String[] args) {
		Connection con = Jsoup.connect("http://www.naver.com");
		try {
			Document doc =  con.get();
			System.out.println(doc);
			Elements elist = doc.select("span.td_ow");	
			System.out.println(elist.size());
			for (int i = 0; i < elist.size(); i++) {
				System.out.println(elist.get(i).text());
				
			}
//
//			String [] contents = new String[elist.size()];
//			
//			for (int i = 0; i < contents.length; i++) {
//				contents[i] = elist.get(i).text();
//			}
//			
//			for (int i = 0; i < contents.length; i++) {
//				System.out.println(contents[i]);
//			}
//			//file에 삽입하기
//			FileWriter file = new FileWriter("naver.txt");
//			for (String s : contents) {
//				file.write(s + "\n");
//			}
//			file.close();
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
		
	

		
	}
}