package 크롤링;

import java.io.IOException;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class crawlingMelon4 {

	public static void main(String[] args) {
		// 가수이름
		Connection con =Jsoup.connect("https://www.melon.com/chart/index.htm");
		// 
		try {
			Document dc = con.get();
			Elements list = dc.select("div.ellipsis.rank02 span");
			System.out.println(list.size());
			System.out.println(list);
			
			
			String[] contents = new String[list.size()];
			
			for (int i = 0; i < contents.length; i++) {
				contents[i] = dc.select("div.ellipsis.rank02 span").get(i).text();
			}
			
			for (int i = 0; i < contents.length; i++) {
				System.out.println(contents[i]);
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
