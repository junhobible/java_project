package 크롤링;

import java.io.IOException;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class crawlingMelon3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con =Jsoup.connect("https://www.melon.com/chart/index.htm");
		// 앨범
		try {
			Document dc = con.get();
			Elements list = dc.select(".ellipsis.rank03 a");
			System.out.println(list.size());
			System.out.println(list);
			
			
			String[] contents = new String[list.size()];
			
			for (int i = 0; i < contents.length; i++) {
				contents[i] = dc.select(".ellipsis.rank03 a").get(i).text();
			}
			
			for (int i = 0; i < contents.length; i++) {
				System.out.println(contents[i]);
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
