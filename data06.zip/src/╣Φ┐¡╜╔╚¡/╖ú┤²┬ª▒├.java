package �迭��ȭ;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.util.Random;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;

public class ����¦�� {
	private static JTextField classmate;
	private static JTextField name;
	public static void main(String[] args) {
		Random r = new Random();
		FlowLayout flow = new FlowLayout();	
		
		
		String[] names = {"ȫ�浿1","ȫ�浿2","ȫ�浿3","ȫ�浿4","ȫ�浿5","ȫ�浿6",
						"ȫ�浿7","ȫ�浿8","ȫ�浿9","ȫ�浿10","ȫ�浿11","ȫ�浿12",
						"ȫ�浿13","ȫ�浿14","ȫ�浿15","ȫ�浿16","ȫ�浿17","ȫ�浿18",
						"ȫ�浿19","ȫ�浿20"};
		
		int[] number = new int[20];
		
		for (int i = 0; i < number.length; i++) {
			number[i] = r.nextInt(20);
			for (int j = 0; j < i; j++) {
				if(number[i] == number[j]) {
					i--;
				}
			}			
		}
		
		for (int i = 0; i < number.length; i++) {
			System.out.println(number[i]);
		}
		JFrame f = new JFrame();
		f.setSize(244, 700);
		f.getContentPane().setLayout(null);		

		
		JButton random = new JButton("random!");
		random.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				for (int i = 1; i <= 10; i++) {
					f.getContentPane().setLayout(flow);
					JButton classmate = new JButton("");
					f.getContentPane().add(classmate);
					classmate.setText(names[number[2*(i-1)]]);
					
					JButton name = new JButton("");
					f.getContentPane().add(name);
					name.setText(names[number[2*i-1]]);
				}
					
			}
		});
		random.setBounds(12, 10, 97, 23);
		f.getContentPane().add(random);	
		
		JButton random_1 = new JButton("random!");
		random_1.setBounds(121, 10, 97, 23);
		f.getContentPane().add(random_1);
		
		
		f.setVisible(true);
		
		}
	}

