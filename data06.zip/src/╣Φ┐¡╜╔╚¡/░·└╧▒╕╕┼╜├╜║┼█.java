package �迭��ȭ;

import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;

public class ���ϱ��Žý��� {
	private static JTextField t2;
	private static JTextField t1;
	static int start = 0;
	static int total = 0;

	public static void main(String[] args) {
			
		String [] fruit = {"���.png", "��.png", "��.png" };
		String [] fruitNames = {"���", "��", "��"};
		int [] fruitPrice = {3000, 5000, 1000};
		int [] fruitCount = new int[3];
	
		
		JFrame f = new JFrame();
		f.setSize(422,245);
		
	
		ImageIcon icon = new ImageIcon(fruit[start]);
		
		JButton image = new JButton("");
		image.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fruitCount[start]++;
	
				for (int i = 0; i < fruitCount.length; i++) {
					total = total + fruitCount[i] * fruitPrice[i] ;
				}				
				t2.setText("�� ���Ż�Ȳ >> " + "���  : " + fruitCount[0]+ ", ��  : " + 
						fruitCount[1] + ", ��  : " + fruitCount[2] + ", �Ѿ� : " + total + "��"  );
			}
		});
		
		image.setIcon(icon);
		
		t2 = new JTextField();
		t2.setFont(new Font("����", Font.BOLD, 13));
		t2.setHorizontalAlignment(SwingConstants.LEFT);
		f.getContentPane().add(t2, BorderLayout.SOUTH);
		t2.setColumns(10);
		t2.setText("�� ���Ż�Ȳ >> " + "���  : " + fruitCount[0]+ ", ��  : " + 
				fruitCount[1] + ", ��  : " + fruitCount[2] + ", �Ѿ� : " + total + "��"  );
		
		
		t1 = new JTextField();
		t1.setForeground(new Color(255, 0, 0));
		t1.setFont(new Font("�޸յձ�������", Font.BOLD, 20));
		t1.setHorizontalAlignment(SwingConstants.CENTER);
		f.getContentPane().add(t1, BorderLayout.NORTH);
		t1.setColumns(10);
		t1.setText(fruitNames[start]);
		
		
		JButton b1 = new JButton("<<");
		b1.setBackground(new Color(188, 143, 143));
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (start == 0) {
					start = start + 2;
				}else {
					start--;
				}
				ImageIcon icon = new ImageIcon(fruit[start]);
				image.setIcon(icon);
				t1.setText(fruitNames[start]);
			}
		});
		
		f.getContentPane().add(b1, BorderLayout.WEST);
		
		JButton b2 = new JButton(">>");
		b2.setBackground(new Color(135, 206, 250));
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (start == 2) {
					start = start -2;
				}else {
					start++;
				}
				ImageIcon icon = new ImageIcon(fruit[start]);
				image.setIcon(icon);
				t1.setText(fruitNames[start]);
			}
		});
		f.getContentPane().add(b2, BorderLayout.EAST);
		
		
		f.getContentPane().add(image, BorderLayout.CENTER);	
		
		
		
		f.setVisible(true);
		
	}

}
