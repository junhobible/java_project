package �迭��ȭ;

public class ��ġ���� {
	public static void main(String[] args) {
		
		int[] num = {66, 77, 33, 22, 99};
		for (int i = 0; i < num.length; i++) {
				if(num[i] < num[i+1]) {
					int temp = num[i];
					num[i] = num[i+1];
					num[i+1] = temp;
				}
			}
				
		for (int i = 0; i < num.length; i++) {
			System.out.println(num[i]);
		}
		 
	}
}
