package ���;

public class ifTest1 {

	public static void main(String[] args) {
		//if
		//if~else
		//if~else if(����)~else
		
		
		//switch 
		
		
	}

}
