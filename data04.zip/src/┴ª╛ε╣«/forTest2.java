package ���;

public class forTest2 {

	public static void main(String[] args) {
		int sum = 0;
		for (int i = 0; i < 11; i++) {
			sum = sum + i;
		}
		System.out.println("������ : " + sum);

	}

}
