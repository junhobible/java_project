package ���;


public class switchTest2 {

	public static void main(String[] args) {
		
		char c = 'A';
		java.util.Date date = new java.util.Date();
		int month = date.getMonth() + 1;
			
			switch (c) {
			case 'A': 
				System.out.println("�ֿ��"); break;
			case 'B':
				System.out.println("���!"); break;
			default:
				System.out.println("����");
			}
			
 	} // main

} // class
