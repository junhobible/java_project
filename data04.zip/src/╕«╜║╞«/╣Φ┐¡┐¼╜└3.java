package ����Ʈ;

import java.util.Random;

public class �迭����3 {

	public static void main(String[] args) {
		
		int [] seat = new int[1000];		
		
		//Random class
		Random rd = new Random();
		

		for (int i = 0; i < seat.length; i++) {
			seat[i] = rd.nextInt(1000);
		}// for
		
//		for (int i = 0; i < seat.length; i++) {
//			System.out.println(seat[i]);
//		}
//		
		int count = 0;
		for (int i = 0; i < seat.length; i++) {
			if(seat[i] == 999) {
				System.out.println("999��ġ : " + i);
				count++;
			}

		}
		System.out.println("999�� ���� : " + count);
		
	} // main

} // class
