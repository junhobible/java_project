package ����Ʈ;

import java.util.Random;
import java.util.Scanner;

public class �迭����5 {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);	
		//1. 
		int count = 0;
		char [] alpha = new char[5];
		
		alpha[0] = 'a';
		alpha[1] = 'b';
		alpha[2] = 'c';
		alpha[3] = 'd';
		alpha[4] = 'e';
		
		for (int i = 0; i < alpha.length; i++) {
			System.out.println(alpha[i]);
		}
		
		for (int i = 0; i < alpha.length; i++) {
			if(alpha[i] == 'a') {
				count++;
			}
		}
		System.out.println("a�� ���� : " + count);
		
		
		//2. 
		
		String[] color = new String[4];
		for (int i = 0; i < color.length; i++) {
			System.out.print("�����ϴ� ���� �Է��ϼ��� >>");
			color[i] = sc.next();
		}
		
		for (int i = 0; i < color.length; i++) {
			System.out.println(color[i]);
		}
		
		//3. 
		
		double[] number = new double[10];
		double sum = 0;
		for (int i = 0; i < number.length; i++) {
			number[i] = i + 0.1;
		}
		
		for (int i = 0; i < number.length; i++) {
			sum = sum + number[i];
		}
		System.out.println("�հ�  :" + sum);
		System.out.println("��� : " + sum/number.length);
		
		
		
		
		
		
		
		 

		
	} // main

} // class
