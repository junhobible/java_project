package 윈도우;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JFormattedTextField;
import javax.swing.ImageIcon;

public class 그래픽연습2 {
	private static JTextField count;
	private static int total_count = 0;
	public static void main(String[] args) {

		//1. 프레임에 해당하는 클래스 필요.
		 JFrame f = new JFrame();		 
		 JLabel total = new JLabel("");
		 count = new JTextField();
		 count.setForeground(Color.BLUE);
		 count.setFont(new Font("굴림", Font.PLAIN, 15));
		 
		 JLabel img = new JLabel("");  // 이미지코드
		 img.setIcon(new ImageIcon("E:\\kjh\\java_project\\data04\\jung.jpg"));
		 img.setBounds(122, 86, 520, 352);
		 f.getContentPane().add(img);

		 
		 total.setForeground(Color.RED);
		 total.setFont(new Font("굴림", Font.BOLD, 40));
		 total.setBackground(Color.WHITE);
		 total.setBounds(272, 448, 321, 59);
		 f.getContentPane().add(total);
		 
		 
		 f.getContentPane().setBackground(new Color(255, 255, 0));
		 
		 f.setSize(782, 556); // 프레임 사이즈
		 f.getContentPane().setLayout(null);
		 
		 JButton jjam = new JButton("짬뽕");
		 jjam.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		total_count++;  //String.valueOf  ==> 정수를 스트링으로 만들어 주는 것.
		 		count.setText(total_count + "개");
		 		total.setText((total_count * 5000) + "원");
		 		ImageIcon icon = new ImageIcon("jjam.jpg");
		 		img.setIcon(icon);
		 	}
		 });
		 jjam.setBackground(new Color(255, 165, 0));
		 jjam.setFont(new Font("굴림", Font.BOLD, 15));
		 jjam.setBounds(12, 10, 124, 53); // 위치를 지정해주는 역할 x, y, 가로길이, 세로길이(왼쪽 위가 기준(0, 0)
		 f.getContentPane().add(jjam);
		 
		 JButton udong = new JButton("우동");
		 udong.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		total_count++;
		 		count.setText(total_count + "개");
		 		total.setText((total_count * 5000) + "원");
		 		ImageIcon icon = new ImageIcon("Udong.jpg");
		 		img.setIcon(icon);
		 	}	
		 });
		 udong.setBackground(new Color(255, 0, 255));
		 udong.setFont(new Font("굴림", Font.BOLD, 15));
		 udong.setBounds(148, 10, 124, 53);
		 f.getContentPane().add(udong);
		 
		 JButton jja = new JButton("자장");
		 jja.setBackground(new Color(0, 255, 255));
		 jja.setFont(new Font("굴림", Font.BOLD, 15));
		 jja.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		total_count++;
		 		count.setText(total_count + "개");
		 		total.setText((total_count * 5000) + "원");
		 		ImageIcon icon = new ImageIcon("jja.jpg");
		 		img.setIcon(icon);
		 	}
		 });
		 jja.setBounds(284, 10, 124, 53);
		 f.getContentPane().add(jja);
		 
		 JTextArea textArea_1 = new JTextArea();
		 textArea_1.setBackground(new Color(255, 255, 0));
		 textArea_1.setFont(new Font("Monospaced", Font.BOLD, 26));
		 textArea_1.setText("지불할 총 금액");
		 textArea_1.setBounds(51, 454, 209, 40);
		 f.getContentPane().add(textArea_1);
		 
		 count.setBounds(514, 7, 188, 59);
		 f.getContentPane().add(count);
		 count.setColumns(10);
		 
		 JLabel lblNewLabel = new JLabel("개수입력");
		 lblNewLabel.setFont(new Font("휴먼둥근헤드라인", Font.PLAIN, 15));
		 lblNewLabel.setBackground(Color.PINK);
		 lblNewLabel.setBounds(420, 23, 74, 40);
		 f.getContentPane().add(lblNewLabel);  				 
		 f.setVisible(true); // 계속 뜨게하는 클래스(맨 마지막에 둔다)	
		
	}// main
}// class
