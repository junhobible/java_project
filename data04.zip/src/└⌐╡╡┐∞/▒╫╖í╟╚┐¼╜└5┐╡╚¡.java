package ������;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class �׷��ȿ���5��ȭ {
	private static JTextField t2;
	private static int count1 = 0;	// ��Ǫ���
	private static int count2 = 0;  // ������ �ĺ�
	private static int count3 = 0;  // 1917
	private static int count4 = 0;  // ���� �ƾ���
	private static int count5 = 0;  // Ŭ����

	public static void main(String[] args) {

		JFrame f = new JFrame();
		
		JLabel t1 = new JLabel(""); 			// ��ȭ����
		t1.setForeground(new Color(255, 0, 0));
		t1.setFont(new Font("�޸յձ�������", Font.BOLD, 20));
		t1.setBounds(327, 165, 219, 64);
		
		t2 = new JTextField();					// �Ѱ���
		t2.setForeground(new Color(0, 0, 255));
		t2.setFont(new Font("�޸յձ�������", Font.PLAIN, 30));
		t2.setBounds(187, 506, 271, 45);
		f.getContentPane().add(t2);
		t2.setColumns(10);
		
		JLabel t3 = new JLabel("");				// ��ȭǥ����
		t3.setForeground(Color.RED);
		t3.setFont(new Font("�޸յձ�������", Font.BOLD, 20));
		t3.setBounds(327, 253, 219, 64);
		f.getContentPane().add(t3);
				
		f.getContentPane().add(t1);
		f.getContentPane().setBackground(new Color(0, 250, 154));
		f.setSize(599, 614);
		f.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("\uC601\uD654 \uC0AC\uC9C4 \uCD9C\uB825 \uD504\uB85C\uADF8\uB7A8");
		lblNewLabel.setBackground(new Color(255, 215, 0));
		lblNewLabel.setFont(new Font("HY�߰���", Font.PLAIN, 34));
		lblNewLabel.setForeground(Color.BLUE);
		lblNewLabel.setBounds(107, 10, 396, 64);
		f.getContentPane().add(lblNewLabel);

		JLabel image = new JLabel("");
		image.setIcon(new ImageIcon("E:\\kjh\\java_project\\data04\\\uC601\uD6546.png"));
		image.setBounds(79, 165, 440, 318);
		f.getContentPane().add(image);

		JButton B1 = new JButton("\uC9C0\uD478\uB77C\uAE30");
		B1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon icon = new ImageIcon("��ȭ1.jpg");
				image.setIcon(icon);
				t1.setText("��ȭ���� : 9.16");
				t3.setText("��ȭ���� : 8000��");
				count1++;
				t2.setText(8000*count1 + 9000*count2 + 10000*count3 + 8500*count4 + 9500*count5 + "��");
			}
		});
		B1.setFont(new Font("HY������B", Font.BOLD, 13));
		B1.setBounds(28, 99, 97, 31);
		f.getContentPane().add(B1);

		JButton B2 = new JButton("\uC815\uC9C1\uD55C\uD6C4\uBCF4");
		B2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon icon = new ImageIcon("��ȭ2.jpg");
				image.setIcon(icon);
				t1.setText("��ȭ���� : 8.74");
				t3.setText("��ȭ���� : 9000��");
				count2++;
				t2.setText(8000*count1 + 9000*count2 + 10000*count3 + 8500*count4 + 9500*count5 + "��");
			}
		});
		B2.setFont(new Font("HY������B", Font.BOLD, 13));
		B2.setBounds(143, 99, 97, 31);
		f.getContentPane().add(B2);

		JButton B3 = new JButton("1917");
		B3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon icon = new ImageIcon("��ȭ3.jpg");
				image.setIcon(icon);
				t1.setText("��ȭ���� : 9.76");
				count3++;
				t2.setText(8000*count1 + 9000*count2 + 10000*count3 + 8500*count4 + 9500*count5 + "��");
				t3.setText("��ȭ���� : 10000��");
			}
		});
		B3.setFont(new Font("HY������B", Font.BOLD, 13));
		B3.setBounds(252, 99, 97, 31);
		f.getContentPane().add(B3);

		JButton B4 = new JButton("\uC791\uC740\uC544\uC528");
		B4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon icon = new ImageIcon("��ȭ4.jpg");
				image.setIcon(icon);
				t1.setText("��ȭ���� : 9.27");
				t3.setText("��ȭ���� : 8500��");
				count4++;
				t2.setText(8000*count1 + 9000*count2 + 10000*count3 + 8500*count4 + 9500*count5 + "��");
			}
		});
		B4.setFont(new Font("HY������B", Font.BOLD, 13));
		B4.setBounds(361, 99, 97, 31);
		f.getContentPane().add(B4);

		
		JButton B5 = new JButton("\uD074\uB85C\uC82F");
		B5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon icon = new ImageIcon("��ȭ5.jpg");
				image.setIcon(icon);
				t1.setText("��ȭ���� : 8.47");
				t3.setText("��ȭ���� : 9500��");
				count5++;
				t2.setText(8000*count1 + 9000*count2 + 10000*count3 + 8500*count4 + 9500*count5 + "��");
			}
		});
		B5.setFont(new Font("HY������B", Font.BOLD, 13));
		B5.setBounds(470, 99, 97, 31);
		f.getContentPane().add(B5);
		
		JLabel lblNewLabel_1 = new JLabel("\uCD1D\uAC00\uACA9");
		lblNewLabel_1.setFont(new Font("�޸յձ�������", Font.PLAIN, 30));
		lblNewLabel_1.setBounds(78, 506, 97, 45);
		f.getContentPane().add(lblNewLabel_1);		
						
		f.setVisible(true); // �� ������
		}
		
	}


