package control;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import database.DtoGuest;
import database.DtoMember;
import user_join.SeatPopup;
import user_join.SeatsGraphic;

public class CheckSeat {
	
	public void checkseat(JFrame j,int i, int seatNum, DtoMember dto, SeatPopup sp) {
		if (seatNum == i) {
			JOptionPane.showMessageDialog(null, "이미 선택한 자리입니다. 다른 자리를 선택하세요");
		}else{
			dto.setSeat_num(i);
			sp.popup2(j,dto);		// dto 자체를 넘겨준다.	
		}
	}
	
	public void checkseat(JFrame j,int i, int seatNum, DtoGuest gdto, SeatPopup sp) {
		if (seatNum == i) {
			JOptionPane.showMessageDialog(null, "이미 선택한 자리입니다. 다른 자리를 선택하세요");
		}else{
			gdto.setSeat_num(i);
			sp.popup2(j,gdto);		// dto 자체를 넘겨준다.	
		}
	}
	
}
