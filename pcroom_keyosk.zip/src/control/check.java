package control;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import database.DaoConn;

public class check {
	
	DaoConn con = new DaoConn();
	Connection con1 =con.conn();
	
	public Boolean read_for_id(String choice) { // 아이디 비교
		
		try {
			String s = "select * from member";			
			PreparedStatement ps = con1.prepareStatement(s);
			ResultSet rs = ps.executeQuery(); //읽어들일때는 ResultSet과 아래를 쓴다.
			while(rs.next()) {
				if(rs.getString("id").equals(choice)) {
					return true;
				}
			}				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public Boolean checkLogin_pw(String id, String choice) { // 비밀번호 비교, 로그인
		
		try {
			String s = "select pw from member where id = "+ id;			
			PreparedStatement ps = con1.prepareStatement(s);
			ResultSet rs = ps.executeQuery(); //읽어들일때는 ResultSet과 아래를 쓴다.
			rs.next();
			if(rs.getString("pw").equals(choice)) {
				return true;
			}				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public Boolean read_for_pw(String choice) {
		
		try {
			String s = "select * from member";			
			PreparedStatement ps = con1.prepareStatement(s);
			ResultSet rs = ps.executeQuery(); //읽어들일때는 ResultSet과 아래를 쓴다.
			while(rs.next()) {
				if(rs.getString("pw").equals(choice)) {
					return true;
				}
			}				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
}
