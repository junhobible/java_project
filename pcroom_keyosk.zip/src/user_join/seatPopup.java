package user_join;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class seatPopup {
	/**
	 * @wbp.parser.entryPoint
	 */
	public void popup() {
		
	JFrame f = new JFrame();
	f.setSize(451, 160);
	Login log = new Login();
	f.getContentPane().setLayout(null);
	JButton b1 = new JButton("yes");
	b1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {			 
			log.login();
			f.dispose();
		}
	});
	b1.setBounds(104, 60, 89, 36);
	f.getContentPane().add(b1);
	
	JButton b2 = new JButton("no");
	b2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			String result = b2.getText();
			System.out.println(result);
			f.dispose();
		}
	});
	b2.setBounds(245, 60, 89, 36);
	f.getContentPane().add(b2);
	
	JLabel lblNewLabel = new JLabel("좌석을 선택하시겠습니까?");
	lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
	lblNewLabel.setBounds(26, 22, 386, 28);
	f.getContentPane().add(lblNewLabel);
	
	
	f.setVisible(true);
}
}
