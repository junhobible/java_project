package user_join;

import java.awt.Color;
import java.awt.ScrollPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.stream.IntStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;

import control.CheckSeat;
import database.DtoGuest;
import database.DtoMember;
import database.GueDaoCrud;
import database.MemDaoCrud;


public class SeatsGraphic {

	static JFrame fFirst = null;
	MemDaoCrud dao = new MemDaoCrud();
	GueDaoCrud gdao = new GueDaoCrud();


	
	public void seatsgraphic(DtoMember dto) {
	
		if (dto == null) {		
			seats();
		} else {
			seats2(dto);
		}

	}
	
	public void seatsgraphic(DtoGuest gdto) {
		
		if (gdto == null) {		
			seats();
		} else {
			seats2(gdto);
		}

	}
	
	
	/**
	 * @wbp.parser.entryPoint
	 */
	public void seats() {
		
		fFirst = new JFrame();
		fFirst.setTitle("컴퓨터 선택");
		fFirst.getContentPane().setBackground(Color.BLACK);
		
		ArrayList<DtoGuest> dtoList = gdao.select(); // 전체 자료 불러오기
		int[] seatNum2 = new int[dtoList.size()];
		ArrayList<DtoMember> dtoList2 = dao.select();
		int[] seatNum3 = new int[dtoList2.size()];
		
		ArrayList<Integer> totallist = new ArrayList<Integer>();
		
		
		for (int i = 0; i < dtoList.size(); i++) {
			seatNum2[i] = dtoList.get(i).getSeat_num();
		}
		
		for (int i = 0; i < dtoList2.size(); i++) {
			seatNum3[i] = dtoList2.get(i).getSeat_num();
			}
		
		
		for (int i = 0; i < seatNum2.length; i++) {
			totallist.add(seatNum2[i]);
			
		}
		
		for (int i = 0; i < seatNum3.length; i++) {
			totallist.add(seatNum3[i]);
		}
				
		int[] totalNum = new int[totallist.size()];
		for (int i = 0; i < totalNum.length; i++) {
		
			totalNum[i] = totallist.get(i);
			System.out.println(totalNum[i]);
		}

		/**
		 * @wbp.parser.entryPoint
		 */
		fFirst.setSize(564, 420);
		fFirst.setBackground(Color.BLACK);
		fFirst.getContentPane().setLayout(null);
		SeatPopup sp = new SeatPopup();
		
//		Arrays.stream(배열).anyMatch(특정 값::equals);
//		(equals 외에 String 의 다른 메소드도 사용이 가능하다.)
//		IntStream.of(배열).anyMatch(x -> x == 특정 숫자);
		
		
		JButton[] button_list = new JButton[16];
		
		
		
		button_list[0] = new JButton("1");
		button_list[0].setBackground(Color.LIGHT_GRAY);
		button_list[0].setBounds(12, 45, 97, 62);
		fFirst.getContentPane().add(button_list[0]);
		button_list[0].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {				
				if(IntStream.of(totalNum).anyMatch(x -> x == 1)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					JButton button = button_list[0];
					sp.popup(button, 1, fFirst); // button 자체를 넘겨준다.
				}
				
			}
		});
						
		
		
		button_list[1] = new JButton("2");
		button_list[1].setBackground(Color.LIGHT_GRAY);
		button_list[1].setBounds(121, 45, 97, 62);
		fFirst.getContentPane().add(button_list[1]);
		button_list[1].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {				
				if(IntStream.of(totalNum).anyMatch(x -> x == 2)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					JButton button = button_list[1];
					sp.popup(button, 2, fFirst); // button 자체를 넘겨준다.
				}
				
			}
		});

		button_list[2] = new JButton("3");
		button_list[2].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 3)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					JButton button = button_list[2];
					sp.popup(button, 3, fFirst); // button 자체를 넘겨준다.
				}
			}
		});
		button_list[2].setBackground(Color.LIGHT_GRAY);
		button_list[2].setBounds(12, 117, 97, 62);
		fFirst.getContentPane().add(button_list[2]);

		button_list[3] = new JButton("4");
		button_list[3].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 4)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					JButton button = button_list[3];
					sp.popup(button, 4, fFirst); // button 자체를 넘겨준다.
				}
			}
		});
		button_list[3].setBackground(Color.LIGHT_GRAY);
		button_list[3].setBounds(121, 117, 97, 62);
		fFirst.getContentPane().add(button_list[3]);

		button_list[4] = new JButton("5");
		button_list[4].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 5)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					JButton button = button_list[4];
					sp.popup(button, 5, fFirst); // button 자체를 넘겨준다.
				}
			}
		});
		button_list[4].setBackground(Color.LIGHT_GRAY);
		button_list[4].setBounds(12, 189, 97, 62);
		fFirst.getContentPane().add(button_list[4]);

		button_list[5] = new JButton("6");
		button_list[5].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 6)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					JButton button = button_list[5];
					sp.popup(button, 6, fFirst); // button 자체를 넘겨준다.
				}
			}
		});
		button_list[5].setBackground(Color.LIGHT_GRAY);
		button_list[5].setBounds(121, 189, 97, 62);
		fFirst.getContentPane().add(button_list[5]);

		button_list[6] = new JButton("7");
		button_list[6].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 7)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					JButton button = button_list[6];
					sp.popup(button, 7, fFirst); // button 자체를 넘겨준다.
				}
			}

		});
		button_list[6].setBackground(Color.LIGHT_GRAY);
		button_list[6].setBounds(12, 261, 97, 62);
		fFirst.getContentPane().add(button_list[6]);

		button_list[7] = new JButton("8");
		button_list[7].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 8)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					JButton button = button_list[7];
					sp.popup(button, 8, fFirst); // button 자체를 넘겨준다.
				}
			}
		});
		button_list[7].setBackground(Color.LIGHT_GRAY);
		button_list[7].setBounds(121, 261, 97, 62);
		fFirst.getContentPane().add(button_list[7]);

		button_list[8] = new JButton("9");
		button_list[8].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 9)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					JButton button = button_list[8];
					sp.popup(button, 9, fFirst); // button 자체를 넘겨준다.
				}
			}
		});
		button_list[8].setBackground(Color.LIGHT_GRAY);
		button_list[8].setBounds(330, 45, 97, 62);
		fFirst.getContentPane().add(button_list[8]);

		button_list[9] = new JButton("10");
		button_list[9].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 10)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					JButton button = button_list[9];
					sp.popup(button, 10, fFirst); // button 자체를 넘겨준다.
				}
			}
		});
		button_list[9].setBackground(Color.LIGHT_GRAY);
		button_list[9].setBounds(439, 45, 97, 62);
		fFirst.getContentPane().add(button_list[9], fFirst);

		button_list[10] = new JButton("11");
		button_list[10].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 11)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					JButton button = button_list[10];
					sp.popup(button, 11, fFirst); // button 자체를 넘겨준다.
				}
			}
		});
		button_list[10].setBackground(Color.LIGHT_GRAY);
		button_list[10].setBounds(330, 117, 97, 62);
		fFirst.getContentPane().add(button_list[10]);

		button_list[11] = new JButton("12");
		button_list[11].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 12)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					JButton button = button_list[11];
					sp.popup(button, 12, fFirst); // button 자체를 넘겨준다.
				}
			}

		});
		button_list[11].setBackground(Color.LIGHT_GRAY);
		button_list[11].setBounds(439, 117, 97, 62);
		fFirst.getContentPane().add(button_list[11]);

		button_list[12] = new JButton("13");
		button_list[12].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 13)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					JButton button = button_list[12];
					sp.popup(button, 13, fFirst); // button 자체를 넘겨준다.
				}
			}
		});
		button_list[12].setBackground(Color.LIGHT_GRAY);
		button_list[12].setBounds(330, 189, 97, 62);
		fFirst.getContentPane().add(button_list[12]);

		button_list[13] = new JButton("14");
		button_list[13].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 14)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					JButton button = button_list[13];
					sp.popup(button, 14, fFirst); // button 자체를 넘겨준다.
				}
			}
		});
		button_list[13].setBackground(Color.LIGHT_GRAY);
		button_list[13].setBounds(439, 189, 97, 62);
		fFirst.getContentPane().add(button_list[13]);

		button_list[14] = new JButton("15");
		button_list[14].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 15)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					JButton button = button_list[14];
					sp.popup(button, 15, fFirst); // button 자체를 넘겨준다.
				}
			}
		});
		button_list[14].setBackground(Color.LIGHT_GRAY);
		button_list[14].setBounds(330, 261, 97, 62);
		fFirst.getContentPane().add(button_list[14]);

		button_list[15] = new JButton("16");
		button_list[15].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 16)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					JButton button = button_list[15];
					sp.popup(button, 16, fFirst); // button 자체를 넘겨준다.
				}
			}
		});
		button_list[15].setBackground(Color.LIGHT_GRAY);
		button_list[15].setBounds(439, 261, 97, 62);
		fFirst.getContentPane().add(button_list[15]);
		
		JButton btnNewButton = new JButton("종료");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		btnNewButton.setBounds(451, 358, 97, 23);
		fFirst.getContentPane().add(btnNewButton);
		
		for (int i : totalNum) {
			if(i == 0) {
				System.out.println("자리번호가 0인 사람입니다.");
			}else {
				button_list[i -1].setBackground(Color.BLUE);
			}
		}
		

		
		fFirst.setVisible(true);
	}
////////////////////////////////////////////////////////////////////
	public void seats2(DtoMember dto) { // 로그인후 자리변경하기(비회원, 다형성)
		System.out.println("자리함수" + dto);
		int seatNum = dto.getSeat_num();
		JFrame f = new JFrame();
		f.setSize(564, 420);
		f.setLocation(1200, 0);
		f.getContentPane().setLayout(null);
		f.setTitle("좌석 다시 선택하기");
		SeatPopup sp = new SeatPopup();
		CheckSeat cs = new CheckSeat();
		
		
		ArrayList<DtoGuest> dtoList = gdao.select(); // 전체 자료 불러오기
		int[] seatNum2 = new int[dtoList.size()];
		ArrayList<DtoMember> dtoList2 = dao.select();
		int[] seatNum3 = new int[dtoList2.size()];
		
		ArrayList<Integer> totallist = new ArrayList<Integer>();
		
		
		for (int i = 0; i < dtoList.size(); i++) {
			seatNum2[i] = dtoList.get(i).getSeat_num();
			
		}
		
		for (int i = 0; i < dtoList2.size(); i++) {
			seatNum3[i] = dtoList2.get(i).getSeat_num();
			
		}
		
		for (int i = 0; i < seatNum2.length; i++) {
			totallist.add(seatNum2[i]);
		}
		
		for (int i = 0; i < seatNum3.length; i++) {
			totallist.add(seatNum3[i]);
		}
				
		int[] totalNum = new int[totallist.size()];
		for (int i = 0; i < totalNum.length; i++) {
			totalNum[i] = totallist.get(i);
			System.out.println(totalNum[i]);
		}


		JButton[] button_list = new JButton[16];
		for (int i = 0; i < button_list.length; i++) {
			String j = Integer.toString(i + 1);
			button_list[i] = new JButton(j);
		}
		
		button_list[0].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 1)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					
					cs.checkseat(f, 1, seatNum, dto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[0].setBackground(Color.LIGHT_GRAY);
		button_list[0].setBounds(12, 45, 97, 62);
		f.getContentPane().add(button_list[0]);

		button_list[1].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 2)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 2, seatNum, dto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[1].setBackground(Color.LIGHT_GRAY);
		button_list[1].setBounds(121, 45, 97, 62);
		f.getContentPane().add(button_list[1]);

		button_list[2] = new JButton("3");
		button_list[2].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 3)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 3, seatNum, dto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[2].setBackground(Color.LIGHT_GRAY);
		button_list[2].setBounds(12, 117, 97, 62);
		f.getContentPane().add(button_list[2]);

		button_list[3].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 4)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 4, seatNum, dto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[3].setBackground(Color.LIGHT_GRAY);
		button_list[3].setBounds(121, 117, 97, 62);
		f.getContentPane().add(button_list[3]);

		button_list[4].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 5)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 5, seatNum, dto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[4].setBackground(Color.LIGHT_GRAY);
		button_list[4].setBounds(12, 189, 97, 62);
		f.getContentPane().add(button_list[4]);

		button_list[5].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 6)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 6, seatNum, dto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[5].setBackground(Color.LIGHT_GRAY);
		button_list[5].setBounds(121, 189, 97, 62);
		f.getContentPane().add(button_list[5]);

		button_list[6].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 7)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 7, seatNum, dto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}

		});
		button_list[6].setBackground(Color.LIGHT_GRAY);
		button_list[6].setBounds(12, 261, 97, 62);
		f.getContentPane().add(button_list[6]);

		button_list[7].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 8)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 8, seatNum, dto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[7].setBackground(Color.LIGHT_GRAY);
		button_list[7].setBounds(121, 261, 97, 62);
		f.getContentPane().add(button_list[7]);

		button_list[8].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 9)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 9, seatNum, dto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[8].setBackground(Color.LIGHT_GRAY);
		button_list[8].setBounds(330, 45, 97, 62);
		f.getContentPane().add(button_list[8]);

		button_list[9].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 10)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 10, seatNum, dto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[9].setBackground(Color.LIGHT_GRAY);
		button_list[9].setBounds(439, 45, 97, 62);
		f.getContentPane().add(button_list[9], f);

		button_list[10] = new JButton("11");
		button_list[10].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 11)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 11, seatNum, dto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[10].setBackground(Color.LIGHT_GRAY);
		button_list[10].setBounds(330, 117, 97, 62);
		f.getContentPane().add(button_list[10]);

		button_list[11].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 12)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 12, seatNum, dto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[11].setBackground(Color.LIGHT_GRAY);
		button_list[11].setBounds(439, 117, 97, 62);
		f.getContentPane().add(button_list[11]);

		button_list[12].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 13)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 13, seatNum, dto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[12].setBackground(Color.LIGHT_GRAY);
		button_list[12].setBounds(330, 189, 97, 62);
		f.getContentPane().add(button_list[12]);

		button_list[13].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 14)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 14, seatNum, dto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[13].setBackground(Color.LIGHT_GRAY);
		button_list[13].setBounds(439, 189, 97, 62);
		f.getContentPane().add(button_list[13]);

		button_list[14].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 15)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 15, seatNum, dto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[14].setBackground(Color.LIGHT_GRAY);
		button_list[14].setBounds(330, 261, 97, 62);
		f.getContentPane().add(button_list[14]);

		button_list[15].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 16)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 16, seatNum, dto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[15].setBackground(Color.LIGHT_GRAY);
		button_list[15].setBounds(439, 261, 97, 62);
		f.getContentPane().add(button_list[15]);

		
		
		for (int i : totalNum) {
			if(i == 0) {
				System.out.println("자리번호가 0인 사람입니다.");
			}else {
				button_list[i -1].setBackground(Color.BLUE);
			}
		}
		
		button_list[seatNum - 1].setBackground(Color.ORANGE);
		f.setVisible(true);
	}
	
	/////////////////////////////////////////////////////////

	/**
	 * @wbp.parser.entryPoint
	 */
	public void seats2(DtoGuest gdto) { // 로그인후 자리변경하기(비회원, 다형성)
		System.out.println("자리함수" + gdto);
		int seatNum = gdto.getSeat_num();
		JFrame f = new JFrame();
		f.setSize(564, 420);
		f.setLocation(1200, 0);
		f.getContentPane().setLayout(null);
		f.setTitle("좌석 다시 선택하기");
		SeatPopup sp = new SeatPopup();
		CheckSeat cs = new CheckSeat();
		
		
		ArrayList<DtoGuest> dtoList = gdao.select(); // 전체 자료 불러오기
		int[] seatNum2 = new int[dtoList.size()];
		ArrayList<DtoMember> dtoList2 = dao.select();
		int[] seatNum3 = new int[dtoList2.size()];
		
		ArrayList<Integer> totallist = new ArrayList<Integer>();
		
		
		for (int i = 0; i < dtoList.size(); i++) {
			seatNum2[i] = dtoList.get(i).getSeat_num();
			System.out.println(seatNum2[i]);
		}
		
		for (int i = 0; i < dtoList2.size(); i++) {
			seatNum3[i] = dtoList2.get(i).getSeat_num();
			System.out.println(seatNum3[i]);
		}
		
		for (int i = 0; i < seatNum2.length; i++) {
			totallist.add(seatNum2[i]);
		}
		
		for (int i = 0; i < seatNum3.length; i++) {
			totallist.add(seatNum3[i]);
		}
				
		int[] totalNum = new int[totallist.size()];
		for (int i = 0; i < totalNum.length; i++) {
		
			totalNum[i] = totallist.get(i);
			System.out.println(totalNum[i]);
		}

		JButton[] button_list = new JButton[16];
		
		for (int i = 0; i < button_list.length; i++) {
			String j = Integer.toString(i + 1);
			button_list[i] = new JButton(j);
		}
		
		
		
		button_list[0].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 1)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					
					cs.checkseat(f, 1, seatNum, gdto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[0].setBackground(Color.LIGHT_GRAY);
		button_list[0].setBounds(12, 45, 97, 62);
		f.getContentPane().add(button_list[0]);

		button_list[1].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 2)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 2, seatNum, gdto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[1].setBackground(Color.LIGHT_GRAY);
		button_list[1].setBounds(121, 45, 97, 62);
		f.getContentPane().add(button_list[1]);

		button_list[2] = new JButton("3");
		button_list[2].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 3)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 3, seatNum, gdto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[2].setBackground(Color.LIGHT_GRAY);
		button_list[2].setBounds(12, 117, 97, 62);
		f.getContentPane().add(button_list[2]);

		button_list[3].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 4)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 4, seatNum, gdto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[3].setBackground(Color.LIGHT_GRAY);
		button_list[3].setBounds(121, 117, 97, 62);
		f.getContentPane().add(button_list[3]);

		button_list[4].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 5)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 5, seatNum, gdto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[4].setBackground(Color.LIGHT_GRAY);
		button_list[4].setBounds(12, 189, 97, 62);
		f.getContentPane().add(button_list[4]);

		button_list[5].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 6)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 6, seatNum, gdto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[5].setBackground(Color.LIGHT_GRAY);
		button_list[5].setBounds(121, 189, 97, 62);
		f.getContentPane().add(button_list[5]);

		button_list[6].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 7)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 7, seatNum, gdto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}

		});
		button_list[6].setBackground(Color.LIGHT_GRAY);
		button_list[6].setBounds(12, 261, 97, 62);
		f.getContentPane().add(button_list[6]);

		button_list[7].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 8)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 8, seatNum, gdto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[7].setBackground(Color.LIGHT_GRAY);
		button_list[7].setBounds(121, 261, 97, 62);
		f.getContentPane().add(button_list[7]);

		button_list[8].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 9)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 9, seatNum, gdto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[8].setBackground(Color.LIGHT_GRAY);
		button_list[8].setBounds(330, 45, 97, 62);
		f.getContentPane().add(button_list[8]);

		button_list[9].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 10)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 10, seatNum, gdto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[9].setBackground(Color.LIGHT_GRAY);
		button_list[9].setBounds(439, 45, 97, 62);
		f.getContentPane().add(button_list[9], f);

		button_list[10] = new JButton("11");
		button_list[10].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 11)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 11, seatNum, gdto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[10].setBackground(Color.LIGHT_GRAY);
		button_list[10].setBounds(330, 117, 97, 62);
		f.getContentPane().add(button_list[10]);

		button_list[11].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 12)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 12, seatNum, gdto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[11].setBackground(Color.LIGHT_GRAY);
		button_list[11].setBounds(439, 117, 97, 62);
		f.getContentPane().add(button_list[11]);

		button_list[12].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 13)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 13, seatNum, gdto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[12].setBackground(Color.LIGHT_GRAY);
		button_list[12].setBounds(330, 189, 97, 62);
		f.getContentPane().add(button_list[12]);

		button_list[13].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 14)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 14, seatNum, gdto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[13].setBackground(Color.LIGHT_GRAY);
		button_list[13].setBounds(439, 189, 97, 62);
		f.getContentPane().add(button_list[13]);

		button_list[14].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 15)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 15, seatNum, gdto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[14].setBackground(Color.LIGHT_GRAY);
		button_list[14].setBounds(330, 261, 97, 62);
		f.getContentPane().add(button_list[14]);

		button_list[15].addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(IntStream.of(totalNum).anyMatch(x -> x == 16)) {
					JOptionPane.showMessageDialog(null, "이미 선택된 자리입니다.");
				}else {
					cs.checkseat(f, 16, seatNum, gdto, sp); // 체크하는 함수를 따로 만듬 - > 바로 유저인터페이스로 가는 함수.
				}
			}
		});
		button_list[15].setBackground(Color.LIGHT_GRAY);
		button_list[15].setBounds(439, 261, 97, 62);
		f.getContentPane().add(button_list[15]);

		
		
		for (int i : totalNum) {
			if(i == 0) {
				System.out.println("자리번호가 0인 사람입니다.");
			}else {
				button_list[i -1].setBackground(Color.BLUE);
			}
		}
		
		button_list[seatNum - 1].setBackground(Color.ORANGE);
		f.setVisible(true);
	}
	

}
