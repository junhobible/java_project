package user_join;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import control.TimeTrans;
import database.MemDaoCrud;
import database.DaoConn;
import database.DtoGuest;
import database.DtoMember;
import database.GueDaoCrud;

public class UserInter {
	private JLabel t1;
	private JLabel t2;
	private JLabel t3;
	private JLabel t4;
	private JLabel timeCheck;
	private JFrame f;
	private SeatsGraphic sc;
	private DtoMember dto;
	private DtoGuest gdto;
	private GueDaoCrud gdao = new GueDaoCrud();
	private MemDaoCrud dao = new MemDaoCrud();
	SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	TimeTrans ttr = new TimeTrans();
	StopFlagThread1 tt1; // Thread !!!!!
	StopFlagThread2 tt2;
	StopFlagThread3 tt3;
	StopFlagThread4 tt4;
	public int leftTime = 0;

//	sql
	/**
	 * @wbp.parser.entryPoint
	 */
	public void userInter(DtoMember dto, JFrame j) {
		this.dto = dto;
		System.out.println("userinter :" + dto);
		f = new JFrame();
		f.getContentPane().setBackground(Color.GRAY);

		f.setSize(454, 363);
		f.setLocation(1400, 0);
		f.getContentPane().setLayout(null);

		JLabel label = new JLabel("");
		label.setForeground(Color.YELLOW);
		label.setFont(new Font("여기어때 잘난체", Font.PLAIN, 20));
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(12, 10, 71, 51);
		label.setText(dto.getSeat_num() + "번");
		f.getContentPane().add(label);

		JLabel b1 = new JLabel("더 좋은 pc방");
		b1.setForeground(Color.WHITE);
		b1.setFont(new Font("여기어때 잘난체", Font.PLAIN, 26));
		b1.setHorizontalAlignment(SwingConstants.CENTER);
		b1.setBounds(91, 10, 272, 37);
		f.getContentPane().add(b1);

		JPanel panel = new JPanel();
		panel.setBackground(Color.DARK_GRAY);
		panel.setBounds(22, 87, 404, 182);
		f.getContentPane().add(panel);
		panel.setLayout(null);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBounds(12, 10, 380, 156);
		panel.add(panel_1);
		panel_1.setLayout(null);

		JLabel lblNewLabel_2 = new JLabel("회원이름");
		lblNewLabel_2.setBounds(41, 11, 70, 25);
		panel_1.add(lblNewLabel_2);

		t1 = new JLabel();
		t1.setBounds(142, 13, 116, 21);
		panel_1.add(t1);
		t1.setText(dto.getId()); // 회원 id 출력

		JLabel lblNewLabel_2_1 = new JLabel("시작일시");
		lblNewLabel_2_1.setBounds(41, 40, 67, 26);
		panel_1.add(lblNewLabel_2_1);

		t2 = new JLabel();
		t2.setBounds(142, 43, 116, 21);
		panel_1.add(t2);
		t2.setText(format1.format(dto.getTime_login()));

		JLabel lblNewLabel_2_2 = new JLabel("사용시간");
		lblNewLabel_2_2.setBounds(41, 70, 65, 24);
		panel_1.add(lblNewLabel_2_2);

		t3 = new JLabel();
		t3.setBounds(142, 72, 116, 21);
		panel_1.add(t3);

		timeCheck = new JLabel("");
		timeCheck.setBackground(new Color(240, 240, 240));
		timeCheck.setForeground(Color.WHITE);
		timeCheck.setFont(new Font("휴먼둥근헤드라인", Font.BOLD, 15));
		timeCheck.setHorizontalAlignment(SwingConstants.CENTER);
		timeCheck.setBounds(322, 20, 104, 15);
		f.getContentPane().add(timeCheck);

		
		


		JLabel lblNewLabel_2_3 = new JLabel("남은시간");
		lblNewLabel_2_3.setBounds(41, 97, 67, 28);
		panel_1.add(lblNewLabel_2_3);

		t4 = new JLabel();
		t4.setBounds(142, 101, 116, 21);
		panel_1.add(t4);

		JButton btnNewButton = new JButton("정보수정");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Join j = new Join();
				j.join(dto);
			}
		});
		btnNewButton.setBounds(322, 56, 104, 23);
		f.getContentPane().add(btnNewButton);

		JButton b2 = new JButton("자리이동");
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				long time = tt1.returnValue();
				dto.setTime_left(time);
				dao.update(dto);
				System.out.println("userinter" + dto);
				sc = new SeatsGraphic();
				sc.seatsgraphic(dto);
//				j.dispose();
//				sc.seatsgraphic(null);
				f.dispose();
			}
		});
		b2.setBounds(122, 279, 97, 23);
		f.getContentPane().add(b2);

		JButton b3 = new JButton("사용종료");
		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result = JOptionPane.showConfirmDialog(null, "정말 종료하시겠습니까?", "종료", JOptionPane.YES_NO_OPTION);
				if (result == JOptionPane.CLOSED_OPTION) {

				} else if (result == JOptionPane.YES_OPTION) {
					long time = tt1.returnValue();
					dto.setTime_left(time);
					dto.setSeat_num(0);
					dao.update(dto);
					SeatsGraphic.fFirst.dispose();
					sc = new SeatsGraphic();
					sc.seats();
					f.dispose();
					tt1.setStop1(true);
					tt2.setStop2(true);
				} else {

				}

			}
		});
		b3.setBounds(246, 279, 97, 23);
		f.getContentPane().add(b3);

		tt1 = new StopFlagThread1(dto); // Thread !!!!!
		tt2 = new StopFlagThread2(dto);
		tt1.start();
		tt2.start();
		if(tt2.returnValue() == 22) {
			JOptionPane.showMessageDialog(null, "10시 입니다. 자동종료합니다.");				
			f.dispose();
			sc = new SeatsGraphic();
			sc.seats();
			tt1.setStop1(false);
			tt2.setStop2(false);
		}
		f.setVisible(true);
	}
	
	// 남은 시간 계산 함수  스레드(스톱기능 추가)
	public class StopFlagThread1 extends Thread {
		// stop 플래그 변수
		private boolean isStop;
		private long time1 = System.currentTimeMillis();
		private long time2 = 0;
		private long time_result= 0;
		Date date;

		public StopFlagThread1(DtoMember dto) { // 안에 변수를 받기 위한 함수이다.
			this.time2 = dto.getTime_left();
			System.out.println("타임스레드 : " + dto);

		}

		public void run() {
			while (!isStop) {
				try {
					Thread.sleep(500);

					long time3 = System.currentTimeMillis();
					Date date = new Date();
					t3.setText(ttr.timetrans((time3 - time1) / 1000)); // 사용시간
					time_result = time2 - ((time3 - time1) / 1000);	
					System.out.println(time_result);
					if(time_result == 0) {
					JOptionPane.showMessageDialog(null, "남은 시간이 0원입니다.");
					f.dispose();
					sc = new SeatsGraphic();
					sc.seats();
					tt1.setStop1(false);
					tt2.setStop2(false);			
				}
					t4.setText(ttr.timetrans(time_result)); // 남은 시간 
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		public void setStop1(boolean isStop) {
			this.isStop = isStop;
		}

		public long returnValue() {
			return time_result;
		}
	}

	// 현재시간 시현 스래드(스톱기능 추가)

	public class StopFlagThread2 extends Thread {
		// stop 플래그 변수
		String adult;
		private int time_present = 0; // 현재 시각
		private boolean isStop;
		public StopFlagThread2(DtoMember dto) {  // 안에 변수를 받기 위한 함수이다.
				this.adult = dto.getAdultYn();
				
			}

		public void run() {
			while (true) {
				try {
					Thread.sleep(500);
					Date time = new Date();
					SimpleDateFormat format2 = new SimpleDateFormat("HH:mm:ss");
					timeCheck.setText(format2.format(time));
//						
//						
					if (time.getHours() == 21 && time.getMinutes() == 55 && adult == "N") {
						JOptionPane.showMessageDialog(null, "미성년자입니다. 10시 5분전이니 종료하세요!");
					}

					if (time.getHours() == 22) {
						time_present = 22;
						dto.setTime_left(tt1.returnValue());
						dao.update(dto);
					}

				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}

		public void setStop2(boolean isStop) {
			this.isStop = isStop;
		}
		
		public int returnValue() {
			return time_present; // 현재 시각 
		}
	}
	
	
	
	//////////////////////////////////////////////////////////////////////
	public void userInter(DtoGuest dto, JFrame j) { // 게스트이용시
		this.gdto = dto;
		System.out.println("userinter :" + gdto);
		f = new JFrame();
		f.getContentPane().setBackground(Color.GRAY);

		f.setSize(454, 363);
		f.setLocation(1400, 0);
		f.getContentPane().setLayout(null);

		JLabel label = new JLabel("");
		label.setForeground(Color.YELLOW);
		label.setFont(new Font("여기어때 잘난체", Font.PLAIN, 20));
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(12, 10, 71, 51);
		label.setText(gdto.getSeat_num() + "번");
		f.getContentPane().add(label);

		JLabel b1 = new JLabel("더 좋은 pc방");
		b1.setForeground(Color.WHITE);
		b1.setFont(new Font("여기어때 잘난체", Font.PLAIN, 26));
		b1.setHorizontalAlignment(SwingConstants.CENTER);
		b1.setBounds(91, 10, 272, 37);
		f.getContentPane().add(b1);

		JPanel panel = new JPanel();
		panel.setBackground(Color.DARK_GRAY);
		panel.setBounds(22, 87, 404, 182);
		f.getContentPane().add(panel);
		panel.setLayout(null);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBounds(12, 10, 380, 156);
		panel.add(panel_1);
		panel_1.setLayout(null);

		JLabel lblNewLabel_2 = new JLabel("회원이름");
		lblNewLabel_2.setBounds(41, 11, 70, 25);
		panel_1.add(lblNewLabel_2);

		t1 = new JLabel();
		t1.setBounds(142, 13, 116, 21);
		panel_1.add(t1);
		t1.setText(Integer.toString(gdto.getLogin_num())); // 회원 id 출력

		JLabel lblNewLabel_2_1 = new JLabel("시작일시");
		lblNewLabel_2_1.setBounds(41, 40, 67, 26);
		panel_1.add(lblNewLabel_2_1);

		t2 = new JLabel();
		t2.setBounds(142, 43, 116, 21);
		panel_1.add(t2);
		t2.setText(format1.format(gdto.getTime_login()));

		JLabel lblNewLabel_2_2 = new JLabel("사용시간");
		lblNewLabel_2_2.setBounds(41, 70, 65, 24);
		panel_1.add(lblNewLabel_2_2);

		t3 = new JLabel();
		t3.setBounds(142, 72, 116, 21);
		panel_1.add(t3);

		timeCheck = new JLabel("");
		timeCheck.setBackground(new Color(240, 240, 240));
		timeCheck.setForeground(Color.WHITE);
		timeCheck.setFont(new Font("휴먼둥근헤드라인", Font.BOLD, 15));
		timeCheck.setHorizontalAlignment(SwingConstants.CENTER);
		timeCheck.setBounds(322, 20, 104, 15);
		f.getContentPane().add(timeCheck);

		JLabel lblNewLabel_2_3 = new JLabel("남은시간");
		lblNewLabel_2_3.setBounds(41, 97, 67, 28);
		panel_1.add(lblNewLabel_2_3);

		t4 = new JLabel();
		t4.setBounds(142, 101, 116, 21);
		panel_1.add(t4);

	
		JButton b2 = new JButton("자리이동");
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				long time = tt3.returnValue();
				gdto.setTime_left(time);
				gdao.update(gdto);
				System.out.println("userinter" + gdto);
				sc = new SeatsGraphic();
				sc.seatsgraphic(gdto);
//				j.dispose();
//				sc.seatsgraphic(null);
				f.dispose();
			}
		});
		b2.setBounds(122, 279, 97, 23);
		f.getContentPane().add(b2);

		JButton b3 = new JButton("사용종료");
		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result = JOptionPane.showConfirmDialog(null, "정말 종료하시겠습니까?", "종료", JOptionPane.YES_NO_OPTION);
				if (result == JOptionPane.CLOSED_OPTION) {

				} else if (result == JOptionPane.YES_OPTION) {
					long time = tt3.returnValue();
					gdto.setTime_left(time);
					gdto.setSeat_num(0);
					System.out.println("종료 : " + gdto);
					gdao.update(gdto);
					SeatsGraphic.fFirst.dispose();
					sc = new SeatsGraphic();
					sc.seats();
					f.dispose();
					tt3.setStop1(true);
					tt4.setStop2(true);
				} else {

				}

			}
		});
		b3.setBounds(246, 279, 97, 23);
		f.getContentPane().add(b3);
		tt3 = new StopFlagThread3(gdto); // Thread !!!!!
		tt4 = new StopFlagThread4(gdto);
		tt3.start();
		tt4.start();
		if(tt4.returnValue() == 22) {
			JOptionPane.showMessageDialog(null, "10시 입니다. 자동종료합니다.");				
			f.dispose();
			sc = new SeatsGraphic();
			sc.seats();
			tt3.setStop1(true);
			tt4.setStop2(true);
		}
		f.setVisible(true);
	}



	
	// 남은 시간 계산 함수  스레드(스톱기능 추가) ----- 비회원용

	public class StopFlagThread3 extends Thread {
		// stop 플래그 변수
		private boolean isStop;
		private long time1 = System.currentTimeMillis();
		private long time2 = 0;
		private long time_result = 0;
		Date date;

		public StopFlagThread3(DtoGuest gdto) { // 안에 변수를 받기 위한 함수이다.
			this.time2 = gdto.getTime_left();
			System.out.println("스레드 : " + time2);
		}

		public void run() {
			while (!isStop) {
				try {
					Thread.sleep(500);
					long time3 = System.currentTimeMillis();
					t3.setText(ttr.timetrans((time3 - time1) / 1000)); // 사용시간
					time_result = time2 - ((time3 - time1) / 1000);
					System.out.println(time_result);
					t4.setText(ttr.timetrans(time_result)); // 남은 시간 
					if(time_result == 0) {
					JOptionPane.showMessageDialog(null, "남은 시간이 0입니다.");
					f.dispose();
					sc = new SeatsGraphic();
					sc.seats();
					tt3.setStop1(false);
					tt4.setStop2(false);			
				}
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		public void setStop1(boolean isStop) {
			this.isStop = isStop;
		}

		public long returnValue() {
			return time_result;
		}
	}

	// 현재시간 시현 스래드(스톱기능 추가)

	public class StopFlagThread4 extends Thread {
		// stop 플래그 변수
		String adult;
		private int time_present = 0; // 현재 시각
		private boolean isStop;
		public StopFlagThread4(DtoGuest gdto) {  // 안에 변수를 받기 위한 함수이다.
				this.adult = gdto.getAdult_YN();
				
			}

		public void run() {
			while (true) {
				try {
					Thread.sleep(500);
					Date time = new Date();
					SimpleDateFormat format2 = new SimpleDateFormat("HH:mm:ss");
					timeCheck.setText(format2.format(time));
//						
//						
					if (time.getHours() == 21 && time.getMinutes() == 55 && adult == "N") {
						JOptionPane.showMessageDialog(null, "미성년자입니다. 10시 5분전이니 종료하세요!");
					}

					if (time.getHours() == 22) {
						time_present = 22;
						gdto.setTime_left(tt3.returnValue());
						gdao.update(gdto);
					}

				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}

		public void setStop2(boolean isStop) {
			this.isStop = isStop;
		}
		
		public int returnValue() {
			return time_present; // 현재 시각 
		}
	}

}

// Thread ★★★★★★★★
