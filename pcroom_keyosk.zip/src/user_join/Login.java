package user_join;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import control.check;
import database.DaoCrud;
import database.DtoMember;

public class Login {
	private JTextField t1;
	private JTextField t2;
	private JTextField t3;
	DaoCrud cr = new DaoCrud();
	check ck = new check();
	UserInter ui = new UserInter();	
	DtoMember dto = new DtoMember();
	Date time = new Date();
	/**
	 * @wbp.parser.entryPoint
	 */
	public void login(JButton button, int seatNum, JFrame j) {
		
		JFrame	f = new JFrame();
		f.setSize(493, 313);
		f.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("더조은 PC방");
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setFont(new Font("휴먼편지체", Font.PLAIN, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(64, 10, 262, 42);
		f.getContentPane().add(lblNewLabel);
		
		t1 = new JTextField();
		t1.setBounds(133, 83, 151, 35);
		f.getContentPane().add(t1);
		t1.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("ID");
		lblNewLabel_1.setFont(new Font("휴먼엑스포", Font.PLAIN, 20));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(41, 83, 57, 35);
		f.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("PW");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("휴먼엑스포", Font.PLAIN, 20));
		lblNewLabel_1_1.setBounds(41, 128, 57, 35);
		f.getContentPane().add(lblNewLabel_1_1);
		
		t2 = new JTextField();
		t2.setColumns(10);
		t2.setBounds(133, 128, 151, 35);
		f.getContentPane().add(t2);
		
		JLabel lblNewLabel_1_2 = new JLabel("비회원");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setFont(new Font("휴먼엑스포", Font.PLAIN, 20));
		lblNewLabel_1_2.setBounds(41, 187, 68, 35);
		f.getContentPane().add(lblNewLabel_1_2);
		
		t3 = new JTextField();
		t3.setColumns(10);
		t3.setBounds(133, 187, 151, 35);
		f.getContentPane().add(t3);
		
		JButton b2 = new JButton("로그인");
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			  boolean id = cr.read_for_id(t1.getText());
			  boolean pw = ck.read_for_pw(t2.getText());
			  DaoCrud dc = new DaoCrud();
			  DtoMember dtoTemp = dc.select(t1.getText());
			  if(id && pw) {
				  System.out.println("select :" + dto.getTime_left());
				  if(dtoTemp.getTime_left() == 0) {
					  JOptionPane.showMessageDialog(null, "해당 아이디에 남은 시간이 없습니다. 충전하세요");
				  }else {
					  JOptionPane.showMessageDialog(null, "로그인 되었습니다.");				  
					  System.out.println("select : " + dtoTemp);
					  dto.setId(t1.getText());
					  dto.setSeat_num(seatNum);
					  dto.setTime_login(time);
					  dto.setPw(dtoTemp.getPw());
					  dto.setName(dtoTemp.getName());
					  dto.setGender(dtoTemp.getGender());
					  dto.setBirth(dtoTemp.getBirth());
					  dto.setTel(dtoTemp.getTel());
					  dto.setAddr(dtoTemp.getAddr());
					  dto.setEmail(dtoTemp.getEmail());
					  dto.setTime_left(dtoTemp.getTime_left());
					  cr.update(dto);
					  button.setBackground(Color.BLUE);
					  ui.userInter(dto);
					  j.dispose();
					  f.dispose();
				  	}
			  }else {
				  JOptionPane.showMessageDialog(null, "아이디나 패스워드가 틀렸습니다.");  
				  }
				  
			  }
				
			});
		b2.setBounds(341, 97, 110, 98);
		f.getContentPane().add(b2);
		
		JButton b1 = new JButton("회원가입");
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Join jg = new Join();
				jg.join();
			}
		});
		
		
		b1.setBounds(338, 21, 113, 23);
		f.getContentPane().add(b1);
		
		JLabel seatNumber = new JLabel("");
		seatNumber.setFont(new Font("굴림", Font.BOLD, 25));
		seatNumber.setBounds(12, 10, 86, 53);
		f.getContentPane().add(seatNumber);
		seatNumber.setText(Integer.toString(seatNum) + "번");
		
		
		f.setVisible(true);
	
	}
}
