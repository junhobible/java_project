package user_join;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import database.Crud;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Login {
	private JTextField t1;
	private JTextField t2;
	private JTextField t3;
	Crud cr = new Crud();
	check ck = new check();
	/**
	 * @wbp.parser.entryPoint
	 */
	public void login() {
		
		JFrame	f = new JFrame();
		f.setSize(493, 313);
		f.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("더조은 PC방");
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setFont(new Font("휴먼편지체", Font.PLAIN, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(64, 10, 262, 42);
		f.getContentPane().add(lblNewLabel);
		
		t1 = new JTextField();
		t1.setBounds(133, 83, 151, 35);
		f.getContentPane().add(t1);
		t1.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("ID");
		lblNewLabel_1.setFont(new Font("휴먼엑스포", Font.PLAIN, 20));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(41, 83, 57, 35);
		f.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("PW");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("휴먼엑스포", Font.PLAIN, 20));
		lblNewLabel_1_1.setBounds(41, 128, 57, 35);
		f.getContentPane().add(lblNewLabel_1_1);
		
		t2 = new JTextField();
		t2.setColumns(10);
		t2.setBounds(133, 128, 151, 35);
		f.getContentPane().add(t2);
		
		JLabel lblNewLabel_1_2 = new JLabel("비회원");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setFont(new Font("휴먼엑스포", Font.PLAIN, 20));
		lblNewLabel_1_2.setBounds(41, 187, 68, 35);
		f.getContentPane().add(lblNewLabel_1_2);
		
		t3 = new JTextField();
		t3.setColumns(10);
		t3.setBounds(133, 187, 151, 35);
		f.getContentPane().add(t3);
		
		JButton b2 = new JButton("로그인");
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			  Boolean id = cr.read_for_id(t1.getText());
			  Boolean pw = ck.read_for_pw(t2.getText());
			  
			  if(id && pw) {
				  JOptionPane.showMessageDialog(null, "로그인 되었습니다.");
				  f.dispose();
			  }else {
				  JOptionPane.showMessageDialog(null, "아이디나 패스워드가 틀렸습니다.");
			  }
				
			}
		});
		b2.setBounds(341, 97, 110, 98);
		f.getContentPane().add(b2);
		
		JButton b1 = new JButton("회원가입");
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Join jg = new Join();
				jg.join();
			}
		});
		b1.setBounds(338, 21, 113, 23);
		f.getContentPane().add(b1);
		
		
		
		
		
		
		f.setVisible(true);
	
	}
}
