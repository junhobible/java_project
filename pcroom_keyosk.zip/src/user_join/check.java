package user_join;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import database.Conn;

public class check {
	
	Conn con = new Conn();
	Connection con1 =con.conn();
	
	public Boolean read_for_id(String choice) {
		
		try {
			String s = "select * from member";			
			PreparedStatement ps = con1.prepareStatement(s);
			ResultSet rs = ps.executeQuery(); //읽어들일때는 ResultSet과 아래를 쓴다.
			while(rs.next()) {
				if(rs.getString("id").equals(choice)) {
					return true;
				}
			}				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public Boolean checkLogin_pw(String choice) {
		
		try {
			String s = "select pw from member where id";			
			PreparedStatement ps = con1.prepareStatement(s);
			ResultSet rs = ps.executeQuery(); //읽어들일때는 ResultSet과 아래를 쓴다.
			rs.next();
			if(rs.getString("pw").equals(choice)) {
				return true;
			}				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public Boolean read_for_pw(String choice) {
		
		try {
			String s = "select * from member";			
			PreparedStatement ps = con1.prepareStatement(s);
			ResultSet rs = ps.executeQuery(); //읽어들일때는 ResultSet과 아래를 쓴다.
			while(rs.next()) {
				if(rs.getString("pw").equals(choice)) {
					return true;
				}
			}				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
}
