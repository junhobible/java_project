package user_join;

import database.DtoMember;

public class main {

	public static void main(String[] args) {
		SeatsGraphic sg = new SeatsGraphic();
		SeatsGraphic sg2 = sg;
		DtoMember dto_temp = null;

		sg.seatsgraphic(dto_temp);
	}

}
