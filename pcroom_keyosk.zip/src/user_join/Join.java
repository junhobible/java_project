package user_join;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import database.Crud;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;

public class Join {
	private JTextField t1;
	private JTextField t2;
	private JTextField t3;
	private JTextField t4;
	private JTextField t5;
	private JTextField t6;
	private JTextField t7;
	Crud cr = new Crud();
	
		/**
		 * @wbp.parser.entryPoint
		 */
		public void join() {
			JFrame f = new JFrame();
			f.setSize(400, 600);
			f.getContentPane().setLayout(null);
			
			JLabel lblNewLabel = new JLabel("회원가입");
			lblNewLabel.setBackground(new Color(240, 240, 240));
			lblNewLabel.setFont(new Font("굴림", Font.PLAIN, 20));
			lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel.setBounds(75, 10, 236, 35);
			f.getContentPane().add(lblNewLabel);
			
			JLabel lblNewLabel_1 = new JLabel("아이디");
			lblNewLabel_1.setFont(new Font("굴림", Font.PLAIN, 20));
			lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_1.setBounds(33, 68, 105, 35);
			f.getContentPane().add(lblNewLabel_1);
			
			t1 = new JTextField();
			t1.setBounds(165, 70, 126, 35);
			f.getContentPane().add(t1);
			t1.setColumns(10);
			
			JLabel lblNewLabel_1_1 = new JLabel("비밀번호");
			lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_1_1.setFont(new Font("굴림", Font.PLAIN, 20));
			lblNewLabel_1_1.setBounds(33, 113, 105, 35);
			f.getContentPane().add(lblNewLabel_1_1);
			
			t2 = new JTextField();
			t2.setColumns(10);
			t2.setBounds(165, 115, 184, 35);
			f.getContentPane().add(t2);
			
			JLabel lblNewLabel_1_2 = new JLabel("이름");
			lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_1_2.setFont(new Font("굴림", Font.PLAIN, 20));
			lblNewLabel_1_2.setBounds(33, 158, 105, 35);
			f.getContentPane().add(lblNewLabel_1_2);
			
			t3 = new JTextField();
			t3.setColumns(10);
			t3.setBounds(165, 160, 184, 35);
			f.getContentPane().add(t3);
			
			JLabel lblNewLabel_1_3 = new JLabel("성별");
			lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_1_3.setFont(new Font("굴림", Font.PLAIN, 20));
			lblNewLabel_1_3.setBounds(33, 204, 105, 35);
			f.getContentPane().add(lblNewLabel_1_3);
			
			JLabel lblNewLabel_1_4 = new JLabel("생년월일");
			lblNewLabel_1_4.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_1_4.setFont(new Font("굴림", Font.PLAIN, 20));
			lblNewLabel_1_4.setBounds(33, 249, 105, 35);
			f.getContentPane().add(lblNewLabel_1_4);
			
			t4 = new JTextField();
			t4.setColumns(10);
			t4.setBounds(165, 251, 98, 35);
			f.getContentPane().add(t4);
			
			JLabel lblNewLabel_1_5 = new JLabel("전화번호");
			lblNewLabel_1_5.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_1_5.setFont(new Font("굴림", Font.PLAIN, 20));
			lblNewLabel_1_5.setBounds(33, 294, 105, 35);
			f.getContentPane().add(lblNewLabel_1_5);
			
			t5 = new JTextField();
			t5.setColumns(10);
			t5.setBounds(165, 296, 184, 35);
			f.getContentPane().add(t5);
			
			JLabel lblNewLabel_1_6 = new JLabel("이메일");
			lblNewLabel_1_6.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_1_6.setFont(new Font("굴림", Font.PLAIN, 20));
			lblNewLabel_1_6.setBounds(33, 339, 105, 35);
			f.getContentPane().add(lblNewLabel_1_6);
			
			t6 = new JTextField();
			t6.setColumns(10);
			t6.setBounds(165, 341, 184, 35);
			f.getContentPane().add(t6);
			
			JCheckBox c3 = new JCheckBox("성인");
			c3.setBounds(284, 257, 65, 23);
			f.getContentPane().add(c3);
			
			JLabel z = new JLabel("주소");
			z.setHorizontalAlignment(SwingConstants.CENTER);
			z.setFont(new Font("굴림", Font.PLAIN, 20));
			z.setBounds(33, 380, 105, 35);
			f.getContentPane().add(z);
			
			t7 = new JTextField();
			t7.setColumns(10);
			t7.setBounds(165, 382, 184, 35);
			
			JRadioButton radio_ma = new JRadioButton("남자");
			radio_ma.setBounds(175, 212, 58, 23);
			f.getContentPane().add(radio_ma);
			
			JRadioButton radio_fe = new JRadioButton("여자");
			radio_fe.setBounds(253, 212, 58, 23);
			f.getContentPane().add(radio_fe);
			
			ButtonGroup groupRd = new ButtonGroup(); // radio 그룹처리해서 양쪽선택 불가하게 한다.
			groupRd.add(radio_ma);
			groupRd.add(radio_fe);	
			
			
			JButton b1 = new JButton("확인");
			b1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					if(cr.read_for_id(t1.getText())) {
						JOptionPane.showMessageDialog(null, "아이디를 새로입력하세요!");
					}else{
//						cr.insert(id, pw, name, gender, birth, tel, email, addr);
						String gender;
						if(radio_ma.isSelected()) {
							 gender = "M";
						}else {
							gender = "F";
						}
						cr.insert(t1.getText(), 
								t2.getText(), 
								t3.getText(), 
								gender, 
								t4.getText(), 
								t5.getText(), 
								t6.getText(), 
								t7.getText());
						f.dispose();
					}
//					
				}
			});
			b1.setBounds(75, 442, 105, 35);
			f.getContentPane().add(b1);
			
			JButton b2 = new JButton("취소");
			b2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					f.dispose();
				}
				
			});
			b2.setBounds(206, 442, 105, 35);
			f.getContentPane().add(b2);
			
			
			f.getContentPane().add(t7);
			
			JButton b3 = new JButton("중복");
			b3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(cr.read_for_id(t1.getText())) {
						JOptionPane.showMessageDialog(null, "중복된 아이디가 있습니다.");						
					}else {
						JOptionPane.showMessageDialog(null, "중복된 아이디가 없습니다.");
					}
				}	
					});
			b3.setBounds(299, 68, 65, 35);
			f.getContentPane().add(b3);
			
			
			
			f.setVisible(true);
		
		}
}
