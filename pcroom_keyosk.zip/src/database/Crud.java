package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class Crud {
	
	Conn con = new Conn();
	Connection con1 =con.conn();
	
	public void insert(String id , String pw, String name, String gender, 
					   String birth, String tel, String email, String addr) {
		try {
			String s = "insert into member values (?, ?, ?, ?, ?, ?, ?, ?, 0, 0,0)";
			PreparedStatement ps = con1.prepareStatement(s);
			ps.setString(1, id);
			ps.setString(2, pw);
			ps.setString(3, name);
			ps.setString(4, gender);
			ps.setString(5, birth);
			ps.setString(6, tel);
			ps.setString(7, email);
			ps.setString(8, addr);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public Boolean read_for_id(String choice) {
			
		try {
			String s = "select * from member";			
			PreparedStatement ps = con1.prepareStatement(s);
			ResultSet rs = ps.executeQuery(); //읽어들일때는 ResultSet과 아래를 쓴다.
			while(rs.next()) {
				if(rs.getString("id").equals(choice)) {
					return true;
				}
			}				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	

	
	public void update(String some, String id) {
		try {
			String s = "update member set ? where id = ?";			
			PreparedStatement ps = con1.prepareStatement(s);
			ps.setString(1, some);
			ps.setString(2, id);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void delete(String id) {
		try {
			String s = "delete from member where id = ?";	
			PreparedStatement ps = con1.prepareStatement(s);
			ps.setString(1, id);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	 
}
