package database;

import java.sql.DriverManager;

public class Conn {
	
	String url = "jdbc:mysql://localhost:3708/pcroom";
	String user = "root";
	String password = "1234";
	java.sql.Connection con1;
	public java.sql.Connection conn(){
		try {
			Class.forName("com.mysql.jdbc.Driver");			
			java.sql.Connection con2 = 
					DriverManager.getConnection(url, user, password);
			con1 = con2;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con1;
	}
}
