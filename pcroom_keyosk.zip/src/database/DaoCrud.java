package database;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class DaoCrud {
	
	DaoConn con = new DaoConn();
	Connection con1 =con.conn();
	
	public void insert(DtoMember dto) {
		try {
			String s = "insert into member values (?, ?, ?, ?, ?, ?, ?, ?, 0, 0,0)";
			PreparedStatement ps = con1.prepareStatement(s);
			ps.setString(1, dto.getId());
			ps.setString(2, dto.getPw());
			ps.setString(3, dto.getName());
			ps.setString(4, dto.getGender());
			ps.setString(5, dto.getBirth());
			ps.setString(6, dto.getTel());
			ps.setString(7, dto.getEmail());
			ps.setString(8, dto.getAddr());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	
	public void update(DtoMember dto) {
		try {
			String s = "update member set pw = ?,  name =?, gender = ?, "
					+ " birth =?, tel = ?, email = ?, addr = ?, seat_num = ?, time_left = ?, time_login =?  where id = ?";			
			PreparedStatement ps = con1.prepareStatement(s);
			SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String time = format1.format(dto.getTime_login());
			Timestamp t = Timestamp.valueOf(time);
			ps.setString(1, dto.getPw());
			ps.setString(2, dto.getName());
			ps.setString(3, dto.getGender());
			ps.setString(4, dto.getBirth());
			ps.setString(5, dto.getTel());
			ps.setString(6, dto.getEmail());
			ps.setString(7, dto.getAddr());
			ps.setLong(8, dto.getSeat_num());
			ps.setLong(9, dto.getTime_left());
			ps.setTimestamp(10, t);
			ps.setString(11, dto.getId());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void update(DtoMember dto, Boolean bool) {
		try {
			String s = "update member set pw = ?,  name =?, gender = ?, "
					+ " birth =?, tel = ?, email = ?, addr = ? where id = ?";			
			PreparedStatement ps = con1.prepareStatement(s);
			ps.setString(1, dto.getPw());
			ps.setString(2, dto.getName());
			if(bool) {
				ps.setString(3, "M");
			}else {
				ps.setString(3,  "F");
			}			
			ps.setString(4, dto.getBirth());
			ps.setString(5, dto.getTel());
			ps.setString(6, dto.getEmail());
			ps.setString(7, dto.getAddr());
			ps.setString(8, dto.getId());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void delete(DtoMember dto) {	
		try {
			String s = "delete from member where id = ?";	
			PreparedStatement ps = con1.prepareStatement(s);
			ps.setString(1, dto.getId());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	 
	public DtoMember select(String id) {
		
		String sql = "select * from member where id = ?";
		DtoMember dto = null;
		try {
			PreparedStatement ps= con1.prepareStatement(sql);
			ps.setString(1, id);
			ResultSet rs =ps.executeQuery();
			if(rs.next()) {
				dto = new DtoMember();
				dto.setId(rs.getString(1));
				dto.setPw(rs.getString(2));
				dto.setName(rs.getString(3));
				dto.setGender(rs.getString(4));
				dto.setBirth(rs.getString(5));
				dto.setTel(rs.getString(6));
				dto.setEmail(rs.getString(7));
				dto.setAddr(rs.getString(8));	
				dto.setTime_left(rs.getLong(9));
				System.out.println(rs.getLong(9));
			}else {
				System.out.println("셀렉트 함수가 자료가 없습니다.");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return dto;
	}	
	
	public Boolean read_for_id(String choice) { // id를 검색하는 메서드			
		try {
			String s = "select * from member";			
			PreparedStatement ps = con1.prepareStatement(s);
			ResultSet rs = ps.executeQuery(); //읽어들일때는 ResultSet과 아래를 쓴다.
			while(rs.next()) {
				if(rs.getString("id").equals(choice)) {
					return true;
				}
			}				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public int read_for_time_left(String id) {
		int result = 0;
		String sql = "select * from member where id = ?";
		PreparedStatement ps;
		try {
			ps = con1.prepareStatement(sql);
			ps.setString(1, id);
			ResultSet rs =ps.executeQuery();
			if(rs.next()) {
				result = rs.getInt(9);
			}else {
				System.out.println("데이터를 불러오는데 실패했습니다.");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}
}
