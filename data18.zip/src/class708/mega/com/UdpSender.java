package class708.mega.com;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class UdpSender {

	public static void main(String[] args) throws Exception {
//	udp :  패킷이 주소를 보고 알아서 간다.
//전송용 소켓
	DatagramSocket	ds = new DatagramSocket(); // 주소를 받을 필요가 없다.(패킷이 가짐)
		
		String data = "I am Happy";
		byte[] buf = data.getBytes();// byte로 변경
		InetAddress address = InetAddress.getByName("127.0.0.1");
		DatagramPacket dp = new DatagramPacket(buf, buf.length, 
				address, 9999);
		ds.send(dp);
		System.out.println("udp pocket 전송완료.");
		ds.close();
		
		
	}

}
