package class708.mega.com;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class DomainToIp {
	public static void main(String[] args) throws Exception {
		String name = "www.naver.com";
		InetAddress ipInfo = InetAddress.getByName(name);
		System.out.println(ipInfo);
	}
}
