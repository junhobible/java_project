package class708.mega.com;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class UdpReceiver {

	public static void main(String[] args) throws Exception {
		
		DatagramSocket socket = new DatagramSocket(9999);
		System.out.println("9999 port data 받을 준비 중");
		byte[] buf = new byte[256];
		DatagramPacket p = new DatagramPacket(buf, buf.length );
		socket.receive(p);
		System.out.println("받은 데이터" + new String(buf));

	}

}
