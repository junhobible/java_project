package class708.mega.com;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;

public class TcpClient3 {
	public static void main(String[] args) throws Exception{
		Socket socket = new Socket("localhost", 9100);
		System.out.println("client1 : 서버와 연결 성공!!");
		// 임시저장 곤간에 모든 문자를 다 지벙넣어놨다가 한줄씩 철하는 것이 편리, socket.getInputstream 은 한글자씩 읽어온다.

		BufferedReader buffer = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		
		String result = buffer.readLine();
		
		socket.close();
		System.out.println("받은 데이터 : "  + result);
	}
}
