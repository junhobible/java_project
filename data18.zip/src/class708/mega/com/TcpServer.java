package class708.mega.com;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class TcpServer {
	public static void main(String[] args) throws Exception {
		// 1. 승인만 하는 소켓이 있어야 한다.
		ServerSocket server = new ServerSocket(9100); // port를 만들어준다. 
		
		System.out.println("tcp 서버 소켓 시작됨");
		System.out.println("클라이언트의 연결을 기다리는 중");
		int numberClient = 0; // 지역변수는 자동초기화가 되지 않음.
		while(true) {
			Socket socket = server.accept();
			System.out.println("클라이언트와 연결 성공");	
			System.out.println("port: " + socket.getPort()); // client의 포트를 받아오며 local은 임의로 부여된다.
			// 1. ip를 가지고 와서,
			// 어느 ip로부터 연결요청 들어왔음.
			InetAddress Ip= socket.getInetAddress();
			System.out.println(Ip+ "로부터 연결요청이 들어왔음.");
			String ip2 = Ip.toString();			
			if(ip2.equals("/127.0.0.1")) {
				System.out.println("내 자리 입니다. ");
				String data = "I am a java programmer!!!";
				PrintWriter out = new PrintWriter(socket.getOutputStream(), true);// 데이터를 전송 
				// tcp는 받는 소켓과 주는 소켓이 다르다.(udp와의 차이) 
				out.println(data);				
			}else {
				System.out.println("외부에서는 전송을 할 수 없음.");
			}
			numberClient++;
			System.out.println("접속한 클라이언트 수 : " + numberClient);			
		}
		
		
//		2. 승인이 떨어지면 통신할 수 있는 별도의 소켓 객체 생성
		
	}
}
