package �迭;

public class arrayTest2 {

	public static void main(String[] args) {
		
		String [] names = {"ȫ�浿","��浿","�۱浿","�ڱ浿", "���浿"}; // �̹� �˰� �ִ� ���
		
		for (int i = 0; i < names.length; i++) {
			System.out.println(names[i]);
		}
		
		// �ƴ� ������� ����
		
		int [] ages = {20, 21, 23, 24,51};
		char [] gender= {'m', 'f', 'f', 'm', 'f'};
		
		for (int i = 0; i < ages.length; i++) {
			System.out.println(ages[i]);
		}
		
		for (int i : ages) {
			System.out.println(i);
		}
		
		for (int i = 0; i < gender.length; i++) {
			System.out.println(gender[i]);
		}
		
		for (char c : gender) {
			System.out.println(c);
		}
	}

}
