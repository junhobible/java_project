package �迭;

import java.util.Scanner;

public class arrayTest3 {

	public static void main(String[] args) {
		
		// �迭 �Է�Ȱ��
		Scanner sc = new Scanner(System.in);
		int[] number = new int[5];
		for (int i = 0; i < 5; i++) {
			System.out.print("�����Է� >>");
			number[i] = sc.nextInt();
		}
		
		int sum = 0;
		
		for (int i : number) {
			sum = sum + i;
		}
		
		System.out.println((double)sum/number.length);
	}

}
