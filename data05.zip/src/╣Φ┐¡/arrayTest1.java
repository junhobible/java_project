package �迭;

import java.util.Iterator;

public class arrayTest1 {

	public static void main(String[] args) {
			
		//100���� ��ȭ�����Ͱ� �ʿ�.
		
		String [] names = new String[100]; // String ������ ����
		// �迭�� �ڵ� �ʱ�ȭ int -> 0, double -> 0.0, String -> null
		
		names[0] = "�����";
		System.out.println(names[0]);
		
		names[names.length - 1]	= "1917";
		System.out.println(names[names.length - 1]);	
		
		
		System.out.println(names);
		for (int i = 0; i < names.length; i++) {
			System.out.println(i +": " +names[i]);
		}
		
		// foreach
		for (String n : names) {
			System.out.println(n);
		}
		
		int[] customers = new int[100];
		customers[0] = 1000;
		customers[99] = 500;
		
		for (int i = 0; i < customers.length; i++) {
			System.out.println(i + ":" + customers[i]);
		}
		
		for (int i : customers) {	//integer�� i�̴�.
			System.out.println(i);
		}
		
		
	
	
	}

}
