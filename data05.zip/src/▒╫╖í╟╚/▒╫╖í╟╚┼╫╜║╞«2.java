package �׷���;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class �׷����׽�Ʈ2 {
	public static void main(String[] args) {
		
		JFrame f = new JFrame();
		f.setSize(300, 300);
		FlowLayout flow = new FlowLayout();
		f.setLayout(flow);
		String [] subject = new String[3];
		int [] subjectCount = new int[3];
		

		for (int i = 0; i < 3; i++) {
			subject[i] = JOptionPane.showInputDialog("�����Է�");
		}
		
		for (int i = 0; i < 3; i++) {
			JButton b = new JButton(subject[i]);
			f.add(b);
			b.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(b.getText().equals("Java")) {
						subjectCount[0]++;
						f.setTitle("Java : " + subjectCount[0] + ", jsp : " + subjectCount[1] + ", spring : " + subjectCount[2]);
					}else if(b.getText().equals("jsp")) {
						subjectCount[1]++;
						f.setTitle("Java : " + subjectCount[0] + ", jsp : " + subjectCount[1] + ", spring : " + subjectCount[2]);
					}else if(b.getText().equals("spring")) {
						subjectCount[2]++;
						f.setTitle("Java : " + subjectCount[0] + ", jsp : " + subjectCount[1] + ", spring : " + subjectCount[2]);
					}
				}
			});
		}		
		f.setVisible(true);

	}
}
