package �׷���;

import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.image.ImagingOpException;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JScrollBar;

public class ��ȣ�� {

	public static void main(String[] args) {
		
		
		
		
		JFrame f = new JFrame();
		f.setSize(300, 800);
		f.getContentPane().setLayout(null);
		
		FlowLayout flowlayout = new FlowLayout();
		
		
		JButton b1 = new JButton("\uBE68\uAC15\uC2E0\uD638");
		b1.setFont(new Font("����", Font.PLAIN, 40));
		b1.setBackground(Color.RED);
		b1.setForeground(Color.YELLOW);
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.setLayout(flowlayout);	
				JLabel l = new JLabel("");
				f.getContentPane().add(l);
				ImageIcon icon = new ImageIcon("����.png");
				l.setIcon(icon);				
			}
		});
		b1.setBounds(12, 10, 260, 78);
		f.getContentPane().add(b1);
		
		JButton b2 = new JButton("\uB178\uB791\uC2E0\uD638");
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.setLayout(flowlayout);	
				JLabel l = new JLabel("");
				f.getContentPane().add(l);
				ImageIcon icon = new ImageIcon("���.png");
				l.setIcon(icon);
			}
		});
		b2.setFont(new Font("����", Font.PLAIN, 40));
		b2.setForeground(new Color(255, 0, 0));
		b2.setBackground(Color.YELLOW);
		b2.setBounds(12, 97, 260, 78);
		f.getContentPane().add(b2);
		
		JButton b3 = new JButton("\uD30C\uB791\uC2E0\uD638");
		b3.setBackground(Color.BLUE);
		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.setLayout(flowlayout);	
				JLabel l = new JLabel("");
				f.getContentPane().add(l);
				ImageIcon icon = new ImageIcon("�ʷ�.png");
				l.setIcon(icon);
			}
		});
		b3.setFont(new Font("����", Font.PLAIN, 40));
		b3.setForeground(Color.YELLOW);
		b3.setBounds(12, 185, 260, 78);
		f.getContentPane().add(b3);
		
		
		
		
		
		f.setVisible(true);
	}
}
