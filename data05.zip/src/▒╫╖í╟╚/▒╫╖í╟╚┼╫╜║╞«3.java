package �׷���;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class �׷����׽�Ʈ3 {
	static String [] subject = new String[3];
	static int [] subjectCount = new int[3];


	
	public static void main(String[] args) {
		
		JFrame f = new JFrame();
		f.setSize(300, 300);
		FlowLayout flow = new FlowLayout();
		f.setLayout(flow);
		String sumSubject ; 

		for (int i = 0; i < 3; i++) {
			subject[i] = JOptionPane.showInputDialog("�����Է�");
		}
		
		for (int i = 0; i < 3; i++) {
			JButton b = new JButton(subject[i]);
			f.add(b);
			b.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					for (int j = 3; j < subjectCount.length; j++) {						
					}
					if(b.getText().equals(subject[0])) {
						subjectCount[0]++;
						String sumSubject = "";
							for (int k = 0; k < subject.length; k++) {
							sumSubject = sumSubject + (subject[k]+ " : " + subjectCount[k] + ", ");
							}
						f.setTitle(sumSubject);
					}else if(b.getText().equals(subject[1])) {
						subjectCount[1]++;
						String sumSubject = "";
						for (int k = 0; k < subject.length; k++) {
							sumSubject = sumSubject + (subject[k]+ " : " + subjectCount[k] + ", ");
							}
						f.setTitle(sumSubject);
					}else if(b.getText().equals(subject[2])) {
						subjectCount[2]++;
						String sumSubject = "";
						for (int k = 0; k < subject.length; k++) {
							sumSubject = sumSubject + (subject[k]+ " : " + subjectCount[k] + ", ");
							}
						f.setTitle(sumSubject);
					}
				}
			});
		}		
		f.setVisible(true);

	}
}
