package 윈도우;

import java.util.Random;
import java.util.Scanner;

public class 가위바위보2 {

	public static void main(String[] args) {

		// 가위바위보
		// 컴퓨터가 선택한다.
		Random rd = new Random();
		Scanner sc = new Scanner(System.in);
		int totalGame = 0;
		int winMe = 0;
		int winCom = 0;

		while (true) {
			int com = rd.nextInt(3);
			System.out.println("0.가위  1.바위  2.보 3.종료");
			System.out.print("가위바위보를 내세요 >>");
			int me = sc.nextInt();
			// if start
			if (me == 0) {
				if (com == 0) {
					System.out.println("비겼습니다.");
					System.out.println("-------------------");
				} else if (com == 1) {
					System.out.println("졌습니다!. 안타깝네요.");
					winCom++;
					totalGame++;
					System.out.println("-------------------");
				} else if (com == 2) {
					System.out.println("이겼습니다!. 축하합니다.");
					winMe++;
					totalGame++;
					System.out.println("-------------------");
				}
			} else if (me == 1) {
				if (com == 1) {
					System.out.println("비겼습니다. 다시 내세요");
					System.out.println("-------------------");
				} else if (com == 2) {
					System.out.println("졌습니다!. 안타깝네요.");
					winCom++;
					totalGame++;
					System.out.println("-------------------");
				} else if (com == 0) {
					System.out.println("이겼습니다!. 축하합니다.");
					winMe++;
					totalGame++;
					System.out.println("-------------------");
				}
			} else if (me == 2) {
				if (com == 2) {
					System.out.println("비겼습니다. 다시 내세요");
					System.out.println("-------------------");
				} else if (com == 0) {
					System.out.println("졌습니다!. 안타깝네요.");
					winCom++;
					totalGame++;
					System.out.println("-------------------");
				} else if (com == 1) {
					System.out.println("이겼습니다!. 축하합니다.");
					winMe++;
					totalGame++;
					System.out.println("-------------------");
				}
			} else {
				System.out.println("종료를 선택했습니다. 종료합니다.");
				System.out.println("컴퓨터 승리 횟수 : " + winCom + "회");
				System.out.println("내 승리 횟수 : " + winMe + "회");
				System.out.println("총 승률 : " + ((winMe*100) / totalGame) + "%");
				break;
			}
		} // while

		sc.close();
	}// main

}// class
