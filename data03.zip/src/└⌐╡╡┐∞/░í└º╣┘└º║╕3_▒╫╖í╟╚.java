package 윈도우;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

public class 가위바위보3_그래픽 {
	static int count = 0; //static main 안에 쓰려면 static을 붙여준다.
	static int comWin = 0;
	static int meWin = 0;
	
	public static void main(String[] args) {

 		Random rd = new Random();

		//1. 프레임에 해당하는 클래스 필요.
		 JFrame f = new JFrame();
		 JLabel result = new JLabel("게임결과 나타낼 자리 :");

		 
		 f.setTitle("가위바위보");
		 f.setSize(940, 489); // 프레임 사이즈
		 
		 JButton btnNewButton = new JButton("");
		 btnNewButton.setBackground(Color.PINK);
		 btnNewButton.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		count++;
		 		//result.setText("가위를 눌렀음");
		 		//JOptionPane.showMessageDialog(null,"가위를 눌렀음");
		 		//컴퓨터가 내게 함.
		 		int com = rd.nextInt(3);
		 		if (com == 0) {
					result.setText("비김");
				} else if (com == 1) {
					result.setText("컴퓨터 승");
					comWin++;
				} else if (com == 2) {
					result.setText("나 승");
					meWin++;
				}
		 		f.setTitle("가위 바위 보 게임 ** 총게임횟수 : " + count + ", 나 승 :" + meWin + "회, 컴 승 : " + comWin +"회");

		 	}
		 });
		 btnNewButton.setIcon(new ImageIcon("E:\\kjh\\java_project\\data03\\가위.png"));
		 f.getContentPane().add(btnNewButton, BorderLayout.WEST);
		 
		 JButton btnNewButton_1 = new JButton("");
		 btnNewButton_1.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		count++;

		 		int com = rd.nextInt(3);
		 		if (com == 0) {
					result.setText("나 승");
					meWin++;

				} else if (com == 1) {
					result.setText("비김");

				} else if (com == 2) {
					result.setText("컴퓨터 승");
					comWin++;

				}
		 		f.setTitle("가위 바위 보 게임 ** 총게임횟수 : " + count + ", 나 승 :" + meWin + "회, 컴 승 : " + comWin +"회");

		 	}
		 });
		 btnNewButton_1.setBackground(Color.ORANGE);
		 btnNewButton_1.setIcon(new ImageIcon("E:\\kjh\\java_project\\data03\\바위.png"));
		 f.getContentPane().add(btnNewButton_1, BorderLayout.CENTER);
		 
		 JButton btnNewButton_2 = new JButton("");
		 btnNewButton_2.setBackground(Color.CYAN);
		 btnNewButton_2.setIcon(new ImageIcon("E:\\kjh\\java_project\\data03\\보.png"));
		 btnNewButton_2.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		count++;

		 		int com = rd.nextInt(3);
		 		if (com == 0) {
					result.setText("컴퓨터 승");
					comWin++;
				} else if (com == 1) {
					result.setText("나 이승");
					meWin++;
				} else if (com == 2) {
					result.setText("비김");
				}
		 		f.setTitle("가위 바위 보 게임 ** 총게임횟수 : " + count + ", 나 승 :" + meWin + "회, 컴 승 : " + comWin +"회");

		 	}
		 });
		 
		 
		 
		 f.getContentPane().add(btnNewButton_2, BorderLayout.EAST);		 
		 result.setFont(new Font("굴림", Font.PLAIN, 15));
		 f.getContentPane().add(result, BorderLayout.SOUTH);
		 
		 
		 
		 f.setVisible(true); // 계속 뜨게하는 클래스(맨 마지막에 둔다)
		 
		 
		 
		
		
		
		
		
		
		
	}// main

}// class
