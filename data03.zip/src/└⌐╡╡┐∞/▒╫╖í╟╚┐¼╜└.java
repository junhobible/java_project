package 윈도우;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

public class 그래픽연습 {

	public static void main(String[] args) {

		//1. 프레임에 해당하는 클래스 필요.
		 JFrame f = new JFrame();
		 
		 f.setSize(500, 500); // 프레임 사이즈
		 
		 JButton btnNewButton = new JButton("나를 눌러요");
		 btnNewButton.setFont(new Font("굴림", Font.BOLD, 20));
		 btnNewButton.setForeground(Color.BLUE);
		 btnNewButton.setBackground(Color.GREEN);
		 f.getContentPane().add(btnNewButton, BorderLayout.CENTER);
		 
		 JButton btnNewButton_1 = new JButton("나는 위에 있는 버튼");
		 btnNewButton_1.setFont(new Font("굴림", Font.BOLD, 20));
		 btnNewButton_1.setBackground(Color.PINK);
		 btnNewButton_1.setForeground(Color.MAGENTA);
		 f.getContentPane().add(btnNewButton_1, BorderLayout.NORTH);
		 
		 JButton btnNewButton_2 = new JButton("나는 왼쪽버튼");
		 btnNewButton_2.setFont(new Font("한컴산뜻돋움", Font.BOLD, 15));
		 btnNewButton_2.setForeground(Color.BLUE);
		 btnNewButton_2.setBackground(Color.YELLOW);
		 f.getContentPane().add(btnNewButton_2, BorderLayout.WEST);
		 
		 JButton btnNewButton_3 = new JButton("나는 오른쪽 버튼");
		 btnNewButton_3.setFont(new Font("한컴산뜻돋움", Font.BOLD, 15));
		 btnNewButton_3.setForeground(Color.BLUE);
		 btnNewButton_3.setBackground(Color.CYAN);
		 f.getContentPane().add(btnNewButton_3, BorderLayout.EAST);
		 
		 JButton btnNewButton_4 = new JButton("나는 아래에 있는 버튼");
		 btnNewButton_4.setFont(new Font("굴림", Font.BOLD, 20));
		 btnNewButton_4.setForeground(Color.GREEN);
		 btnNewButton_4.setBackground(Color.PINK);
		 f.getContentPane().add(btnNewButton_4, BorderLayout.SOUTH);
		 

		 
		 
		 
		 
		 f.setVisible(true); // 계속 뜨게하는 클래스(맨 마지막에 둔다)
		 
		 
		 
		
		
		
		
		
		
		
	}// main

}// class
