package 윈도우;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JFormattedTextField;

public class 그래픽연습2 {
	static int jjamCount;
	static int jjaCount;
	static int udongCount;

	public static void main(String[] args) {
		
		

		//1. 프레임에 해당하는 클래스 필요.
		 JFrame f = new JFrame();
		 
		 JLabel count = new JLabel("");
		 count.setBackground(new Color(255, 255, 255));
		 count.setBounds(457, 10, 209, 53);
		 f.getContentPane().add(count);
		 
		 JLabel total = new JLabel("");
		 total.setBackground(new Color(255, 255, 255));
		 total.setBounds(267, 432, 321, 59);
		 f.getContentPane().add(total);
		 
		 
		 f.getContentPane().setBackground(new Color(255, 255, 0));
		 
		 f.setSize(782, 556); // 프레임 사이즈
		 f.getContentPane().setLayout(null);
		 
		 JButton jjam = new JButton("짬뽕");
		 jjam.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		
		 		jjamCount++;
		 	}
		 });
		 jjam.setBackground(new Color(255, 165, 0));
		 jjam.setFont(new Font("굴림", Font.BOLD, 15));
		 jjam.setBounds(12, 10, 124, 53);
		 f.getContentPane().add(jjam);
		 
		 JButton udong = new JButton("우동");
		 udong.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		udongCount++;
		 	}
		 });
		 udong.setBackground(new Color(255, 0, 255));
		 udong.setFont(new Font("굴림", Font.BOLD, 15));
		 udong.setBounds(148, 10, 124, 53);
		 f.getContentPane().add(udong);
		 
		 JButton jja = new JButton("자장");
		 jja.setBackground(new Color(0, 255, 255));
		 jja.setFont(new Font("굴림", Font.BOLD, 15));
		 jja.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		jjaCount++;
		 	}
		 });
		 jja.setBounds(284, 10, 124, 53);
		 f.getContentPane().add(jja);
		 
		 JTextArea textArea = new JTextArea();
		 textArea.setBackground(new Color(255, 255, 0));
		 textArea.setFont(new Font("Monospaced", Font.BOLD, 15));
		 textArea.setText("개수");
		 textArea.setBounds(420, 36, 44, 27);
		 f.getContentPane().add(textArea);
		 
		 JTextArea textArea_1 = new JTextArea();
		 textArea_1.setBackground(new Color(255, 255, 0));
		 textArea_1.setFont(new Font("Monospaced", Font.BOLD, 26));
		 textArea_1.setText("지불할 총 금액");
		 textArea_1.setBounds(51, 454, 209, 40);
		 f.getContentPane().add(textArea_1);
		 
		 
				 
		 
		 
		 
		 f.setVisible(true); // 계속 뜨게하는 클래스(맨 마지막에 둔다)
		 
		 
		 
		
		
		
		
		
		
		
	}// main
}// class
